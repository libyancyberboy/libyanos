# Tharaa Media Manager

منصة إدارة داخلية لثراء ميديا تشمل الموظفين، الأقسام، المالية، المهام، الحضور عبر QR/GPS، والتقارير.

## ملف الإعداد الواحد

قبل الرفع على cPanel عدّل الملف:

```text
tharaa.config.json
```

هذا هو الملف الرئيسي الذي تكتب فيه:

- رابط الموقع بعد الرفع.
- رابط أو بيانات قاعدة البيانات.
- إحداثيات مقر الشركة للحضور.
- مسافة السماح لتسجيل الحضور.
- سر الجلسات JWT.
- بيانات حساب المدير الافتراضي لأول تشغيل.

مهم: غيّر `jwtSecret` وبيانات المدير قبل الرفع.

## التشغيل المحلي من CMD

```bat
cd /d C:\path\to\project
npm install
npm run dev
```

افتح:

```text
http://localhost:3000
```

بيانات الدخول الافتراضية:

```text
username: admin
password: admin
portal: إدارة النظام
```

## الرفع على cPanel

1. افتح `tharaa.config.json` وعدّل القيم.
2. شغّل محليًا:
   ```bat
   npm install
   npm run build
   ```
3. ارفع ملفات المشروع إلى cPanel بدون:
   ```text
   node_modules
   .npm-cache
   data
   ```
4. من cPanel Node.js App:
   ```text
   Node.js version: 20 أو أحدث
   Application root: مسار مجلد المشروع
   Application startup command: npm run start
   Startup file إذا طلبه cPanel: server.js
   Environment: production
   ```
5. شغّل:
   ```bash
   npm install
   npm run build
   npm run start
   ```

## التخزين الحالي

النظام حاليًا يحفظ البيانات في ملف JSON:

```text
data/db.json
```

لو تبي لاحقًا ربط MySQL كامل، بيانات MySQL موجودة في `tharaa.config.json` وجاهزة كمدخلات، لكن التخزين الفعلي الحالي هو JSON ثابت ومناسب كبداية على cPanel.

## أوامر مفيدة

```bash
npm run lint
npm run build
npm run start
npm run clean
```
