import { jsPDF } from 'jspdf';

type PdfCell = string | number | null | undefined;
type Rgb = [number, number, number];

interface ArabicReportTable {
  title?: string;
  head: string[];
  rows: PdfCell[][];
  rowsPerPage?: number;
}

interface ArabicReportOptions {
  filename: string;
  title: string;
  subtitle?: string;
  meta?: Array<string | { label: string; value: PdfCell }>;
  summary?: Array<{ label: string; value: PdfCell; tone?: 'green' | 'orange' | 'dark' }>;
  image?: {
    dataUrl: string;
    caption?: string;
  };
  contentHtml?: string;
  table?: ArabicReportTable;
  tables?: ArabicReportTable[];
  footer?: string[];
  stamp?: {
    name: string;
    title: string;
  };
}

const PAGE_WIDTH = 794;
const PAGE_HEIGHT = 1123;
const PAGE_MARGIN = 52;
const CONTENT_WIDTH = PAGE_WIDTH - PAGE_MARGIN * 2;
const FOOTER_LINE_Y = 1064;
const FOOTER_TEXT_Y = 1086;
const PAGE_BOTTOM_LIMIT = 1034;
const CANVAS_SCALE = 2;
const FONT_FAMILY = '"ThmanyahSans", "Tahoma", "Arial", sans-serif';

const COLOR = {
  ink: [17, 19, 24] as Rgb,
  muted: [95, 102, 115] as Rgb,
  line: [217, 221, 229] as Rgb,
  soft: [247, 248, 250] as Rgb,
  orange: [249, 115, 22] as Rgb,
  green: [21, 128, 61] as Rgb,
  white: [255, 255, 255] as Rgb,
};

interface CanvasPage {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  y: number;
}

const textValue = (value: PdfCell) => String(value ?? '-').replace(/\s+/g, ' ').trim() || '-';

const cssColor = (color: Rgb) => `rgb(${color[0]}, ${color[1]}, ${color[2]})`;

const setFont = (ctx: CanvasRenderingContext2D, size: number, weight = 400) => {
  ctx.font = `${weight} ${size}px ${FONT_FAMILY}`;
};

const loadImage = (src: string) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    const timer = window.setTimeout(() => reject(new Error(`Image timeout: ${src}`)), 7000);
    image.onload = () => {
      window.clearTimeout(timer);
      resolve(image);
    };
    image.onerror = () => {
      window.clearTimeout(timer);
      reject(new Error(`Image load failed: ${src}`));
    };
    image.src = src;
  });

const prepareFonts = async () => {
  try {
    if (!document.fonts) return;
    await Promise.all([
      document.fonts.load(`400 24px ${FONT_FAMILY}`),
      document.fonts.load(`800 32px ${FONT_FAMILY}`),
    ]);
    await document.fonts.ready;
  } catch (error) {
    console.warn('PDF font readiness check failed, using browser fallback fonts.', error);
  }
};

const wrapTextByWidth = (
  ctx: CanvasRenderingContext2D,
  value: PdfCell,
  maxWidth: number,
  maxLines = 4
) => {
  const text = textValue(value);
  const words = text.split(' ');
  const lines: string[] = [];
  let current = '';

  words.forEach(word => {
    const trial = current ? `${current} ${word}` : word;
    if (ctx.measureText(trial).width <= maxWidth) {
      current = trial;
      return;
    }

    if (current) {
      lines.push(current);
      current = '';
    }

    if (ctx.measureText(word).width <= maxWidth) {
      current = word;
      return;
    }

    let chunk = '';
    Array.from(word).forEach(char => {
      const next = `${chunk}${char}`;
      if (ctx.measureText(next).width > maxWidth && chunk) {
        lines.push(chunk);
        chunk = char;
      } else {
        chunk = next;
      }
    });
    if (chunk) current = chunk;
  });

  if (current) lines.push(current);
  return lines.slice(0, maxLines);
};

const drawText = (
  page: CanvasPage,
  value: PdfCell,
  x: number,
  y: number,
  options: {
    size?: number;
    weight?: number;
    color?: Rgb;
    align?: CanvasTextAlign;
    direction?: 'rtl' | 'ltr';
    maxWidth?: number;
    maxLines?: number;
    lineHeight?: number;
  } = {}
) => {
  const { ctx } = page;
  const size = options.size || 16;
  const lineHeight = options.lineHeight || Math.round(size * 1.35);
  setFont(ctx, size, options.weight || 400);
  ctx.fillStyle = cssColor(options.color || COLOR.ink);
  ctx.textAlign = options.align || (options.direction === 'ltr' ? 'left' : 'right');
  ctx.textBaseline = 'alphabetic';
  (ctx as any).direction = options.direction || 'rtl';

  const lines = options.maxWidth
    ? wrapTextByWidth(ctx, value, options.maxWidth, options.maxLines)
    : [textValue(value)];

  lines.forEach((line, index) => {
    ctx.fillText(line, x, y + index * lineHeight);
  });

  return lines.length * lineHeight;
};

const roundedRect = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
  fill: Rgb,
  stroke?: Rgb,
  lineWidth = 1
) => {
  const safeRadius = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + safeRadius, y);
  ctx.lineTo(x + width - safeRadius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + safeRadius);
  ctx.lineTo(x + width, y + height - safeRadius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - safeRadius, y + height);
  ctx.lineTo(x + safeRadius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - safeRadius);
  ctx.lineTo(x, y + safeRadius);
  ctx.quadraticCurveTo(x, y, x + safeRadius, y);
  ctx.closePath();
  ctx.fillStyle = cssColor(fill);
  ctx.fill();

  if (stroke) {
    ctx.strokeStyle = cssColor(stroke);
    ctx.lineWidth = lineWidth;
    ctx.stroke();
  }
};

const extractImageFromContent = (contentHtml?: string) => {
  if (!contentHtml) return null;
  const imageMatch = contentHtml.match(/src="([^"]+)"/);
  const captionMatch = contentHtml.match(/<p>(.*?)<\/p>/);
  return imageMatch ? {
    dataUrl: imageMatch[1],
    caption: captionMatch?.[1]?.replace(/<[^>]+>/g, '')
  } : null;
};

const createPage = (options: ArabicReportOptions, logo: HTMLImageElement | null) => {
  const canvas = document.createElement('canvas');
  canvas.width = PAGE_WIDTH * CANVAS_SCALE;
  canvas.height = PAGE_HEIGHT * CANVAS_SCALE;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas is not available.');

  ctx.scale(CANVAS_SCALE, CANVAS_SCALE);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, PAGE_WIDTH, PAGE_HEIGHT);

  const page: CanvasPage = { canvas, ctx, y: 122 };
  drawPageHeader(page, options, logo);
  return page;
};

const drawPageHeader = (
  page: CanvasPage,
  options: ArabicReportOptions,
  logo: HTMLImageElement | null
) => {
  const { ctx } = page;

  if (logo) {
    ctx.drawImage(logo, PAGE_MARGIN - 8, 18, 160, 82);
  } else {
    drawText(page, 'THARAA MEDIA', PAGE_MARGIN, 55, {
      size: 22,
      weight: 800,
      color: COLOR.orange,
      align: 'left',
      direction: 'ltr',
    });
  }

  drawText(page, options.title, PAGE_WIDTH - PAGE_MARGIN, 54, {
    size: 31,
    weight: 800,
    maxWidth: 360,
    maxLines: 2,
    lineHeight: 37,
  });

  if (options.subtitle) {
    drawText(page, options.subtitle, PAGE_WIDTH - PAGE_MARGIN, 86, {
      size: 17,
      color: COLOR.muted,
      maxWidth: 420,
    });
  }

  ctx.strokeStyle = cssColor(COLOR.orange);
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(PAGE_MARGIN, 104);
  ctx.lineTo(PAGE_WIDTH - PAGE_MARGIN, 104);
  ctx.stroke();
};

const ensureSpace = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  neededHeight: number
) => {
  let page = pages[pages.length - 1];
  if (page.y + neededHeight <= PAGE_BOTTOM_LIMIT) return page;

  page = createPage(options, logo);
  pages.push(page);
  return page;
};

const drawMeta = (pages: CanvasPage[], options: ArabicReportOptions, logo: HTMLImageElement | null) => {
  if (!options.meta?.length) return;

  let page = pages[pages.length - 1];
  const gap = 10;
  const width = (CONTENT_WIDTH - gap) / 2;
  const height = 48;
  const rows = Math.ceil(options.meta.length / 2);
  page = ensureSpace(pages, options, logo, rows * (height + gap) + 10);

  options.meta.forEach((item, index) => {
    const col = index % 2;
    const row = Math.floor(index / 2);
    const x = col === 0 ? PAGE_WIDTH - PAGE_MARGIN - width : PAGE_MARGIN;
    const y = page.y + row * (height + gap);
    roundedRect(page.ctx, x, y, width, height, 12, COLOR.white, COLOR.line);

    if (typeof item === 'string') {
      drawText(page, item, x + width - 14, y + 30, { size: 15, maxWidth: width - 28 });
    } else {
      drawText(page, item.label, x + width - 14, y + 20, { size: 12, color: COLOR.muted, maxWidth: width - 28 });
      drawText(page, item.value, x + width - 14, y + 38, { size: 15, weight: 800, maxWidth: width - 28 });
    }
  });

  page.y += rows * (height + gap) + 8;
};

const drawSummary = (pages: CanvasPage[], options: ArabicReportOptions, logo: HTMLImageElement | null) => {
  if (!options.summary?.length) return;

  let page = pages[pages.length - 1];
  const gap = 10;
  const columns = options.summary.length <= 2 ? options.summary.length : 3;
  const width = (CONTENT_WIDTH - gap * (columns - 1)) / columns;
  const height = 76;
  const rows = Math.ceil(options.summary.length / columns);
  page = ensureSpace(pages, options, logo, rows * (height + gap) + 12);

  options.summary.forEach((item, index) => {
    const col = index % columns;
    const row = Math.floor(index / columns);
    const x = PAGE_WIDTH - PAGE_MARGIN - width - col * (width + gap);
    const y = page.y + row * (height + gap);
    const fill = item.tone === 'green' ? COLOR.green : item.tone === 'orange' ? COLOR.orange : COLOR.ink;
    roundedRect(page.ctx, x, y, width, height, 14, fill);
    drawText(page, item.label, x + width - 14, y + 25, { size: 13, color: COLOR.white, maxWidth: width - 28 });
    drawText(page, item.value, x + width - 14, y + 56, { size: 22, weight: 800, color: COLOR.white, maxWidth: width - 28 });
  });

  page.y += rows * (height + gap) + 12;
};

const drawImageBlock = async (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null
) => {
  const image = options.image || extractImageFromContent(options.contentHtml);
  if (!image?.dataUrl) return;

  let page = ensureSpace(pages, options, logo, 448);
  const cardWidth = 430;
  const cardHeight = 430;
  const x = PAGE_MARGIN + (CONTENT_WIDTH - cardWidth) / 2;
  const y = page.y;

  roundedRect(page.ctx, x, y, cardWidth, cardHeight, 24, COLOR.soft, COLOR.line);

  try {
    const loadedImage = await loadImage(image.dataUrl);
    page.ctx.drawImage(loadedImage, x + 65, y + 32, 300, 300);
  } catch (error) {
    console.warn('PDF image insertion failed:', error);
    drawText(page, 'تعذر إدراج الصورة', x + cardWidth / 2, y + 205, {
      size: 18,
      weight: 800,
      color: COLOR.muted,
      align: 'center',
    });
  }

  if (image.caption) {
    drawText(page, image.caption, PAGE_WIDTH / 2, y + 376, {
      size: 19,
      weight: 800,
      align: 'center',
      maxWidth: cardWidth - 40,
    });
  }

  page.y += cardHeight + 18;
};

const getColumnWidths = (columnCount: number) => {
  if (columnCount <= 4) return Array(columnCount).fill(CONTENT_WIDTH / columnCount);
  if (columnCount === 5) return [130, 135, 125, 140, 160];
  if (columnCount === 6) return [112, 112, 112, 112, 112, 130];
  if (columnCount === 7) return [95, 105, 95, 95, 95, 95, 110];
  if (columnCount === 8) return [84, 90, 84, 84, 84, 84, 84, 96];
  return Array(columnCount).fill(CONTENT_WIDTH / columnCount);
};

const getTableFontSize = (columnCount: number) => (
  columnCount > 8 ? 11 : columnCount > 7 ? 12 : columnCount > 5 ? 13 : 15
);

const measureTableRow = (
  page: CanvasPage,
  cells: PdfCell[],
  columnWidths: number[],
  isHead = false
) => {
  const fontSize = getTableFontSize(columnWidths.length);
  setFont(page.ctx, fontSize, isHead ? 800 : 400);
  const cellLines = cells.map((cell, index) => wrapTextByWidth(
    page.ctx,
    cell,
    (columnWidths[index] || columnWidths[columnWidths.length - 1]) - 16,
    columnWidths.length > 7 ? 2 : 4
  ));
  const lineCount = Math.max(...cellLines.map(lines => lines.length), 1);
  const rowHeight = Math.max(columnWidths.length > 7 ? 34 : 40, 18 + lineCount * Math.round(fontSize * 1.25));

  return { fontSize, cellLines, rowHeight };
};

const drawTableRow = (
  page: CanvasPage,
  cells: PdfCell[],
  columnWidths: number[],
  isHead = false,
  rowIndex = 0
) => {
  const { ctx } = page;
  const { fontSize, cellLines, rowHeight } = measureTableRow(page, cells, columnWidths, isHead);
  let x = PAGE_WIDTH - PAGE_MARGIN;

  cells.forEach((cell, index) => {
    const width = columnWidths[index] || columnWidths[columnWidths.length - 1];
    x -= width;

    ctx.fillStyle = cssColor(isHead ? COLOR.orange : rowIndex % 2 === 0 ? COLOR.white : COLOR.soft);
    ctx.strokeStyle = cssColor(isHead ? COLOR.orange : COLOR.line);
    ctx.lineWidth = 1;
    ctx.fillRect(x, page.y, width, rowHeight);
    ctx.strokeRect(x, page.y, width, rowHeight);

    const lines = cellLines[index] || [textValue(cell)];
    lines.forEach((line, lineIndex) => {
      drawText(page, line, x + width - 8, page.y + 23 + lineIndex * Math.round(fontSize * 1.25), {
        size: fontSize,
        weight: isHead ? 800 : 400,
        color: isHead ? COLOR.white : COLOR.ink,
        maxWidth: width - 16,
      });
    });
  });

  page.y += rowHeight;
};

const drawTable = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  table: ArabicReportTable
) => {
  let page = pages[pages.length - 1];
  const columnWidths = getColumnWidths(table.head.length);

  page = ensureSpace(pages, options, logo, 84);
  if (table.title) {
    drawText(page, table.title, PAGE_WIDTH - PAGE_MARGIN, page.y + 4, {
      size: 20,
      weight: 800,
      maxWidth: CONTENT_WIDTH,
    });
    page.y += 26;
  }

  const drawHeader = () => drawTableRow(page, table.head, columnWidths, true);
  drawHeader();

  const rows = table.rows.length ? table.rows : [['لا توجد بيانات', ...Array(table.head.length - 1).fill('')]];
  rows.forEach((row, index) => {
    const fullRow = table.head.map((_, cellIndex) => row[cellIndex] ?? '-');
    const { rowHeight } = measureTableRow(page, fullRow, columnWidths);
    if (page.y + rowHeight > PAGE_BOTTOM_LIMIT) {
      page = createPage(options, logo);
      pages.push(page);
      drawHeader();
    }
    drawTableRow(page, fullRow, columnWidths, false, index);
  });

  page.y += 14;
};

const drawStamp = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null
) => {
  if (!options.stamp) return;

  let page = ensureSpace(pages, options, logo, 138);
  page.y = Math.max(page.y, 918);

  if (page.y + 118 > PAGE_BOTTOM_LIMIT) {
    page = createPage(options, logo);
    pages.push(page);
    page.y = 918;
  }

  const { ctx } = page;
  const y = page.y;
  const approvalWidth = 270;
  const gap = 18;
  const blankWidth = (CONTENT_WIDTH - approvalWidth - gap * 2) / 2;
  const boxHeight = 104;
  const approvalX = PAGE_WIDTH - PAGE_MARGIN - approvalWidth;
  const signatureX = approvalX - gap - blankWidth;
  const stampX = PAGE_MARGIN;

  roundedRect(ctx, PAGE_MARGIN, y, CONTENT_WIDTH, boxHeight, 16, COLOR.white, COLOR.line);

  drawText(page, options.stamp.name, approvalX + approvalWidth - 24, y + 43, {
    size: 21,
    weight: 800,
    maxWidth: approvalWidth - 48,
  });
  drawText(page, options.stamp.title, approvalX + approvalWidth - 24, y + 70, {
    size: 16,
    color: COLOR.muted,
    maxWidth: approvalWidth - 48,
  });

  ctx.strokeStyle = cssColor(COLOR.ink);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(approvalX + 24, y + 86);
  ctx.lineTo(approvalX + approvalWidth - 24, y + 86);
  ctx.stroke();

  ctx.save();
  ctx.setLineDash([8, 7]);
  ctx.strokeStyle = cssColor(COLOR.line);
  ctx.lineWidth = 2;
  roundedRect(ctx, signatureX, y + 18, blankWidth, 68, 12, COLOR.white, COLOR.line, 2);
  roundedRect(ctx, stampX + 18, y + 14, blankWidth - 36, 76, 38, COLOR.white, COLOR.line, 2);
  ctx.restore();

  page.y += boxHeight + 14;
};

const drawFooter = (page: CanvasPage, pageNumber: number, totalPages: number, footer: string[]) => {
  const { ctx } = page;
  ctx.strokeStyle = 'rgb(229, 231, 235)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(PAGE_MARGIN, FOOTER_LINE_Y);
  ctx.lineTo(PAGE_WIDTH - PAGE_MARGIN, FOOTER_LINE_Y);
  ctx.stroke();

  if (footer.length) {
    drawText(page, footer.join(' | '), PAGE_WIDTH - PAGE_MARGIN, FOOTER_TEXT_Y, {
      size: 12,
      color: COLOR.muted,
      maxWidth: 480,
      maxLines: 1,
    });
  }

  drawText(page, `صفحة ${pageNumber} من ${totalPages}`, PAGE_MARGIN, FOOTER_TEXT_Y, {
    size: 12,
    color: COLOR.muted,
    align: 'left',
    direction: 'rtl',
  });
};

export const setupArabicPdf = async (doc: jsPDF) => {
  doc.setLanguage('ar');
  doc.setR2L(true);
  return 'canvas-arabic';
};

export const arabicText = (doc: jsPDF, text: string, x: number, y: number, options: Record<string, any> = {}) => {
  doc.setR2L(true);
  doc.text(String(text || ''), x, y, { align: 'right', ...options });
};

export const arabicTableStyles = (fontName: string) => ({
  styles: { font: fontName, fontSize: 8, halign: 'right' as const, cellPadding: 2.5 },
  headStyles: { font: fontName, fillColor: COLOR.orange, halign: 'right' as const, textColor: COLOR.white },
  bodyStyles: { font: fontName, halign: 'right' as const },
});

export const saveArabicReportPdf = async (options: ArabicReportOptions) => {
  try {
    await prepareFonts();
    const logo = await loadImage('/icons/logo.svg').catch(() => loadImage('/icons/icon.svg')).catch(() => null);
    const pages = [createPage(options, logo)];

    drawMeta(pages, options, logo);
    drawSummary(pages, options, logo);
    await drawImageBlock(pages, options, logo);

    const tables = options.tables || (options.table ? [options.table] : []);
    tables.forEach(table => drawTable(pages, options, logo, table));
    drawStamp(pages, options, logo);

    const doc = new jsPDF('p', 'mm', 'a4');
    pages.forEach((page, index) => {
      drawFooter(page, index + 1, pages.length, options.footer || []);
      if (index > 0) doc.addPage();
      doc.addImage(page.canvas.toDataURL('image/jpeg', 0.96), 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
    });

    doc.save(options.filename);
  } catch (error) {
    console.error('PDF export failed:', error);
    alert('تعذر تصدير PDF. راجع البيانات وحاول مرة ثانية.');
  }
};
