
import { 
  UserProfile, 
  Department, 
  FinanceTransaction, 
  Task, 
  AttendanceRecord 
} from '../types';

// Mock Data
export const MOCK_DEPARTMENTS: Department[] = [
  { id: 'dept-1', name: 'الإنتاج المرئي', description: 'تصوير، مونتاج، وإخراج الفيديو', createdAt: '2023-01-01' },
  { id: 'dept-2', name: 'الإدارة والمالية', description: 'الشؤون الإدارية والمالية', createdAt: '2023-01-01' },
  { id: 'dept-3', name: 'التسويق الرقمي', description: 'إدارة السوشيال ميديا والحملات الإعلانية', createdAt: '2023-01-01' },
  { id: 'dept-4', name: 'فريق المصممين', description: 'الهوية البصرية والتصميم الجرافيكي', createdAt: '2023-01-01' },
  { id: 'dept-5', name: 'تجهيزات المواقع', description: 'الإضاءة ميكرفونات والديكور', createdAt: '2023-01-01' },
  { id: 'dept-6', name: 'الأفلام الوثائقية', description: 'بحث، نص، وإنتاج الأفلام الوثائقية الطويلة والقصيرة', createdAt: '2023-01-01' },
];

export const MOCK_EMPLOYEES: UserProfile[] = [
  { 
    uid: 'user-1', 
    email: 'admin@tharaa.com', 
    displayName: 'محمود', 
    role: 'ADMIN', 
    departmentId: 'dept-2',
    joinDate: '2023-01-01',
    baseSalary: 6000
  },
  { 
    uid: 'user-2', 
    email: 'ali@tharaa.com', 
    displayName: 'علي الورفلي', 
    role: 'MANAGER', 
    departmentId: 'dept-1',
    joinDate: '2023-05-10',
    baseSalary: 4200
  },
];

export const MOCK_FINANCE: FinanceTransaction[] = [
  { id: 'f-1', type: 'INCOME', amount: 25000, source: 'عقد إنتاج إعلان - شركة ليبيانا', departmentId: 'dept-1', date: '2024-04-01', paymentMethod: 'BANK' },
  { id: 'f-2', type: 'EXPENSE', amount: 1500, category: 'OPERATIONAL', departmentId: 'dept-2', date: '2024-04-05', paymentMethod: 'CASH', vendor: 'التوأم للتوريدات', notes: 'أدوات مكتبية' },
];

export const MOCK_TASKS: Task[] = [
  { id: 't-1', title: 'تجهيز الاستوديو الجديد', description: 'تركيب الإضاءة والعزل الصوتي', assignedTo: 'user-1', departmentId: 'dept-5', priority: 'HIGH', status: 'IN_PROGRESS', deadline: '2024-05-15', createdAt: '2024-04-20' },
];

export const MOCK_ATTENDANCE: AttendanceRecord[] = [
  { id: 'a-1', employeeUid: 'user-1', departmentId: 'dept-2', timestamp: '2024-04-24T08:00:00Z', type: 'CHECK_IN' },
  { id: 'a-2', employeeUid: 'user-2', departmentId: 'dept-1', timestamp: '2024-04-24T09:15:00Z', type: 'CHECK_IN' },
];
