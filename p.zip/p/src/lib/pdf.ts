
import { jsPDF } from 'jspdf';
import { FinanceTransaction } from '../types';

export const generateInvoicePDF = (transaction: FinanceTransaction) => {
  const doc = new jsPDF();
  
  // Note: jspdf has limited support for Arabic fonts out of the box without loading them.
  // For this demo, we use English labels but show where Arabic would go.
  
  doc.setFontSize(22);
  doc.text('JISR ERP - TRANSACTION REPORT', 105, 20, { align: 'center' });
  
  doc.setFontSize(12);
  doc.text(`ID: ${transaction.id}`, 20, 40);
  doc.text(`Date: ${transaction.date}`, 20, 50);
  doc.text(`Type: ${transaction.type}`, 20, 60);
  doc.text(`Amount: ${transaction.amount} د.ل`, 20, 70);
  doc.text(`Method: ${transaction.paymentMethod}`, 20, 80);
  doc.text(`Notes: ${transaction.notes || 'N/A'}`, 20, 90);
  
  doc.rect(10, 10, 190, 277); // Border
  
  doc.save(`report-${transaction.id}.pdf`);
};
