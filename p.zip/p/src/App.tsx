import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Login from './pages/Login';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Departments from './pages/Departments';
import Users from './pages/Users';
import Finance from './pages/Finance';
import Tasks from './pages/Tasks';
import Attendance from './pages/Attendance';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Freelance from './pages/Freelance';
import Invoices from './pages/Invoices';
import Suppliers from './pages/Suppliers';
import Notifications from './pages/Notifications';
import InstallAppPrompt from './components/InstallAppPrompt';

const pathToTab: Record<string, string> = {
  '/': 'dashboard',
  '/dashboard': 'dashboard',
  '/attendance': 'attendance',
  '/tasks': 'tasks',
  '/finance': 'finance',
  '/freelance': 'freelance',
  '/invoices': 'invoices',
  '/suppliers': 'suppliers',
  '/notifications': 'notifications',
  '/users': 'users',
  '/departments': 'departments',
  '/reports': 'reports',
  '/settings': 'settings',
};

const tabToPath: Record<string, string> = {
  dashboard: '/',
  attendance: '/attendance',
  tasks: '/tasks',
  finance: '/finance',
  freelance: '/freelance',
  invoices: '/invoices',
  suppliers: '/suppliers',
  notifications: '/notifications',
  users: '/users',
  departments: '/departments',
  reports: '/reports',
  settings: '/settings',
};

const getTabFromLocation = () => pathToTab[window.location.pathname] || 'dashboard';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('token') !== null);
  const [user, setUser] = useState<any>(JSON.parse(localStorage.getItem('user') || 'null'));
  const [activeTab, setActiveTabState] = useState(getTabFromLocation);

  useEffect(() => {
    const handleRouteChange = () => setActiveTabState(getTabFromLocation());
    window.addEventListener('popstate', handleRouteChange);
    return () => window.removeEventListener('popstate', handleRouteChange);
  }, []);

  const setActiveTab = (tab: string) => {
    setActiveTabState(tab);
    const nextPath = tabToPath[tab] || '/';
    if (window.location.pathname !== nextPath || window.location.search) {
      window.history.pushState({}, '', nextPath);
    }
  };

  const onLogin = (token: string, userData: any) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    setIsLoggedIn(true);
  };

  const onLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setIsLoggedIn(false);
    setActiveTabState('dashboard');
    window.history.replaceState({}, '', '/');
  };

  if (!isLoggedIn || !user) {
    return <Login onLogin={onLogin} />;
  }

  const canOpenTab = (tab: string) => {
    if (tab === 'freelance') return user.role === 'ADMIN';
    if (tab === 'settings') return user.role === 'ADMIN';
    if (['users', 'departments', 'reports', 'invoices'].includes(tab)) return user.role === 'ADMIN' || user.role === 'MANAGER';
    if (tab === 'suppliers') return user.role === 'ADMIN' || user.role === 'MANAGER' || Boolean(user.isSupplier);
    return true;
  };

  const renderContent = () => {
    if (!canOpenTab(activeTab)) {
      return <Dashboard user={user} />;
    }

    const pages: any = {
      dashboard: <Dashboard user={user} />,
      departments: <Departments user={user} />,
      users: <Users />,
      finance: <Finance user={user} />,
      freelance: <Freelance />,
      invoices: <Invoices />,
      suppliers: <Suppliers user={user} />,
      notifications: <Notifications user={user} />,
      tasks: <Tasks user={user} />,
      attendance: <Attendance user={user} />,
      reports: <Reports />,
      settings: <Settings />,
    };
    return pages[activeTab] || <Dashboard user={user} />;
  };

  return (
    <div className="flex h-screen bg-[#0a0b0d] text-[#e1e1e1] font-sans" dir="rtl">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={onLogout} user={user} />
      <main className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
        <InstallAppPrompt />
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10, filter: 'blur(10px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -10, filter: 'blur(10px)' }}
            transition={{ duration: 0.3 }}
            className="max-w-7xl mx-auto"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
