/**
 * THARAA MEDIA - SYSTEM CONFIGURATION
 * Centralized repository for all sensitive URLs and system constants.
 */

export const SYSTEM_CONFIG = {
  VERSION: "3.0.0-PRO",
  COMPANY_NAME: "THARAA MEDIA",
  
  // Database & QR Service Links
  API_BASE_URL: window.location.origin + "/api",
  
  // Security Constants
  PASSWORD_MIN_LENGTH: 6,
  SESSION_TIMEOUT: 3600, // 1 hour in seconds

  // Attendance Parameters (GPS & Verification)
  COMPANY_LAT: 32.8872, // Representative Tripoli coordinates
  COMPANY_LNG: 13.1913,
  MAX_DISTANCE_METERS: 150,
  MAX_ATTENDANCE_INTERVAL: 120, // 2 minutes in seconds
  ATTENDANCE_TIME_ZONE: "Africa/Tripoli",
  ATTENDANCE_GRACE_MINUTES: 10,
  RATE_LIMIT_REQUESTS: 10,
};

export type PublicSystemConfig = typeof SYSTEM_CONFIG;

export async function loadPublicSystemConfig(): Promise<PublicSystemConfig> {
  try {
    const response = await fetch('/api/config/public');
    if (!response.ok) return SYSTEM_CONFIG;

    const config = await response.json();
    return {
      ...SYSTEM_CONFIG,
      COMPANY_NAME: config.companyName || SYSTEM_CONFIG.COMPANY_NAME,
      COMPANY_LAT: config.attendance?.companyLat ?? SYSTEM_CONFIG.COMPANY_LAT,
      COMPANY_LNG: config.attendance?.companyLng ?? SYSTEM_CONFIG.COMPANY_LNG,
      MAX_DISTANCE_METERS: config.attendance?.maxDistanceMeters ?? SYSTEM_CONFIG.MAX_DISTANCE_METERS,
      MAX_ATTENDANCE_INTERVAL: config.attendance?.minIntervalSeconds ?? SYSTEM_CONFIG.MAX_ATTENDANCE_INTERVAL,
      ATTENDANCE_TIME_ZONE: config.attendance?.timeZone ?? SYSTEM_CONFIG.ATTENDANCE_TIME_ZONE,
      ATTENDANCE_GRACE_MINUTES: config.attendance?.graceMinutes ?? SYSTEM_CONFIG.ATTENDANCE_GRACE_MINUTES,
    };
  } catch {
    return SYSTEM_CONFIG;
  }
}
