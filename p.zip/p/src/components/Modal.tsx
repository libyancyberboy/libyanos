import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, GripHorizontal } from 'lucide-react';
import { Rnd } from 'react-rnd';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

export default function Modal({ isOpen, onClose, title, children }: ModalProps) {
  const [size, setSize] = useState({ width: Math.min(512, Math.max(300, window.innerWidth - 24)), height: 'auto' });
  const isMobile = window.innerWidth < 640;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm pointer-events-auto"
          />
          
          <Rnd
            default={{
              x: Math.max(0, (window.innerWidth - Math.min(512, window.innerWidth - 40)) / 2),
              y: Math.max(0, (window.innerHeight - 500) / 2),
              width: Math.min(512, window.innerWidth - 40),
              height: 'auto',
            }}
            minWidth={Math.min(320, window.innerWidth - 16)}
            maxWidth={window.innerWidth - 16}
            bounds="window"
            dragHandleClassName={isMobile ? '' : 'modal-drag-handle'}
            disableDragging={isMobile}
            enableResizing={!isMobile}
            className="pointer-events-auto z-10"
            style={{ position: 'relative' }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full h-full bg-[#111318] border border-[#1f2127] rounded-[2rem] overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)] flex flex-col"
            >
              <div className="modal-drag-handle cursor-move flex items-center justify-between p-4 sm:p-6 border-b border-[#1f2127] bg-[#16191e] select-none">
                <div className="flex items-center gap-3">
                  <GripHorizontal size={16} className="text-[#4b5563]" />
                  <h3 className="text-base sm:text-xl font-bold text-white leading-none">{title}</h3>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 text-[#6b7280] hover:text-white hover:bg-[#1f2127] rounded-xl transition-all"
                >
                  <X size={20} />
                </button>
              </div>
              <div className="p-4 sm:p-8 custom-scrollbar overflow-y-auto flex-1 max-h-[calc(100vh-140px)]">
                {children}
              </div>
              {/* Resize Handle Indicator */}
              <div className="absolute bottom-1 right-1 w-4 h-4 cursor-nwse-resize flex items-center justify-center opacity-30 hover:opacity-100 transition-opacity">
                <div className="w-1.5 h-1.5 rounded-full border border-[#4b5563]" />
              </div>
            </motion.div>
          </Rnd>
        </div>
      )}
    </AnimatePresence>
  );
}
