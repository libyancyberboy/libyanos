import React, { useEffect, useState } from 'react';
import { Download, MonitorDown, Smartphone, X } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export default function InstallAppPrompt() {
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const standalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as any).standalone;
    if (standalone) {
      setInstalled(true);
      return;
    }

    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as BeforeInstallPromptEvent);
    };

    const handleInstalled = () => {
      setInstalled(true);
      setInstallEvent(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleInstalled);
    };
  }, []);

  const installApp = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    await installEvent.userChoice;
    setInstallEvent(null);
  };

  if (dismissed || installed) return null;

  return (
    <div className="mb-5 bg-[#111318] border border-orange-500/20 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg shadow-orange-500/5">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-11 h-11 rounded-xl bg-orange-600/10 text-orange-500 flex items-center justify-center shrink-0">
          {installEvent ? <Download size={22} /> : <Smartphone size={22} />}
        </div>
        <div className="min-w-0">
          <h3 className="text-sm font-black text-white">تحميل التطبيق على الجهاز</h3>
          <p className="text-xs text-[#6b7280] leading-relaxed">
            {installEvent
              ? 'اضغط تثبيت باش ينزل كاختصار تطبيق من المتصفح.'
              : 'من قائمة المتصفح اختار Install app أو Add to Home Screen.'}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={installApp}
          disabled={!installEvent}
          className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
            installEvent
              ? 'bg-orange-600 hover:bg-orange-500 text-white'
              : 'bg-[#0a0b0d] border border-[#1f2127] text-[#6b7280]'
          }`}
        >
          <MonitorDown size={16} />
          تثبيت
        </button>
        <button
          onClick={() => setDismissed(true)}
          className="p-3 rounded-xl bg-[#0a0b0d] border border-[#1f2127] text-[#6b7280] hover:text-white transition-all"
          title="إخفاء"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
}
