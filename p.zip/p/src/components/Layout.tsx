
import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Wallet, 
  CheckSquare, 
  Users, 
  Building2, 
  QrCode, 
  BarChart3, 
  Settings,
  LogOut,
  Menu,
  X,
  Moon,
  Sun
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}

const navItems = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { id: 'finance', label: 'المالية', icon: Wallet },
  { id: 'tasks', label: 'المهام', icon: CheckSquare },
  { id: 'departments', label: 'الأقسام', icon: Building2 },
  { id: 'employees', label: 'الموظفين', icon: Users },
  { id: 'attendance', label: 'الحضور والانصراف', icon: QrCode },
  { id: 'reports', label: 'التقارير', icon: BarChart3 },
  { id: 'settings', label: 'الإعدادات', icon: Settings },
];

export default function Layout({ children, activeTab, setActiveTab, onLogout }: LayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="flex h-full w-full bg-[#0a0b0d] text-[#e1e1e1] font-sans overflow-hidden rtl" dir="rtl">
      
      {/* Sidebar Navigation */}
      <aside className={cn(
        "border-l border-[#1f2127] bg-[#111318] flex flex-col p-6 transition-all duration-300",
        isSidebarOpen ? "w-64" : "w-20"
      )}>
        <div className="flex items-center gap-3 mb-10 px-2 overflow-hidden">
          <div className="min-w-[40px] h-10 bg-[#f97316] rounded-lg flex items-center justify-center shadow-lg shadow-orange-500/20">
            <span className="text-white font-bold text-xl">ث</span>
          </div>
          {isSidebarOpen && (
            <span className="text-lg font-bold tracking-tight whitespace-nowrap">
              ثراء | THARAA<br/>
              <span className="text-[#6b7280] text-[10px] font-mono">MEDIA v1.0</span>
            </span>
          )}
        </div>
        
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2 rounded-md transition-all duration-200 group text-right",
                  isActive 
                    ? "bg-[#1f2127] text-white" 
                    : "text-[#6b7280] hover:bg-[#16191e] hover:text-[#e1e1e1]"
                )}
              >
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full transition-all",
                  isActive ? "bg-[#f97316] scale-100" : "bg-transparent scale-0 group-hover:scale-100 group-hover:bg-[#1f2127]"
                )} />
                <Icon size={18} className={cn(!isSidebarOpen && "mx-auto")} />
                {isSidebarOpen && <span className="text-sm">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        <div className="mt-auto p-4 bg-[#16191e] rounded-xl border border-[#1f2127]">
          {isSidebarOpen && <div className="text-[10px] uppercase text-[#6b7280] mb-2 font-mono tracking-wider italic font-bold">المستخدم الحالي</div>}
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-orange-500 to-red-600 flex-shrink-0 shadow-lg shadow-orange-500/20" />
            {isSidebarOpen && (
              <div className="overflow-hidden">
                <div className="text-sm font-bold truncate text-white">محمود</div>
                <div className="text-[10px] text-orange-400 font-mono font-bold tracking-tighter">MASTER_ADMIN</div>
              </div>
            )}
          </div>
          <button 
            onClick={onLogout}
            className={cn(
              "w-full flex items-center gap-2 py-2 text-red-500 hover:text-red-400 transition-colors text-xs font-bold border-t border-[#1f2127] pt-3 mt-2",
              !isSidebarOpen && "justify-center px-0"
            )}
          >
            <LogOut size={16} />
            {isSidebarOpen && <span>خروج آمن</span>}
          </button>
        </div>
        
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="mt-4 p-2 text-[#6b7280] hover:text-white transition-colors"
        >
          {isSidebarOpen ? <X size={18} /> : <Menu size={18} />}
        </button>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-[#1f2127] flex items-center justify-between px-8 bg-[#0a0b0d]/80 backdrop-blur-md z-30">
          <div className="flex items-center gap-6 w-1/3">
            <div className="relative w-full">
              <input 
                type="text" 
                placeholder="بحث ذكي... (F1)" 
                className="w-full bg-[#111318] border border-[#1f2127] rounded-lg py-1.5 px-4 text-xs focus:outline-none focus:border-[#f97316] transition-colors placeholder:text-[#6b7280]" 
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-[10px] text-green-400 font-mono">SYSTEM ONLINE</span>
            </div>
            <button className="p-2 text-[#6b7280] hover:text-white transition-colors">
              <span className="relative">
                🔔
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#f97316] rounded-full border border-[#0a0b0d]"></span>
              </span>
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
          >
            {children}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
