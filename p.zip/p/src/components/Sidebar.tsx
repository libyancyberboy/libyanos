import React from 'react';
import { 
  LayoutDashboard, 
  Building2, 
  Users as UsersIcon, 
  Wallet, 
  ReceiptText,
  FileText,
  BriefcaseBusiness,
  Truck,
  Bell,
  CheckSquare, 
  Clock, 
  BarChart3, 
  Settings,
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { cn } from '../lib/utils';

import { SYSTEM_CONFIG } from '../config';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  user: any;
}

export default function Sidebar({ activeTab, setActiveTab, onLogout, user }: SidebarProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  const allMenuItems = [
    { id: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard, roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { id: 'attendance', label: 'الحضور', icon: Clock, roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { id: 'tasks', label: 'المهام', icon: CheckSquare, roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { id: 'finance', label: 'المالية', icon: Wallet, roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { id: 'invoices', label: 'الفواتير', icon: ReceiptText, roles: ['ADMIN', 'MANAGER'] },
    { id: 'letters', label: 'رسالة رسمية', icon: FileText, roles: ['ADMIN', 'MANAGER'] },
    { id: 'suppliers', label: 'الموردين', icon: Truck, roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'], supplierOnly: true },
    { id: 'notifications', label: 'الإشعارات', icon: Bell, roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { id: 'freelance', label: 'الفري لانس', icon: BriefcaseBusiness, roles: ['ADMIN'] },
    { id: 'users', label: 'الموظفين', icon: UsersIcon, roles: ['ADMIN', 'MANAGER'] },
    { id: 'departments', label: 'الأقسام', icon: Building2, roles: ['ADMIN', 'MANAGER'] },
    { id: 'reports', label: 'التقارير', icon: BarChart3, roles: ['ADMIN', 'MANAGER'] },
    { id: 'settings', label: 'الإعدادات', icon: Settings, roles: ['ADMIN'] },
  ];

  const menuItems = allMenuItems.filter(item => {
    if (!item.roles.includes(user?.role)) return false;
    if ((item as any).supplierOnly) {
      return user?.role === 'ADMIN' || user?.role === 'MANAGER' || Boolean(user?.isSupplier);
    }
    return true;
  });

  const NavContent = () => (
    <>
      <div className="p-6 border-b border-[#1f2127] flex items-center justify-between">
        <h1 className="text-xl font-black text-orange-500 tracking-tighter truncate">{SYSTEM_CONFIG.COMPANY_NAME} <span className="text-[10px] text-[#6b7280] font-mono uppercase">V_{SYSTEM_CONFIG.VERSION}</span></h1>
        <button onClick={() => setIsOpen(false)} className="md:hidden text-[#6b7280]">
          <X size={24} />
        </button>
      </div>
      
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id);
              setIsOpen(false);
            }}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all",
              activeTab === item.id 
                ? "bg-orange-600 text-white shadow-lg shadow-orange-500/20" 
                : "text-[#6b7280] hover:bg-[#1f2127] hover:text-white"
            )}
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-[#1f2127] space-y-2">
        <div className="flex items-center gap-3 px-4 py-3 bg-[#0a0b0d] rounded-2xl border border-[#1f2127]">
           <div className="w-8 h-8 rounded-full bg-orange-600 flex items-center justify-center text-white font-black text-xs">
              {user?.username?.[0]?.toUpperCase()}
           </div>
           <div className="flex-1 overflow-hidden">
              <p className="text-xs font-bold text-white truncate">{user?.username}</p>
              <p className="text-[10px] text-[#4b5563] font-mono">{user?.role}</p>
           </div>
        </div>
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-500/10 rounded-xl transition-all font-bold text-sm"
        >
          <LogOut size={20} />
          <span>تسجيل الخروج</span>
        </button>
      </div>
    </>
  );

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="md:hidden fixed top-4 right-4 z-50 p-3 bg-[#111318] border border-[#1f2127] text-white rounded-xl shadow-xl"
      >
        <Menu size={20} />
      </button>

      <aside className="w-64 bg-[#111318] border-l border-[#1f2127] flex flex-col h-screen sticky top-0 hidden md:flex">
        <NavContent />
      </aside>

      {isOpen && (
        <div className="fixed inset-0 z-[100] md:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsOpen(false)} />
          <aside className="absolute right-0 top-0 bottom-0 w-64 bg-[#111318] border-l border-[#1f2127] flex flex-col animate-in slide-in-from-right duration-300">
            <NavContent />
          </aside>
        </div>
      )}
    </>
  );
}
