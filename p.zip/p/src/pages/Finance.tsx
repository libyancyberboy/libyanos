import React, { useState, useEffect, useMemo } from 'react';
import { Wallet, ArrowUpRight, ArrowDownRight, Printer, Trash2 } from 'lucide-react';
import Modal from '../components/Modal';
import { saveArabicReportPdf } from '../lib/pdfArabic';

interface FinanceProps {
  user: any;
}

export default function Finance({ user }: FinanceProps) {
  if (!user) return null;
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [personalSalary, setSalary] = useState(0);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'income' | 'expense'>('income');
  const [formData, setFormData] = useState({
    category: '',
    amount: '',
    notes: '',
    employeeId: ''
  });

  useEffect(() => {
    fetchFinance();
    if (user.role === 'ADMIN' || user.role === 'MANAGER') {
      fetch('/api/users', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      .then(r => r.json())
      .then(d => setUsers(d));
      fetch('/api/departments', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      .then(r => r.json())
      .then(d => setDepartments(Array.isArray(d) ? d : []));
    }
  }, [user, selectedEmployeeId]);

  const fetchFinance = () => {
    setLoading(true);
    const query = (user.role === 'ADMIN' || user.role === 'MANAGER') && selectedEmployeeId 
      ? `?employeeId=${selectedEmployeeId}` 
      : '';

    fetch(`/api/finance${query}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(r => r.json())
    .then(d => {
      // Role is EMPLOYEE or Admin has selected a specific employee
      if (user.role === 'EMPLOYEE' || (isAdmin && selectedEmployeeId)) {
        setData(d.entries || []);
        setSalary(d.salary || 0);
      } else {
        setData(d || []);
        setSalary(0);
      }
      setLoading(false);
    });
  };

  const handleOpenModal = (type: 'income' | 'expense', category?: string) => {
    setModalType(type);
    setFormData({ category: category || 'عام', amount: '', notes: '', employeeId: selectedEmployeeId || '' });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const resp = await fetch('/api/finance', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ 
        type: modalType, 
        amount: parseFloat(formData.amount), 
        category: formData.category, 
        notes: formData.notes, 
        employeeId: formData.employeeId || null 
      })
    });
    if (resp.ok) {
      await fetchFinance(); // Refresh to get correct stats
      setIsModalOpen(false);
    } else {
      const err = await resp.json();
      alert(err.message || 'تعذر تسجيل العملية المالية');
    }
  };

  const isAdmin = user.role === 'ADMIN' || user.role === 'MANAGER';
  const departmentNameById = useMemo(() => {
    return departments.reduce<Record<string, string>>((acc, dept: any) => {
      acc[dept.id] = dept.name;
      return acc;
    }, {});
  }, [departments]);

  const getDepartmentName = (departmentId?: string) => (
    departmentId ? (departmentNameById[departmentId] || departmentId) : 'عام'
  );

  const handleDeleteTrx = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذه العملية المالية؟")) return;
    const resp = await fetch(`/api/finance/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (resp.ok) {
      setData(data.filter((d: any) => d.id !== id));
    }
  };

  // Logic to distinguish categories
  const isSalaryPayment = (category: string) => 
    category?.includes('راتب') || category?.includes('Salary') || category?.includes('صرف');
  const isBonus = (category: string) => 
    category?.includes('مكافأة') || category?.includes('Bonus') || category?.includes('إضافة');

  // Filter logic for summaries
  const relevantEntries = isAdmin && selectedEmployeeId 
    ? data.filter((f: any) => f.employeeId === selectedEmployeeId) 
    : data;

  const totalIncome = relevantEntries.filter((f: any) => f.type === 'income').reduce((a, b: any) => a + b.amount, 0);
  const totalExpense = relevantEntries.filter((f: any) => f.type === 'expense').reduce((a, b: any) => a + b.amount, 0);

  // General Deductions (Non-Salaries)
  const totalDeductionsAll = data.filter((f: any) => f.type === 'expense' && f.category === 'خصم').reduce((a, b: any) => a + b.amount, 0);

  // Employee specific logic (Deductions vs Payouts)
  const employeeDeductions = data.filter((f: any) => f.type === 'expense' && (f.category === 'خصم' || (!isSalaryPayment(f.category) && f.employeeId))).reduce((a, b: any) => a + b.amount, 0);
  const employeeBonuses = data.filter((f: any) => f.type === 'income' || (f.type === 'expense' && isBonus(f.category))).reduce((a, b: any) => a + b.amount, 0);
  const paidAmount = data.filter((f: any) => f.type === 'expense' && isSalaryPayment(f.category)).reduce((a, b: any) => a + b.amount, 0);

  const handleExportPDF = async () => {
    try {
      const tableRows = data.map((item: any) => [
        new Date(item.timestamp).toLocaleDateString('ar-LY'),
        getDepartmentName(item.departmentId),
        item.category || 'General',
        item.type === 'income' ? 'إيراد' : 'مصروف',
        `${Number(item.amount || 0).toLocaleString()} LYD`,
        item.notes || '-'
      ]);

      await saveArabicReportPdf({
        filename: `finance_report_${Date.now()}.pdf`,
        title: 'التقرير المالي',
        meta: [
          { label: 'تاريخ التصدير', value: new Date().toLocaleString('ar-LY') },
          { label: 'النطاق', value: selectedEmployeeId ? `الموظف: ${users.find(u => u.id === selectedEmployeeId)?.username || selectedEmployeeId}` : 'الخزينة العامة' }
        ],
        summary: [
          { label: 'إجمالي الإيرادات', value: `${totalIncome.toLocaleString()} LYD`, tone: 'green' },
          { label: 'إجمالي المصروفات', value: `${totalExpense.toLocaleString()} LYD`, tone: 'orange' },
          { label: 'الصافي', value: `${(totalIncome - totalExpense).toLocaleString()} LYD`, tone: 'dark' }
        ],
        table: {
          title: 'الحركات المالية',
          head: ['التاريخ', 'القسم', 'الفئة', 'النوع', 'المبلغ', 'التفاصيل'],
          rows: tableRows
        },
        footer: ['التقرير المالي']
      });
    } catch (err) {
      console.error("PDF Export Error:", err);
      alert("حدث خطأ أثناء تصدير PDF. تأكد من أن جميع البيانات صحيحة.");
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-10">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black text-white">المالية</h1>
          <p className="text-[#6b7280]">إدارة التدفقات النقدية والرواتب والميزانيات</p>
        </div>
        {isAdmin && (
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <select
              value={selectedEmployeeId}
              onChange={(e) => setSelectedEmployeeId(e.target.value)}
              className="bg-[#111318] border border-[#1f2127] text-white rounded-2xl px-4 py-3 text-sm focus:border-orange-500 outline-none w-full md:w-auto"
            >
              <option value="">جميع الموظفين (الخزينة العامة)</option>
              {users.map(u => (
                <option key={u.id} value={u.id}>{u.username}</option>
              ))}
            </select>
            <div className="flex gap-3 w-full md:w-auto">
              <button 
                onClick={() => handleOpenModal('expense', 'خصم')}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#111318] border border-red-500/30 text-red-500 font-bold rounded-2xl hover:bg-red-500 hover:text-white transition-all active:scale-95"
              >
                <ArrowDownRight size={18} />
                <span>تسجيل خصم</span>
              </button>
              <button 
                onClick={() => handleOpenModal('expense')}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#111318] border border-[#1f2127] text-white font-bold rounded-2xl hover:border-orange-500 transition-all active:scale-95"
              >
                <ArrowDownRight size={18} className="text-orange-500" />
                <span>مصروف</span>
              </button>
              <button 
                onClick={() => handleOpenModal('income')}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
              >
                <ArrowUpRight size={18} />
                <span>إيراد</span>
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-1 gap-6 mb-8">
        <div className={`bg-[#111318] p-8 border border-[#1f2127] rounded-[2rem] ${user.role === 'EMPLOYEE' || selectedEmployeeId ? 'glow-orange' : ''}`}>
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="space-y-1 text-center md:text-right w-full">
              <h3 className="text-[#6b7280] text-xs font-mono tracking-widest uppercase mb-4 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></div>
                {user.role === 'EMPLOYEE' || selectedEmployeeId ? 'Personal_Financial_Profile' : 'General_Ledger_Active'}
              </h3>
              {user.role === 'EMPLOYEE' || (isAdmin && selectedEmployeeId) ? (
                <div className="flex flex-col sm:flex-row flex-wrap gap-4 sm:gap-8 justify-center md:justify-start w-full">
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[200px]">
                     <p className="text-[10px] text-[#4b5563] mb-1">الراتب الأساسي + الإضافات</p>
                     <p className="text-3xl font-black text-white">{(personalSalary + employeeBonuses).toLocaleString()} <span className="text-xs text-orange-500">LYD</span></p>
                     {employeeBonuses > 0 && <p className="text-[9px] text-green-500 mt-1">يتضمن {employeeBonuses.toLocaleString()} إضافات/مكافآت</p>}
                   </div>
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[200px]">
                     <p className="text-[10px] text-orange-600 mb-1">الخصميات الفردية</p>
                     <p className="text-3xl font-black text-orange-600">{employeeDeductions.toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                   <div className="bg-orange-600 p-6 rounded-2xl flex-1 min-w-[200px] shadow-lg shadow-orange-600/20">
                     <p className="text-[10px] text-white/50 mb-1">الصافي المتبقي</p>
                     <p className="text-3xl font-black text-white">{(personalSalary + employeeBonuses - employeeDeductions - paidAmount).toLocaleString()} <span className="text-xs">LYD</span></p>
                     {paidAmount > 0 && <p className="text-[9px] text-white/70 mt-1">تم صرف {paidAmount.toLocaleString()} سابقاً</p>}
                   </div>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row flex-wrap gap-4 sm:gap-8 w-full">
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[180px]">
                     <p className="text-[10px] text-green-500 mb-1">إجمالي الدخل</p>
                     <p className="text-3xl font-black text-white">{totalIncome.toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[180px]">
                     <p className="text-[10px] text-orange-600 mb-1">إجمالي الخصميات</p>
                     <p className="text-3xl font-black text-white">{totalDeductionsAll.toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[180px]">
                     <p className="text-[10px] text-[#6b7280] mb-1">صافي الخزينة</p>
                     <p className="text-3xl font-black text-white">{(totalIncome - totalExpense).toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 flex flex-col min-h-[400px]">
          {data.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center opacity-30">
              <Wallet size={48} className="mb-4" />
              <p className="font-mono font-bold uppercase tracking-[0.3em]">{loading ? 'Syncing_Ledger...' : 'No_Transactions'}</p>
            </div>
          ) : (
            <div className="space-y-4 w-full">
              {data.map((trx: any) => (
                <div key={trx.id} className={`bg-[#0a0b0d] p-4 border rounded-2xl flex justify-between items-center group transition-all gap-4 ${trx.category === 'خصم' ? 'border-red-500/20 hover:border-red-500/50' : 'border-[#1f2127] hover:border-orange-500/30'}`}>
                  <div className="flex items-center gap-4 overflow-hidden">
                    <div className={trx.type === 'income' ? 'text-green-500 shrink-0' : (trx.category === 'خصم' ? 'text-red-500 shrink-0' : 'text-orange-500 shrink-0')}>
                      {trx.type === 'income' ? <ArrowUpRight size={20} /> : <ArrowDownRight size={20} />}
                    </div>
                    <div className="truncate">
                      <p className="font-bold text-white truncate">{trx.category || 'عام'}</p>
                      <p className="text-[10px] text-[#6b7280] font-mono">
                        {new Date(trx.timestamp).toLocaleDateString()} · {getDepartmentName(trx.departmentId)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 sm:gap-4 shrink-0">
                    <span className={`font-mono font-bold text-sm sm:text-base ${trx.type === 'income' ? 'text-green-500' : 'text-orange-500'}`}>
                      {trx.type === 'income' ? '+' : '-'}{trx.amount.toLocaleString()} 
                    </span>
                    {(user.role === 'ADMIN' || user.role === 'MANAGER') && (
                      <button 
                        onClick={() => handleDeleteTrx(trx.id)}
                        className="opacity-100 sm:opacity-0 group-hover:opacity-100 p-2 text-red-500/50 hover:text-red-500 transition-all"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="space-y-6">
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 glow-orange">
            <h3 className="text-xs font-bold text-[#6b7280] uppercase tracking-widest font-mono mb-6">Realtime_Summary</h3>
            <div className="space-y-4">
              <div className="flex justify-between border-b border-[#1f2127] pb-3">
                <span className="text-[#6b7280] text-sm">إجمالي الدخل</span>
                <span className="text-green-500 font-mono font-black">{totalIncome.toLocaleString()} LYD</span>
              </div>
              <div className="flex justify-between border-b border-[#1f2127] pb-3">
                <span className="text-[#6b7280] text-sm">إجمالي المصروف</span>
                <span className="text-orange-600 font-mono font-black">{totalExpense.toLocaleString()} LYD</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-white font-bold text-sm">صافي الصندوق</span>
                <span className="text-orange-500 font-mono font-black">{(totalIncome - totalExpense).toLocaleString()} LYD</span>
              </div>
            </div>
            <button 
              onClick={handleExportPDF}
              className="w-full mt-8 flex items-center justify-center gap-2 py-4 bg-orange-600/10 border border-orange-500/20 text-orange-500 rounded-2xl font-bold hover:bg-orange-600 hover:text-white transition-all"
            >
              <Printer size={18} />
              تصدير كشف PDF
            </button>
          </div>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalType === 'income' ? 'تسجيل إيراد جديد' : 'تسجيل مصروف جديد'}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">الفئة</label>
            <input
              type="text"
              required
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="مثال: رواتب، مبيعات، إيجار..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">المبلغ (LYD)</label>
            <input
              type="number"
              required
              value={formData.amount}
              onChange={(e) => setFormData({...formData, amount: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">ملاحظات إضافية</label>
            <input
              type="text"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            />
          </div>

          {isAdmin && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">ربط بموظف (اختياري)</label>
              <select
                value={formData.employeeId}
                onChange={(e) => setFormData({...formData, employeeId: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              >
                <option value="">لا يوجد ارتباط</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>{u.username} ({u.role})</option>
                ))}
              </select>
            </div>
          )}

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-500/20"
            >
              تسجيل العملية
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-6 py-3 bg-[#1f2127] text-white font-bold rounded-xl hover:bg-[#2a2d35] transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
