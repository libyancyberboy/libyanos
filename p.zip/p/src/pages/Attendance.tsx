import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertCircle, CalendarDays, CheckCircle2, Clock, FileDown, Loader2, MapPin, QrCode, Share2, ShieldCheck, UserCheck, UserX } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { SYSTEM_CONFIG, loadPublicSystemConfig } from '../config';
import { saveArabicReportPdf } from '../lib/pdfArabic';

interface AttendanceProps {
  user: any;
}

type ReportPeriod = 'daily' | 'weekly' | 'monthly' | 'annual';

interface ReportDay {
  date: string;
  status: 'present' | 'absent';
  checkIn: string | null;
  checkOut: string | null;
  late: boolean;
  lateMinutes: number;
  earlyDeparture: boolean;
  earlyMinutes: number;
  logsCount: number;
}

interface ReportRow {
  userId: string;
  username: string;
  role: string;
  departmentName: string;
  attendanceStartTime: string;
  attendanceEndTime: string;
  attendanceGraceMinutes: number;
  presentDays: number;
  absentDays: number;
  lateDays: number;
  earlyDepartureDays: number;
  checkedOutDays: number;
  totalDays: number;
  days: ReportDay[];
}

interface AttendanceReport {
  period: ReportPeriod;
  startDate: string;
  endDate: string;
  totals: {
    employees: number;
    totalDays: number;
    presentDays: number;
    absentDays: number;
    lateDays: number;
    earlyDepartureDays: number;
    checkedOutDays: number;
  };
  rows: ReportRow[];
}

const todayKey = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const formatTime = (value: string | null) => {
  if (!value) return '-';
  return new Date(value).toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' });
};

const periodLabels: Record<ReportPeriod, string> = {
  daily: 'يومي',
  weekly: 'أسبوعي',
  monthly: 'شهري',
  annual: 'سنوي',
};

export default function Attendance({ user }: AttendanceProps) {
  if (!user) return null;

  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error' | 'processing'>('idle');
  const [msg, setMsg] = useState('');
  const [publicConfig, setPublicConfig] = useState(SYSTEM_CONFIG);
  const [depts, setDepts] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [selectedDept, setSelectedDept] = useState<string>('');
  const [qrTokens, setQrTokens] = useState<Record<string, string>>({});
  const [period, setPeriod] = useState<ReportPeriod>('daily');
  const [reportDate, setReportDate] = useState(todayKey);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [report, setReport] = useState<AttendanceReport | null>(null);

  const isAdmin = user.role === 'ADMIN' || user.role === 'MANAGER';
  const attendanceUsers = useMemo(() => users.filter((item) => item.role !== 'ADMIN'), [users]);

  const fetchReport = useCallback(async () => {
    if (!isAdmin) return;
    const params = new URLSearchParams({
      period,
      date: reportDate,
    });
    if (selectedEmployeeId) params.set('employeeId', selectedEmployeeId);

    const resp = await fetch(`/api/attendance/report?${params.toString()}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    const data = await resp.json();
    setReport(data);
  }, [isAdmin, period, reportDate, selectedEmployeeId]);

  useEffect(() => {
    loadPublicSystemConfig().then(setPublicConfig);

    if (isAdmin) {
      fetch('/api/departments', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
        .then((r) => r.json())
        .then((data) => {
          setDepts(data);
          if (data.length > 0) setSelectedDept(data[0].id);
        });

      fetch('/api/users', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
        .then((r) => r.json())
        .then((data) => setUsers(Array.isArray(data) ? data : []));

      fetch('/api/attendance/qr-tokens', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
        .then((r) => r.json())
        .then((tokens) => {
          const tokenMap: Record<string, string> = {};
          tokens.forEach((token: any) => { tokenMap[token.departmentId] = token.token; });
          setQrTokens(tokenMap);
        });
    }
  }, [isAdmin]);

  useEffect(() => {
    fetchReport();
  }, [fetchReport]);

  const handleAutomaticAttendance = useCallback(async (deptId: string, token: string) => {
    setStatus('processing');
    setLoading(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        try {
          const resp = await fetch('/api/attendance/check', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
              token,
              departmentId: deptId,
              lat: latitude,
              lng: longitude
            })
          });
          const data = await resp.json();
          if (resp.ok) {
            setStatus('success');
            setMsg(data.message);
          } else {
            setStatus('error');
            setMsg(data.message || 'فشل التحقق من بيانات الحضور');
          }
        } catch {
          setStatus('error');
          setMsg('حدث خطأ أثناء الاتصال بالخادم');
        } finally {
          setLoading(false);
        }
      },
      () => {
        setStatus('error');
        setMsg('يجب السماح بالوصول للموقع الجغرافي GPS لتسجيل الحضور');
        setLoading(false);
      },
      { enableHighAccuracy: true }
    );
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const deptId = params.get('dept');
    const token = params.get('token');

    if (deptId && token && !isAdmin) {
      handleAutomaticAttendance(deptId, token);
    }
  }, [handleAutomaticAttendance, isAdmin]);

  const ensureStableToken = async (deptId: string) => {
    const resp = await fetch('/api/attendance/qr-tokens', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ departmentId: deptId })
    });
    const data = await resp.json();
    if (resp.ok) setQrTokens((prev) => ({ ...prev, [deptId]: data.token }));
  };

  const currentToken = qrTokens[selectedDept];
  const attendanceUrl = currentToken ? `${window.location.origin}/attendance?dept=${selectedDept}&token=${currentToken}` : '';
  const selectedEmployee = attendanceUsers.find((item) => item.id === selectedEmployeeId);

  const exportReport = async () => {
    if (!report) return;

    const title = `تقرير الحضور والغياب - ${periodLabels[period]}`;
    const tables = [
      {
        title: 'ملخص الموظفين',
        head: ['الموظف', 'القسم', 'وقت الدوام', 'المهلة', 'حضور', 'غياب', 'تأخير', 'خروج مبكر', 'خروج'],
        rows: report.rows.map((row) => [
          row.username,
          row.departmentName,
          `${row.attendanceStartTime} - ${row.attendanceEndTime}`,
          `${row.attendanceGraceMinutes} د`,
          row.presentDays,
          row.absentDays,
          row.lateDays,
          row.earlyDepartureDays,
          row.checkedOutDays
        ]),
        rowsPerPage: 16
      }
    ];

    if (selectedEmployeeId && report.rows[0]?.days?.length) {
      tables.push({
        title: 'السجل اليومي للموظف',
        head: ['التاريخ', 'الحالة', 'الدخول', 'الخروج', 'دقائق التأخير', 'خروج مبكر'],
        rows: report.rows[0].days.map((day) => [
          day.date,
          day.status === 'present' ? 'حاضر' : 'غائب',
          formatTime(day.checkIn),
          formatTime(day.checkOut),
          day.lateMinutes,
          day.earlyDeparture ? `${day.earlyMinutes} د` : '-'
        ]),
        rowsPerPage: 22
      });
    }

    await saveArabicReportPdf({
      filename: `attendance-${period}-${Date.now()}.pdf`,
      title,
      meta: [
        { label: 'الفترة', value: `${report.startDate} إلى ${report.endDate}` },
        { label: 'الموظف', value: selectedEmployee?.username || 'كل الموظفين' }
      ],
      summary: [
        { label: 'الحضور', value: report.totals.presentDays, tone: 'green' },
        { label: 'الغياب', value: report.totals.absentDays, tone: 'orange' },
        { label: 'التأخير', value: report.totals.lateDays, tone: 'dark' },
        { label: 'الخروج المبكر', value: report.totals.earlyDepartureDays, tone: 'dark' }
      ],
      tables,
      footer: ['تقرير الحضور والغياب']
    });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-10 px-4">
      <div className="text-center space-y-4">
        <div className="inline-flex p-5 bg-orange-900/10 border border-orange-800/20 rounded-[2rem] text-orange-500">
          <Clock size={48} />
        </div>
        <h1 className="text-3xl font-black text-white">{publicConfig.COMPANY_NAME} | الحضور الذكي</h1>
        <p className="text-[#6b7280]">
          {isAdmin ? 'تقارير يومية وأسبوعية وشهرية وسنوية حسب الموظف' : 'سجل حضورك من رابط QR الخاص بالقسم'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <div className="space-y-6">
          {isAdmin ? (
            <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <QrCode size={20} className="text-orange-500" />
                  <h3 className="text-md font-bold text-white">رابط QR للحضور</h3>
                </div>
                <button
                  onClick={() => ensureStableToken(selectedDept)}
                  className="p-2 text-orange-500 hover:bg-orange-500/10 rounded-lg transition-all"
                  title={currentToken ? 'الرابط ثابت' : 'إنشاء رابط ثابت'}
                >
                  <ShieldCheck size={18} />
                </button>
              </div>

              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              >
                {depts.map((dept) => <option key={dept.id} value={dept.id}>{dept.name}</option>)}
              </select>

              {attendanceUrl && (
                <div className="space-y-5">
                  <div className="bg-white p-6 rounded-[2rem] flex items-center justify-center mx-auto w-fit shadow-2xl">
                    <QRCodeSVG value={attendanceUrl} size={200} level="H" includeMargin />
                  </div>
                  <div className="p-3 bg-[#0a0b0d] border border-[#1f2127] rounded-xl flex items-center justify-between gap-2">
                    <span className="text-[10px] text-[#6b7280] truncate">{attendanceUrl}</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(attendanceUrl);
                        alert('تم نسخ الرابط');
                      }}
                      className="p-1.5 text-orange-500 hover:bg-orange-500/10 rounded-lg transition-all"
                    >
                      <Share2 size={14} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className={`bg-[#111318] border border-[#1f2127] rounded-[2rem] p-12 text-center space-y-6 transition-all ${loading ? 'animate-pulse border-orange-500/50' : ''}`}>
              {status === 'idle' && (
                <div className="space-y-6">
                  <AlertCircle size={48} className="mx-auto text-[#1f2127]" />
                  <h3 className="text-lg font-bold text-white">انتظار رابط الحضور</h3>
                  <p className="text-sm text-[#6b7280] leading-relaxed">افتح رابط QR الخاص بالقسم لتسجيل حضورك أو انصرافك تلقائياً.</p>
                </div>
              )}

              {status === 'processing' && (
                <div className="space-y-6 py-10">
                  <Loader2 size={64} className="mx-auto text-orange-500 animate-spin" />
                  <h3 className="text-xl font-black text-white">جاري التحقق...</h3>
                </div>
              )}

              {status !== 'idle' && status !== 'processing' && (
                <div className="space-y-6">
                  <div className={status === 'success' ? 'text-green-500' : 'text-orange-500'}>
                    {status === 'success' ? <CheckCircle2 size={64} className="mx-auto" /> : <AlertCircle size={64} className="mx-auto" />}
                  </div>
                  <h3 className="text-xl font-bold text-white">{status === 'success' ? 'تمت العملية' : 'تعذر التسجيل'}</h3>
                  <p className={`text-sm leading-relaxed ${status === 'success' ? 'text-green-500/80' : 'text-orange-500/80'}`}>{msg}</p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 space-y-6">
          <h3 className="text-[10px] font-black text-orange-500 uppercase font-mono tracking-[0.3em]">Attendance_Control</h3>
          <div className="space-y-4">
            <div className="p-4 bg-[#0a0b0d] border border-[#1f2127] rounded-2xl flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500">
                <MapPin size={20} />
              </div>
              <div>
                <p className="text-xs font-bold text-white">التحقق الجغرافي</p>
                <p className="text-[10px] text-[#4b5563] font-mono">Radius: {publicConfig.MAX_DISTANCE_METERS}m</p>
              </div>
            </div>
            <div className="p-4 bg-[#0a0b0d] border border-[#1f2127] rounded-2xl flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center text-green-500">
                <Clock size={20} />
              </div>
              <div>
                <p className="text-xs font-bold text-white">وقت حضور لكل موظف</p>
                <p className="text-[10px] text-[#4b5563]">أي دخول بعد الوقت المحدد يتسجل كمتأخر مع تنبيه خصم.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {isAdmin && report && (
        <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6 md:p-8 space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#0a0b0d] border border-[#1f2127] flex items-center justify-center text-orange-500">
                <CalendarDays size={22} />
              </div>
              <div>
                <h2 className="text-xl font-black text-white">تقارير الحضور والغياب</h2>
                <p className="text-xs text-[#6b7280]">الأدمن مستبعد من الحسابات</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <select
                value={selectedEmployeeId}
                onChange={(event) => setSelectedEmployeeId(event.target.value)}
                className="bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              >
                <option value="">كل الموظفين</option>
                {attendanceUsers.map((item) => (
                  <option key={item.id} value={item.id}>{item.username}</option>
                ))}
              </select>
              <input
                type="date"
                value={reportDate}
                onChange={(event) => setReportDate(event.target.value)}
                className="bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              />
              <button
                onClick={exportReport}
                className="flex items-center justify-center gap-2 px-5 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl transition-all"
              >
                <FileDown size={16} />
                PDF
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {(['daily', 'weekly', 'monthly', 'annual'] as ReportPeriod[]).map((item) => (
              <button
                key={item}
                onClick={() => setPeriod(item)}
                className={`py-3 rounded-xl text-sm font-bold transition-all ${period === item ? 'bg-orange-600 text-white' : 'bg-[#0a0b0d] border border-[#1f2127] text-[#6b7280] hover:text-white'}`}
              >
                {periodLabels[item]}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 flex items-center gap-3">
              <UserCheck size={20} className="text-green-500" />
              <div><p className="text-[10px] text-[#6b7280]">حضور</p><p className="text-2xl font-black text-white">{report.totals.presentDays}</p></div>
            </div>
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 flex items-center gap-3">
              <UserX size={20} className="text-red-500" />
              <div><p className="text-[10px] text-[#6b7280]">غياب</p><p className="text-2xl font-black text-white">{report.totals.absentDays}</p></div>
            </div>
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 flex items-center gap-3">
              <Clock size={20} className="text-orange-500" />
              <div><p className="text-[10px] text-[#6b7280]">تأخير</p><p className="text-2xl font-black text-white">{report.totals.lateDays}</p></div>
            </div>
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 flex items-center gap-3">
              <Clock size={20} className="text-red-500" />
              <div><p className="text-[10px] text-[#6b7280]">خروج مبكر</p><p className="text-2xl font-black text-white">{report.totals.earlyDepartureDays}</p></div>
            </div>
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
              <p className="text-[10px] text-[#6b7280]">الفترة</p>
              <p className="text-sm font-black text-white">{report.startDate} / {report.endDate}</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[820px]">
              <thead>
                <tr className="text-[#6b7280] border-b border-[#1f2127]">
                  <th className="py-3 text-right font-bold">الموظف</th>
                  <th className="py-3 text-right font-bold">القسم</th>
                  <th className="py-3 text-right font-bold">وقت الدوام</th>
                  <th className="py-3 text-right font-bold">المهلة</th>
                  <th className="py-3 text-right font-bold">حضور</th>
                  <th className="py-3 text-right font-bold">غياب</th>
                  <th className="py-3 text-right font-bold">تأخير</th>
                  <th className="py-3 text-right font-bold">خروج مبكر</th>
                  <th className="py-3 text-right font-bold">خروج</th>
                </tr>
              </thead>
              <tbody>
                {report.rows.map((row) => (
                  <tr key={row.userId} className="border-b border-[#1f2127]/60">
                    <td className="py-4 text-white font-bold">{row.username}</td>
                    <td className="py-4 text-[#6b7280]">{row.departmentName}</td>
                    <td className="py-4 text-[#d1d5db] font-mono">{row.attendanceStartTime} - {row.attendanceEndTime}</td>
                    <td className="py-4 text-[#d1d5db] font-mono">{row.attendanceGraceMinutes}د</td>
                    <td className="py-4 text-green-500 font-mono">{row.presentDays}</td>
                    <td className="py-4 text-red-500 font-mono">{row.absentDays}</td>
                    <td className="py-4 text-orange-500 font-mono">{row.lateDays}</td>
                    <td className="py-4 text-red-500 font-mono">{row.earlyDepartureDays}</td>
                    <td className="py-4 text-[#d1d5db] font-mono">{row.checkedOutDays}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedEmployeeId && report.rows[0] && (
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 space-y-3">
              <h3 className="text-sm font-black text-white">تفصيل أيام الموظف</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {report.rows[0].days.map((day) => (
                  <div key={day.date} className="border border-[#1f2127] rounded-xl p-3 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-white font-bold">{day.date}</p>
                      <p className="text-[10px] text-[#6b7280]">دخول {formatTime(day.checkIn)} | خروج {formatTime(day.checkOut)}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black ${day.status === 'present' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                      {day.late
                        ? `متأخر ${day.lateMinutes}د`
                        : day.earlyDeparture
                          ? `خروج مبكر ${day.earlyMinutes}د`
                          : day.status === 'present' ? 'حاضر' : 'غائب'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
