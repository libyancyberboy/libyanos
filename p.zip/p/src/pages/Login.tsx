import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Lock, LogIn } from 'lucide-react';
import InstallAppPrompt from '../components/InstallAppPrompt';

interface LoginProps {
  onLogin: (token: string, user: any) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'MANAGEMENT' | 'EMPLOYEE'>('EMPLOYEE');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const resp = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, role })
      });
      const data = await resp.json();
      if (resp.ok) {
        onLogin(data.token, data.user);
      } else {
        setError(data.message);
      }
    } catch (err) {
      setError('فشل الاتصال بالخادم');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0b0d] flex flex-col items-center justify-center p-4 gap-4" dir="rtl">
      <div className="w-full max-w-md">
        <InstallAppPrompt />
      </div>
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 shadow-2xl"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-black text-white mb-2">منصة الإدارة الذكية</h1>
          <p className="text-[#6b7280] text-sm">مرحباً بك مجدداً في نظام مؤسستك</p>
        </div>

        <div className="flex bg-[#0a0b0d] p-1 rounded-2xl mb-8 border border-[#1f2127]">
          <button
            onClick={() => setRole('MANAGEMENT')}
            className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all ${role === 'MANAGEMENT' ? 'bg-orange-600 text-white shadow-lg' : 'text-[#6b7280]'}`}
          >
            إدارة النـظام
          </button>
          <button
            onClick={() => setRole('EMPLOYEE')}
            className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all ${role === 'EMPLOYEE' ? 'bg-orange-600 text-white shadow-lg' : 'text-[#6b7280]'}`}
          >
            بوابة الموظف
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-1">
            <label className="text-[10px] text-[#6b7280] font-mono font-bold uppercase tracking-widest mr-1">Identifier</label>
            <div className="relative">
              <User size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#4b5563]" />
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-2xl py-4 pr-12 pl-4 focus:border-orange-500 outline-none transition-all"
                placeholder={role === 'MANAGEMENT' ? "اسم المستخدم" : "رقم الموظف / اسم المستخدم"}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-[#6b7280] font-mono font-bold uppercase tracking-widest mr-1">Access_Key</label>
            <div className="relative">
              <Lock size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#4b5563]" />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-2xl py-4 pr-12 pl-4 focus:border-orange-500 outline-none transition-all"
                placeholder="••••••••"
              />
            </div>
          </div>

          {error && <p className="text-red-500 text-xs text-center font-bold bg-red-500/10 py-2 rounded-lg">{error}</p>}

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-3 transition-all shadow-lg shadow-orange-500/20"
          >
            دخول للنظام <LogIn size={20} />
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
}
