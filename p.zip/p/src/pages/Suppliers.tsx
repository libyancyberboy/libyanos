import React, { useEffect, useMemo, useState } from 'react';
import { BadgeDollarSign, Download, FileText, Plus, ReceiptText, Trash2, Truck, Upload } from 'lucide-react';

interface SuppliersProps {
  user: any;
}

interface SupplierInvoice {
  id: string;
  supplierId: string;
  supplierName: string;
  description: string;
  amount: number;
  createdAt: string;
  attachment?: {
    name: string;
    type: string;
    size: number;
    dataUrl: string;
  };
}

const fileToAttachment = (file: File) => new Promise<any>((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve({
    name: file.name,
    type: file.type || 'application/octet-stream',
    size: file.size,
    dataUrl: reader.result
  });
  reader.onerror = reject;
  reader.readAsDataURL(file);
});

export default function Suppliers({ user }: SuppliersProps) {
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<SupplierInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [selectedSupplierId, setSelectedSupplierId] = useState('');

  const canManage = user?.role === 'ADMIN' || user?.role === 'MANAGER';
  const canAddInvoice = Boolean(user?.isSupplier || canManage);

  const fetchInvoices = async () => {
    setLoading(true);
    const resp = await fetch('/api/supplier-invoices', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });

    if (resp.ok) {
      const data = await resp.json();
      setSuppliers(data.suppliers || []);
      setInvoices(data.invoices || []);
      if (!selectedSupplierId && data.suppliers?.length) {
        setSelectedSupplierId(data.suppliers[0].id);
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchInvoices();
  }, []);

  const total = useMemo(() => invoices.reduce((sum, invoice) => sum + Number(invoice.amount || 0), 0), [invoices]);
  const grouped = useMemo(() => {
    const map = new Map<string, { supplier: any; invoices: SupplierInvoice[]; total: number }>();

    suppliers.forEach((supplier) => {
      map.set(supplier.id, { supplier, invoices: [], total: 0 });
    });

    invoices.forEach((invoice) => {
      if (!map.has(invoice.supplierId)) {
        map.set(invoice.supplierId, {
          supplier: { id: invoice.supplierId, username: invoice.supplierName || 'مورد غير محدد' },
          invoices: [],
          total: 0
        });
      }
      const group = map.get(invoice.supplierId)!;
      group.invoices.push(invoice);
      group.total += Number(invoice.amount || 0);
    });

    return Array.from(map.values()).filter(group => group.invoices.length > 0 || canManage);
  }, [suppliers, invoices, canManage]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!file) {
      alert('ارفق ملف الفاتورة');
      return;
    }

    if (file.size > 6 * 1024 * 1024) {
      alert('حجم الفاتورة كبير. اختار ملف أقل من 6MB.');
      return;
    }

    setSaving(true);
    try {
      const attachment = await fileToAttachment(file);
      const resp = await fetch('/api/supplier-invoices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          supplierId: canManage ? selectedSupplierId : undefined,
          description,
          amount: parseFloat(amount),
          attachment
        })
      });

      if (resp.ok) {
        setDescription('');
        setAmount('');
        setFile(null);
        const input = document.getElementById('supplier-invoice-file') as HTMLInputElement | null;
        if (input) input.value = '';
        await fetchInvoices();
      } else {
        const err = await resp.json();
        alert(err.message || 'تعذر حفظ الفاتورة');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (invoiceId: string) => {
    if (!confirm('هل تريد حذف هذه الفاتورة؟')) return;
    const resp = await fetch(`/api/supplier-invoices/${invoiceId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (resp.ok) {
      setInvoices(current => current.filter(invoice => invoice.id !== invoiceId));
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-orange-600/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
            <Truck size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-white">الموردين</h1>
            <p className="text-[#6b7280] text-sm">مشتريات الموردين وفواتيرهم</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#111318] border border-[#1f2127] rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Truck size={20} className="text-orange-500" />
            <span className="text-[#6b7280] text-sm font-bold">عدد الموردين</span>
          </div>
          <p className="text-4xl font-black text-white">{suppliers.length}</p>
        </div>
        <div className="bg-[#111318] border border-[#1f2127] rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <ReceiptText size={20} className="text-orange-500" />
            <span className="text-[#6b7280] text-sm font-bold">عدد الفواتير</span>
          </div>
          <p className="text-4xl font-black text-white">{invoices.length}</p>
        </div>
        <div className="bg-orange-600 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <BadgeDollarSign size={20} className="text-white" />
            <span className="text-white/70 text-sm font-bold">إجمالي الفواتير</span>
          </div>
          <p className="text-4xl font-black text-white">{total.toLocaleString()} <span className="text-sm">LYD</span></p>
        </div>
      </div>

      {canAddInvoice && (
        <form onSubmit={handleSubmit} className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-5 sm:p-8 space-y-5">
          <div className="flex items-center gap-3">
            <Plus size={20} className="text-orange-500" />
            <h2 className="text-lg font-black text-white">إضافة فاتورة مورد</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_180px_240px] gap-4">
            {canManage && (
              <select
                value={selectedSupplierId}
                onChange={(event) => setSelectedSupplierId(event.target.value)}
                className="bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              >
                {suppliers.map((supplier) => (
                  <option key={supplier.id} value={supplier.id}>{supplier.username}</option>
                ))}
              </select>
            )}
            <input
              type="text"
              required
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              className="bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="شن شريت؟"
            />
            <input
              type="number"
              required
              min="0"
              step="0.01"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
              className="bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="القيمة"
            />
          </div>

          <div className="flex flex-col md:flex-row gap-4 md:items-center">
            <label className="flex-1 flex items-center gap-3 bg-[#0a0b0d] border border-dashed border-[#343842] rounded-xl py-4 px-4 cursor-pointer hover:border-orange-500/50 transition-all">
              <Upload size={18} className="text-orange-500" />
              <span className="text-sm text-[#9ca3af] truncate">{file ? file.name : 'إرفاق الفاتورة PDF أو صورة'}</span>
              <input
                id="supplier-invoice-file"
                type="file"
                accept="application/pdf,image/*"
                onChange={(event) => setFile(event.target.files?.[0] || null)}
                className="hidden"
              />
            </label>
            <button
              type="submit"
              disabled={saving || (canManage && !selectedSupplierId)}
              className="flex items-center justify-center gap-2 px-6 py-4 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all"
            >
              <Plus size={18} />
              {saving ? 'جاري الحفظ...' : 'حفظ الفاتورة'}
            </button>
          </div>
        </form>
      )}

      <div className="space-y-5">
        {loading ? (
          <div className="bg-[#111318] border border-[#1f2127] rounded-2xl p-10 text-center text-[#6b7280]">جاري تحميل الفواتير...</div>
        ) : grouped.length === 0 ? (
          <div className="bg-[#111318] border border-[#1f2127] rounded-2xl p-10 text-center text-[#6b7280]">لا توجد فواتير موردين بعد.</div>
        ) : grouped.map((group) => (
          <section key={group.supplier.id} className="bg-[#111318] border border-[#1f2127] rounded-[2rem] overflow-hidden">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-5 border-b border-[#1f2127]">
              <div>
                <h2 className="text-xl font-black text-white">{group.supplier.username}</h2>
                <p className="text-sm text-[#6b7280]">عدد الفواتير: {group.invoices.length}</p>
              </div>
              <div className="text-left">
                <p className="text-xs text-[#6b7280]">إجمالي المورد</p>
                <p className="text-2xl font-black text-orange-500">{group.total.toLocaleString()} LYD</p>
              </div>
            </div>

            <div className="divide-y divide-[#1f2127]">
              {group.invoices.map((invoice) => (
                <div key={invoice.id} className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#0a0b0d] border border-[#1f2127] text-orange-500 flex items-center justify-center shrink-0">
                      <FileText size={18} />
                    </div>
                    <div>
                      <h3 className="text-white font-bold">{invoice.description}</h3>
                      <p className="text-[11px] text-[#6b7280] mt-1">
                        التاريخ من المنظومة: {new Date(invoice.createdAt).toLocaleString('ar-LY')}
                      </p>
                      <p className="text-[11px] text-[#6b7280] mt-1">{invoice.attachment?.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-black text-white">{Number(invoice.amount || 0).toLocaleString()} LYD</span>
                    {invoice.attachment?.dataUrl && (
                      <a
                        href={invoice.attachment.dataUrl}
                        download={invoice.attachment.name || 'invoice'}
                        className="p-3 bg-[#0a0b0d] border border-[#1f2127] text-orange-500 hover:bg-orange-600 hover:text-white rounded-xl transition-all"
                        title="تحميل الفاتورة"
                      >
                        <Download size={18} />
                      </a>
                    )}
                    {(canManage || invoice.supplierId === user?.id) && (
                      <button
                        onClick={() => handleDelete(invoice.id)}
                        className="p-3 bg-[#0a0b0d] border border-[#1f2127] text-red-500/70 hover:text-red-500 rounded-xl transition-all"
                        title="حذف الفاتورة"
                      >
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
