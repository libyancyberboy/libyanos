import React, { useState } from 'react';
import { AlignRight, Building2, CalendarDays, FileDown, FileText, Hash, Type } from 'lucide-react';
import { saveArabicReportPdf } from '../lib/pdfArabic';

const today = () => new Date().toISOString().slice(0, 10);
const EXECUTIVE_NAME = 'محمود قنونو';
const EXECUTIVE_TITLE = 'المدير التنفيذي';
const GREETING = 'تحية طيبة وبعد،';

export default function OfficialLetters() {
  const [formData, setFormData] = useState({
    recipient: '',
    reference: '',
    subject: '',
    body: '',
    date: today(),
  });

  const displayDate = formData.date
    ? new Date(formData.date).toLocaleDateString('ar-LY')
    : new Date().toLocaleDateString('ar-LY');

  const handleExport = async () => {
    if (!formData.recipient.trim()) return alert('اكتب الجهة المرسل إليها');
    if (!formData.subject.trim()) return alert('اكتب موضوع الرسالة');
    if (!formData.body.trim()) return alert('اكتب نص الرسالة الرسمية');

    await saveArabicReportPdf({
      filename: `official-letter-${Date.now()}.pdf`,
      title: 'رسالة رسمية',
      subtitle: 'THARAA MEDIA',
      letter: {
        recipient: formData.recipient.trim(),
        reference: formData.reference.trim() || '-',
        date: displayDate,
        subject: formData.subject.trim(),
        body: formData.body.trim(),
        greeting: GREETING,
      },
      stamp: {
        name: EXECUTIVE_NAME,
        title: EXECUTIVE_TITLE,
      },
      footer: ['THARAA MEDIA', 'رسالة رسمية']
    });
  };

  const inputClass = 'w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all';
  const labelClass = 'flex items-center gap-2 text-xs font-bold text-[#8b929f]';

  return (
    <div className="space-y-6 sm:space-y-8 pb-10" dir="rtl">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-orange-600/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
            <FileText size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-white">رسالة رسمية</h1>
            <p className="text-[#8b929f] text-sm">مراسلات THARAA MEDIA</p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleExport}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
        >
          <FileDown size={18} />
          تصدير PDF
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_390px] gap-6 items-start">
        <div className="bg-[#111318] border border-[#1f2127] rounded-2xl p-5 sm:p-7 space-y-6">
          <div className="flex items-center justify-between gap-3 border-b border-[#1f2127] pb-5">
            <div>
              <h2 className="text-xl font-black text-white">بيانات الخطاب</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className={labelClass}>
                <Building2 size={15} />
                الجهة المرسل إليها
              </label>
              <input
                value={formData.recipient}
                onChange={(event) => setFormData({ ...formData, recipient: event.target.value })}
                className={inputClass}
                placeholder="مثال: السادة / شركة ..."
              />
            </div>
            <div className="space-y-2">
              <label className={labelClass}>
                <Hash size={15} />
                رقم الإشارة
              </label>
              <input
                value={formData.reference}
                onChange={(event) => setFormData({ ...formData, reference: event.target.value })}
                className={inputClass}
                placeholder="اختياري"
              />
            </div>
            <div className="space-y-2">
              <label className={labelClass}>
                <CalendarDays size={15} />
                تاريخ الرسالة
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(event) => setFormData({ ...formData, date: event.target.value })}
                className={`${inputClass} text-right`}
              />
            </div>
            <div className="space-y-2">
              <label className={labelClass}>
                <Type size={15} />
                موضوع الرسالة
              </label>
              <input
                value={formData.subject}
                onChange={(event) => setFormData({ ...formData, subject: event.target.value })}
                className={inputClass}
                placeholder="مثال: طلب تعاون"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className={labelClass}>
              <AlignRight size={15} />
              نص الرسالة
            </label>
            <textarea
              value={formData.body}
              onChange={(event) => setFormData({ ...formData, body: event.target.value })}
              className="w-full min-h-[420px] bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-5 px-5 focus:border-orange-500 outline-none transition-all resize-y leading-8 text-[15px] sm:text-base"
              placeholder="اكتب نص الرسالة الرسمية هنا..."
            />
          </div>
        </div>

        <aside className="bg-white text-[#111318] rounded-2xl border border-[#e5e7eb] p-6 h-fit shadow-xl shadow-black/20">
          <div className="flex items-start justify-between gap-4 border-b border-[#e5e7eb] pb-4">
            <div className="text-right">
              <p className="text-lg font-black">رسالة رسمية</p>
              <p className="text-xs text-[#6b7280] mt-1">{displayDate}</p>
            </div>
            <div className="text-left" dir="ltr">
              <p className="text-sm font-black text-orange-600">THARAA</p>
              <p className="text-xs font-bold text-[#111318]">MEDIA</p>
            </div>
          </div>

          <div className="py-6 space-y-5 text-sm leading-7">
            <div>
              <p className="text-xs font-bold text-[#6b7280]">إلى</p>
              <p className="font-black text-base break-words">{formData.recipient || 'الجهة المرسل إليها'}</p>
            </div>

            <div className="rounded-xl border border-orange-200 bg-orange-50 px-4 py-4 text-center">
              <p className="text-xs font-black text-orange-600 mb-2">الموضوع</p>
              <h3 className="text-lg font-black leading-7 break-words">{formData.subject || 'عنوان الرسالة'}</h3>
            </div>

            <div className="space-y-3">
              <p className="font-black">{GREETING}</p>
              <p className="whitespace-pre-wrap leading-8 text-[#374151] break-words">
                {formData.body || 'نص الرسالة'}
              </p>
            </div>
          </div>

          <div className="border-t border-[#e5e7eb] pt-5 grid grid-cols-2 gap-4 items-end">
            <div>
              <p className="font-black">{EXECUTIVE_NAME}</p>
              <p className="text-xs text-[#6b7280] mt-1">{EXECUTIVE_TITLE}</p>
            </div>
            <div className="h-14 rounded-xl border border-dashed border-[#cbd5e1] flex items-center justify-center text-xs font-bold text-[#9ca3af]">
              الختم والتوقيع
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
