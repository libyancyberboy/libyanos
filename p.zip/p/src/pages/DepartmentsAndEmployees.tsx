
import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  MoreVertical, 
  Mail, 
  Phone, 
  Calendar,
  ShieldCheck,
  Plus,
  Trash2,
  Edit2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_DEPARTMENTS, MOCK_EMPLOYEES } from '../lib/store';
import { cn } from '../lib/utils';

export default function DepartmentsAndEmployees() {
  const [departments, setDepartments] = useState(MOCK_DEPARTMENTS);
  const [employees, setEmployees] = useState(MOCK_EMPLOYEES);

  const addDepartment = () => {
    const name = prompt("أدخل اسم القسم الجديد:");
    if (name) {
      const newDept = {
        id: `dept-${Date.now()}`,
        name,
        description: "قسم جديد مضاف حديثاً للمنظومة",
        createdAt: new Date().toISOString()
      };
      setDepartments([...departments, newDept]);
    }
  };

  const deleteDepartment = (id: string) => {
    if(confirm("هل أنت متأكد من حذف هذا القسم؟")) {
      setDepartments(departments.filter(d => d.id !== id));
    }
  };

  return (
    <div className="space-y-10">
      {/* Departments Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-sm font-bold flex items-center gap-2 text-white">
             <span className="text-orange-500 font-mono">/</span> الوحدات التنظيمية
          </h2>
          <button 
            onClick={addDepartment}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl hover:bg-orange-500 transition-all shadow-lg shadow-orange-500/20 active:scale-95"
          >
            <Plus size={16} />
            <span>وحدة جديدة</span>
          </button>
        </div>
        
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence initial={false}>
            {departments.map((dept, index) => (
              <motion.div 
                key={dept.id}
                layout
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.5, transition: { duration: 0.2 } }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="bg-[#111318] p-6 border border-[#1f2127] rounded-2xl hover:border-orange-500/40 transition-all group relative overflow-hidden technical-card"
              >
                <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                  <button onClick={() => deleteDepartment(dept.id)} className="p-1.5 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-all">
                    <Trash2 size={12} />
                  </button>
                </div>

                <div className="flex items-start justify-between mb-5">
                  <div className="w-12 h-12 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500 group-hover:bg-orange-500 group-hover:text-white transition-all duration-300">
                    <Building2 size={24} />
                  </div>
                  <div className="text-[10px] font-mono text-[#6b7280] font-bold tracking-tighter">{dept.id}</div>
                </div>
                
                <h3 className="text-base font-bold mb-2 text-white group-hover:text-orange-500 transition-colors">{dept.name}</h3>
                <p className="text-[11px] text-[#6b7280] mb-8 leading-relaxed italic font-medium opacity-80">/ {dept.description}</p>
                
                <div className="flex items-center justify-between pt-5 border-t border-[#1f2127]">
                  <div className="flex items-center gap-3">
                    <div className="flex -space-x-2 rtl:space-x-reverse">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="w-7 h-7 rounded-xl bg-[#16191e] border-2 border-[#111318] flex items-center justify-center text-[10px] text-orange-500 font-bold group-hover:border-orange-500/20 transition-all">
                          <Users size={12} />
                        </div>
                      ))}
                    </div>
                    <span className="text-[10px] font-bold font-mono text-orange-500 tracking-tighter">
                      {employees.filter(e => e.departmentId === dept.id).length}_NODES
                    </span>
                  </div>
                  <button className="text-[#6b7280] font-mono text-[10px] hover:text-orange-500 uppercase tracking-widest font-black transition-colors">Config</button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </section>

      {/* Employees Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-sm font-bold flex items-center gap-2 text-white">
             <span className="text-orange-500 font-mono">/</span> مصفوفة الكوادر
          </h2>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#1f2127] border border-[#1f2127] text-white text-xs font-bold rounded-xl hover:bg-[#111318] hover:border-orange-500/30 transition-all active:scale-95">
            <Plus size={16} />
            <span>إضافة كادر</span>
          </button>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#111318] border border-[#1f2127] rounded-2xl overflow-hidden shadow-2xl"
        >
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="bg-[#16191e] border-b border-[#1f2127]">
                  <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280] font-black">IDENTITY</th>
                  <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280] font-black">UNIT</th>
                  <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280] font-black">RANK</th>
                  <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280] font-black">SALARY_LYD</th>
                  <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280] font-black">INTERFACE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1f2127] text-xs font-medium">
                {employees.map((employee) => (
                  <tr key={employee.uid} className="hover:bg-orange-500/[0.02] transition-colors group">
                    <td className="px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#16191e] border border-[#1f2127] flex items-center justify-center text-orange-500 font-mono text-xs font-bold group-hover:border-orange-500/30 group-hover:text-white transition-all group-hover:bg-orange-600">
                          {employee.displayName.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-white group-hover:text-orange-500 transition-colors">{employee.displayName}</p>
                          <p className="text-[10px] text-[#6b7280] font-mono tracking-tight">{employee.uid}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-5 text-[#6b7280] font-mono text-[11px] font-bold">
                      {departments.find(d => d.id === employee.departmentId)?.name || 'OUT_OF_UNIT'}
                    </td>
                    <td className="px-6 py-5">
                      <span className={cn(
                        "text-[9px] font-mono font-black px-2 py-0.5 border rounded uppercase tracking-tighter",
                        employee.role === 'ADMIN' ? 'border-orange-500/50 text-orange-500 bg-orange-500/5' : 'border-[#1f2127] text-[#6b7280]'
                      )}>
                        {employee.role}
                      </span>
                    </td>
                    <td className="px-6 py-5 font-mono text-white font-bold">
                      {(employee.baseSalary || 0).toLocaleString()}
                    </td>
                    <td className="px-6 py-5">
                      <div className="flex items-center gap-2">
                        <button className="p-1.5 px-3 border border-[#1f2127] text-[#6b7280] text-[9px] font-black font-mono rounded-lg hover:text-orange-500 hover:border-orange-500/30 transition-all">MAIL</button>
                        <button className="p-1.5 px-3 border border-[#1f2127] text-[#6b7280] text-[9px] font-black font-mono rounded-lg hover:text-orange-500 hover:border-orange-500/30 transition-all">PERMS</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
