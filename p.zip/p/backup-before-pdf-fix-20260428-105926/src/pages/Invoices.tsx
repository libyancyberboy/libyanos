import React, { useMemo, useState } from 'react';
import { BadgeDollarSign, FileDown, Plus, ReceiptText, Stamp, Trash2 } from 'lucide-react';
import { saveArabicReportPdf } from '../lib/pdfArabic';

type InvoiceType = 'draft' | 'final';
type Currency = 'LYD' | 'USD';

interface InvoiceItem {
  id: string;
  description: string;
  quantity: string;
  price: string;
}

const createItem = (): InvoiceItem => ({
  id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
  description: '',
  quantity: '1',
  price: '0',
});

const currencyLabels: Record<Currency, string> = {
  LYD: 'دينار ليبي',
  USD: 'دولار أمريكي',
};

const invoiceTypeLabels: Record<InvoiceType, string> = {
  draft: 'مبدئية',
  final: 'نهائية',
};

const parseAmount = (value: string) => {
  const amount = Number.parseFloat(value);
  return Number.isFinite(amount) ? amount : 0;
};

const formatAmount = (value: number) =>
  value.toLocaleString('en-US', {
    minimumFractionDigits: value % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });

const safeFileName = (value: string) =>
  value.trim().replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, '-').slice(0, 60) || 'invoice';

export default function Invoices() {
  const [clientName, setClientName] = useState('');
  const [invoiceType, setInvoiceType] = useState<InvoiceType>('draft');
  const [currency, setCurrency] = useState<Currency>('LYD');
  const [issueDate, setIssueDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [items, setItems] = useState<InvoiceItem[]>([createItem()]);

  const normalizedItems = useMemo(() => (
    items.map(item => {
      const quantity = Math.max(0, parseAmount(item.quantity));
      const price = Math.max(0, parseAmount(item.price));
      return {
        ...item,
        quantity,
        price,
        total: quantity * price,
      };
    })
  ), [items]);

  const invoiceTotal = useMemo(
    () => normalizedItems.reduce((sum, item) => sum + item.total, 0),
    [normalizedItems]
  );

  const updateItem = (id: string, patch: Partial<InvoiceItem>) => {
    setItems(current => current.map(item => item.id === id ? { ...item, ...patch } : item));
  };

  const removeItem = (id: string) => {
    setItems(current => current.length === 1 ? current : current.filter(item => item.id !== id));
  };

  const handleExportPDF = async () => {
    const printableItems = normalizedItems.filter(item => item.description.trim() && item.quantity > 0);

    if (!clientName.trim()) {
      alert('اكتب اسم العميل قبل إصدار الفاتورة');
      return;
    }

    if (printableItems.length === 0) {
      alert('أضف صنف واحد على الأقل مع الكمية والسعر');
      return;
    }

    const dateText = new Date(issueDate).toLocaleDateString('ar-LY');
    const invoiceTitle = `فاتورة ${invoiceTypeLabels[invoiceType]}`;
    const currencyText = `${currencyLabels[currency]} (${currency})`;

    await saveArabicReportPdf({
      filename: `${invoiceType}_${safeFileName(clientName)}_${Date.now()}.pdf`,
      title: invoiceTitle,
      subtitle: 'THARAA MEDIA',
      meta: [
        { label: 'اسم العميل', value: clientName.trim() },
        { label: 'نوع الفاتورة', value: invoiceTypeLabels[invoiceType] },
        { label: 'العملة', value: currencyText },
        { label: 'التاريخ', value: dateText }
      ],
      summary: [
        { label: 'الإجمالي', value: `${formatAmount(invoiceTotal)} ${currency}`, tone: 'orange' }
      ],
      table: {
        title: 'الأصناف',
        head: ['الصنف', 'الكمية', 'السعر', 'الإجمالي'],
        rows: printableItems.map(item => [
          item.description.trim(),
          formatAmount(item.quantity),
          `${formatAmount(item.price)} ${currency}`,
          `${formatAmount(item.total)} ${currency}`,
        ]),
        rowsPerPage: 12
      },
      stamp: {
        name: 'محمود قنونو',
        title: 'المدير التنفيذي'
      },
      footer: ['الفاتورة تصدر بدون أرشفة داخل النظام']
    });
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-orange-600/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
            <ReceiptText size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-white">الفواتير</h1>
            <p className="text-[#6b7280] text-sm">إصدار فاتورة PDF</p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleExportPDF}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
        >
          <FileDown size={18} />
          تصدير PDF
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-6">
        <div className="space-y-6">
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-5 sm:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2 md:col-span-2">
                <label className="text-xs font-bold text-[#6b7280]">اسم العميل</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(event) => setClientName(event.target.value)}
                  className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
                  placeholder="اسم الشركة أو العميل"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-[#6b7280]">نوع الفاتورة</label>
                <div className="grid grid-cols-2 gap-2 bg-[#0a0b0d] border border-[#1f2127] rounded-xl p-1">
                  {(['draft', 'final'] as InvoiceType[]).map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setInvoiceType(type)}
                      className={`py-2.5 rounded-lg text-sm font-bold transition-all ${invoiceType === type ? 'bg-orange-600 text-white' : 'text-[#6b7280] hover:text-white'}`}
                    >
                      {invoiceTypeLabels[type]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-[#6b7280]">العملة</label>
                <div className="grid grid-cols-2 gap-2 bg-[#0a0b0d] border border-[#1f2127] rounded-xl p-1">
                  {(['LYD', 'USD'] as Currency[]).map(value => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setCurrency(value)}
                      className={`py-2.5 rounded-lg text-sm font-bold transition-all ${currency === value ? 'bg-orange-600 text-white' : 'text-[#6b7280] hover:text-white'}`}
                    >
                      {value === 'LYD' ? 'دينار ليبي' : 'دولار'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-[#6b7280]">تاريخ الفاتورة</label>
                <input
                  type="date"
                  value={issueDate}
                  onChange={(event) => setIssueDate(event.target.value)}
                  className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
                />
              </div>
            </div>
          </div>

          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-5 sm:p-8">
            <div className="flex items-center justify-between gap-3 mb-5">
              <h2 className="text-lg font-black text-white">الأصناف</h2>
              <button
                type="button"
                onClick={() => setItems(current => [...current, createItem()])}
                className="flex items-center gap-2 px-4 py-2 bg-[#0a0b0d] border border-orange-500/20 text-orange-500 rounded-xl font-bold hover:bg-orange-600 hover:text-white transition-all"
              >
                <Plus size={16} />
                صنف
              </button>
            </div>

            <div className="space-y-3">
              {items.map((item, index) => {
                const line = normalizedItems[index];
                return (
                  <div key={item.id} className="grid grid-cols-1 lg:grid-cols-[1fr_110px_140px_140px_44px] gap-3 bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-3">
                    <input
                      type="text"
                      value={item.description}
                      onChange={(event) => updateItem(item.id, { description: event.target.value })}
                      className="w-full bg-[#111318] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
                      placeholder="وصف الصنف أو الخدمة"
                    />
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.quantity}
                      onChange={(event) => updateItem(item.id, { quantity: event.target.value })}
                      className="w-full bg-[#111318] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
                      placeholder="الكمية"
                    />
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.price}
                      onChange={(event) => updateItem(item.id, { price: event.target.value })}
                      className="w-full bg-[#111318] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
                      placeholder="السعر"
                    />
                    <div className="flex items-center justify-between bg-[#111318] border border-[#1f2127] rounded-xl py-3 px-4">
                      <span className="text-[#6b7280] text-xs">{currency}</span>
                      <span className="text-white font-black">{formatAmount(line.total)}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeItem(item.id)}
                      disabled={items.length === 1}
                      className="h-12 flex items-center justify-center text-red-500/70 hover:text-red-500 disabled:opacity-30 disabled:hover:text-red-500/70 transition-all"
                      title="حذف الصنف"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <aside className="space-y-6">
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-orange-600/10 text-orange-500 flex items-center justify-center">
                <BadgeDollarSign size={20} />
              </div>
              <h2 className="text-lg font-black text-white">الإجمالي</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-[#1f2127] pb-3">
                <span className="text-[#6b7280] text-sm">نوع الفاتورة</span>
                <span className="text-white font-bold">{invoiceTypeLabels[invoiceType]}</span>
              </div>
              <div className="flex items-center justify-between border-b border-[#1f2127] pb-3">
                <span className="text-[#6b7280] text-sm">العملة</span>
                <span className="text-white font-bold">{currency}</span>
              </div>
              <div className="bg-orange-600 rounded-2xl p-5 text-white">
                <p className="text-white/70 text-xs mb-1">قيمة الفاتورة</p>
                <p className="text-4xl font-black">{formatAmount(invoiceTotal)}</p>
                <p className="text-white/80 text-sm mt-1">{currencyLabels[currency]}</p>
              </div>
            </div>
          </div>

          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-[#0a0b0d] text-orange-500 flex items-center justify-center">
                <Stamp size={20} />
              </div>
              <h2 className="text-lg font-black text-white">الختم والتوقيع</h2>
            </div>
            <div className="border border-dashed border-[#343842] rounded-2xl p-5 min-h-[140px] flex flex-col justify-end">
              <p className="text-white font-black">محمود قنونو</p>
              <p className="text-[#6b7280] text-sm">المدير التنفيذي</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
