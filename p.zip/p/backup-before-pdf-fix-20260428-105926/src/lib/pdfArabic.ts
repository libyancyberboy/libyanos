import { jsPDF } from 'jspdf';

const FONT_NAME = 'ThmanyahSans';
const FONT_FILE = 'thmanyahsans-Regular.otf';
let fontBase64Cache: string | null = null;
let svgFontCssCache: string | null = null;

type PdfCell = string | number | null | undefined;

interface ArabicReportTable {
  title?: string;
  head: string[];
  rows: PdfCell[][];
  rowsPerPage?: number;
}

interface ArabicReportOptions {
  filename: string;
  title: string;
  subtitle?: string;
  meta?: Array<string | { label: string; value: PdfCell }>;
  summary?: Array<{ label: string; value: PdfCell; tone?: 'green' | 'orange' | 'dark' }>;
  image?: {
    dataUrl: string;
    caption?: string;
  };
  contentHtml?: string;
  table?: ArabicReportTable;
  tables?: ArabicReportTable[];
  footer?: string[];
  stamp?: {
    name: string;
    title: string;
  };
}

const PAGE_WIDTH = 794;
const PAGE_HEIGHT = 1123;
const PAGE_MARGIN = 52;
const CONTENT_WIDTH = PAGE_WIDTH - PAGE_MARGIN * 2;
const FONT_FAMILY = '"ThmanyahSansPdf", "Tahoma", "Arial", sans-serif';

const arrayBufferToBase64 = (buffer: ArrayBuffer) => {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;

  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }

  return btoa(binary);
};

const escapeXml = (value: PdfCell) =>
  String(value ?? '-')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');

const chunkRows = (rows: PdfCell[][], size: number) => {
  if (!rows.length) return [[]];
  const chunks: PdfCell[][][] = [];
  for (let index = 0; index < rows.length; index += size) {
    chunks.push(rows.slice(index, index + size));
  }
  return chunks;
};

const getSvgFontCss = async () => {
  if (svgFontCssCache !== null) return svgFontCssCache;

  try {
    const [regular, bold] = await Promise.all([
      fetch('/fonts/thmanyahsans-Regular.woff2').then(response => response.arrayBuffer()),
      fetch('/fonts/thmanyahsans-Bold.woff2').then(response => response.arrayBuffer()),
    ]);

    svgFontCssCache = `
      @font-face {
        font-family: "ThmanyahSansPdf";
        src: url(data:font/woff2;base64,${arrayBufferToBase64(regular)}) format("woff2");
        font-weight: 400;
      }
      @font-face {
        font-family: "ThmanyahSansPdf";
        src: url(data:font/woff2;base64,${arrayBufferToBase64(bold)}) format("woff2");
        font-weight: 800;
      }
    `;
  } catch (error) {
    console.warn('PDF font loading failed, falling back to system Arabic fonts.', error);
    svgFontCssCache = '';
  }

  return svgFontCssCache;
};

const getImageFromSvg = async (svg: string) => {
  const blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      const timer = window.setTimeout(() => reject(new Error('PDF render timeout')), 8000);
      img.onload = () => {
        window.clearTimeout(timer);
        resolve(img);
      };
      img.onerror = () => {
        window.clearTimeout(timer);
        reject(new Error('PDF render failed'));
      };
      img.src = url;
    });

    const canvas = document.createElement('canvas');
    const scale = 2;
    canvas.width = PAGE_WIDTH * scale;
    canvas.height = PAGE_HEIGHT * scale;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas is not available.');

    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.scale(scale, scale);
    context.drawImage(image, 0, 0, PAGE_WIDTH, PAGE_HEIGHT);

    return canvas.toDataURL('image/jpeg', 0.94);
  } finally {
    URL.revokeObjectURL(url);
  }
};

const extractImageFromContent = (contentHtml?: string) => {
  if (!contentHtml) return null;
  const imageMatch = contentHtml.match(/src="([^"]+)"/);
  const captionMatch = contentHtml.match(/<p>(.*?)<\/p>/);
  return imageMatch ? {
    dataUrl: imageMatch[1],
    caption: captionMatch?.[1]?.replace(/<[^>]+>/g, '')
  } : null;
};

const wrapText = (value: PdfCell, maxChars: number) => {
  const text = String(value ?? '-').replace(/\s+/g, ' ').trim() || '-';
  const words = text.split(' ');
  const lines: string[] = [];
  let current = '';

  words.forEach(word => {
    if (word.length > maxChars) {
      if (current) {
        lines.push(current);
        current = '';
      }
      for (let index = 0; index < word.length; index += maxChars) {
        lines.push(word.slice(index, index + maxChars));
      }
      return;
    }

    const next = current ? `${current} ${word}` : word;
    if (next.length > maxChars && current) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
  });

  if (current) lines.push(current);
  return lines.slice(0, 4);
};

const textSvg = (
  value: PdfCell,
  x: number,
  y: number,
  options: {
    size?: number;
    weight?: number;
    color?: string;
    anchor?: 'start' | 'middle' | 'end';
    maxChars?: number;
    lineHeight?: number;
  } = {}
) => {
  const size = options.size || 16;
  const lineHeight = options.lineHeight || Math.round(size * 1.35);
  const lines = wrapText(value, options.maxChars || 80);

  return lines.map((line, index) => `
    <text
      x="${x}"
      y="${y + index * lineHeight}"
      font-size="${size}"
      font-weight="${options.weight || 400}"
      fill="${options.color || '#111318'}"
      text-anchor="${options.anchor || 'end'}"
      direction="rtl"
      unicode-bidi="plaintext"
      style="font-family: ${FONT_FAMILY};"
    >${escapeXml(line)}</text>
  `).join('');
};

const rectSvg = (
  x: number,
  y: number,
  width: number,
  height: number,
  options: { fill?: string; stroke?: string; radius?: number; strokeWidth?: number; dash?: string } = {}
) => `
  <rect
    x="${x}"
    y="${y}"
    width="${width}"
    height="${height}"
    rx="${options.radius ?? 10}"
    fill="${options.fill || 'none'}"
    stroke="${options.stroke || 'none'}"
    stroke-width="${options.strokeWidth || 1}"
    ${options.dash ? `stroke-dasharray="${options.dash}"` : ''}
  />
`;

const drawMeta = (meta: ArabicReportOptions['meta'], startY: number) => {
  if (!meta?.length) return { svg: '', y: startY };

  let svg = '';
  const gap = 10;
  const width = (CONTENT_WIDTH - gap) / 2;
  const height = 48;

  meta.forEach((item, index) => {
    const col = index % 2;
    const row = Math.floor(index / 2);
    const x = PAGE_MARGIN + col * (width + gap);
    const y = startY + row * (height + gap);
    svg += rectSvg(x, y, width, height, { fill: '#ffffff', stroke: '#d9dde5', radius: 12 });

    if (typeof item === 'string') {
      svg += textSvg(item, x + width - 14, y + 30, { size: 15, maxChars: 35 });
    } else {
      svg += textSvg(item.label, x + width - 14, y + 20, { size: 12, color: '#717987', maxChars: 20 });
      svg += textSvg(item.value, x + width - 14, y + 38, { size: 15, weight: 800, maxChars: 28 });
    }
  });

  return {
    svg,
    y: startY + Math.ceil(meta.length / 2) * (height + gap) + 8
  };
};

const drawSummary = (summary: ArabicReportOptions['summary'], startY: number) => {
  if (!summary?.length) return { svg: '', y: startY };

  let svg = '';
  const gap = 10;
  const columns = summary.length <= 2 ? summary.length : 3;
  const width = (CONTENT_WIDTH - gap * (columns - 1)) / columns;
  const height = 76;

  summary.forEach((item, index) => {
    const col = index % columns;
    const row = Math.floor(index / columns);
    const x = PAGE_MARGIN + col * (width + gap);
    const y = startY + row * (height + gap);
    const fill = item.tone === 'green' ? '#15803d' : item.tone === 'orange' ? '#f97316' : '#111318';
    svg += rectSvg(x, y, width, height, { fill, radius: 14 });
    svg += textSvg(item.label, x + width - 14, y + 25, { size: 13, color: '#ffffff', maxChars: 18 });
    svg += textSvg(item.value, x + width - 14, y + 56, { size: 22, weight: 800, color: '#ffffff', maxChars: 18 });
  });

  return {
    svg,
    y: startY + Math.ceil(summary.length / columns) * (height + gap) + 12
  };
};

const drawImageBlock = (image: ArabicReportOptions['image'] | null | undefined, startY: number) => {
  if (!image?.dataUrl) return { svg: '', y: startY };

  const cardWidth = 430;
  const cardHeight = 430;
  const x = PAGE_MARGIN + (CONTENT_WIDTH - cardWidth) / 2;
  let svg = rectSvg(x, startY, cardWidth, cardHeight, { fill: '#f7f8fa', stroke: '#d9dde5', radius: 24 });
  svg += `<image href="${escapeXml(image.dataUrl)}" x="${x + 65}" y="${startY + 32}" width="300" height="300" preserveAspectRatio="xMidYMid meet" />`;
  if (image.caption) {
    svg += textSvg(image.caption, PAGE_WIDTH / 2, startY + 376, { size: 19, weight: 800, anchor: 'middle', maxChars: 36 });
  }

  return { svg, y: startY + cardHeight + 18 };
};

const getColumnWidths = (columnCount: number) => {
  if (columnCount <= 4) return Array(columnCount).fill(CONTENT_WIDTH / columnCount);
  if (columnCount === 5) return [130, 135, 125, 140, 160];
  if (columnCount === 6) return [112, 112, 112, 112, 112, 130];
  if (columnCount === 7) return [95, 105, 95, 95, 95, 95, 110];
  if (columnCount === 8) return [84, 90, 84, 84, 84, 84, 84, 96];
  return Array(columnCount).fill(CONTENT_WIDTH / columnCount);
};

const drawTable = (table: ArabicReportTable | null, rows: PdfCell[][], startY: number) => {
  if (!table) return { svg: '', y: startY };

  const columnWidths = getColumnWidths(table.head.length);
  const fontSize = table.head.length > 7 ? 12 : table.head.length > 5 ? 13 : 15;
  const maxChars = table.head.length > 7 ? 10 : table.head.length > 5 ? 13 : 18;
  const rowBase = table.head.length > 7 ? 34 : 40;
  let y = startY;
  let svg = '';

  if (table.title) {
    svg += textSvg(table.title, PAGE_WIDTH - PAGE_MARGIN, y + 4, { size: 20, weight: 800, maxChars: 45 });
    y += 26;
  }

  const drawRow = (cells: PdfCell[], rowY: number, isHead = false) => {
    let rowSvg = '';
    let x = PAGE_WIDTH - PAGE_MARGIN;
    const rowLines = cells.map(cell => wrapText(cell, maxChars));
    const lineCount = Math.max(...rowLines.map(lines => lines.length), 1);
    const rowHeight = Math.max(rowBase, 18 + lineCount * Math.round(fontSize * 1.25));

    cells.forEach((cell, index) => {
      const width = columnWidths[index] || columnWidths[columnWidths.length - 1];
      x -= width;
      rowSvg += rectSvg(x, rowY, width, rowHeight, {
        fill: isHead ? '#f97316' : '#ffffff',
        stroke: isHead ? '#f97316' : '#d9dde5',
        radius: 0
      });

      const lines = rowLines[index];
      lines.forEach((line, lineIndex) => {
        rowSvg += textSvg(line, x + width - 8, rowY + 23 + lineIndex * Math.round(fontSize * 1.25), {
          size: fontSize,
          weight: isHead ? 800 : 400,
          color: isHead ? '#ffffff' : '#111318',
          maxChars,
        });
      });
    });

    return { svg: rowSvg, height: rowHeight };
  };

  const head = drawRow(table.head, y, true);
  svg += head.svg;
  y += head.height;

  if (!rows.length) {
    const empty = drawRow(['لا توجد بيانات', ...Array(table.head.length - 1).fill('')], y);
    svg += empty.svg;
    y += empty.height;
  } else {
    rows.forEach((row) => {
      const fullRow = table.head.map((_, index) => row[index] ?? '-');
      const body = drawRow(fullRow, y);
      svg += body.svg;
      y += body.height;
    });
  }

  return { svg, y: y + 14 };
};

const drawStamp = (stamp: ArabicReportOptions['stamp'], startY: number) => {
  if (!stamp) return '';

  const tableX = PAGE_MARGIN;
  const tableY = Math.max(startY, 888);
  const totalWidth = CONTENT_WIDTH;
  const headHeight = 38;
  const bodyHeight = 112;
  const colWidth = totalWidth / 3;
  let svg = '';

  svg += textSvg('الختم والتوقيع', PAGE_WIDTH - PAGE_MARGIN, tableY - 14, { size: 18, weight: 800 });

  ['الاعتماد', 'التوقيع', 'الختم'].forEach((label, index) => {
    const x = tableX + index * colWidth;
    svg += rectSvg(x, tableY, colWidth, headHeight, { fill: '#111318', stroke: '#111318', radius: 0 });
    svg += textSvg(label, x + colWidth - 16, tableY + 25, { size: 15, weight: 800, color: '#ffffff', maxChars: 12 });
  });

  for (let index = 0; index < 3; index += 1) {
    const x = tableX + index * colWidth;
    svg += rectSvg(x, tableY + headHeight, colWidth, bodyHeight, { fill: '#ffffff', stroke: '#d9dde5', radius: 0 });
  }

  svg += textSvg(stamp.name, tableX + colWidth - 18, tableY + headHeight + 42, { size: 21, weight: 800, maxChars: 20 });
  svg += textSvg(stamp.title, tableX + colWidth - 18, tableY + headHeight + 68, { size: 16, color: '#5f6673', maxChars: 20 });
  svg += `<line x1="${tableX + 18}" y1="${tableY + headHeight + 90}" x2="${tableX + colWidth - 18}" y2="${tableY + headHeight + 90}" stroke="#111318" stroke-width="2" />`;
  svg += textSvg('مساحة التوقيع', tableX + colWidth * 2 - 22, tableY + headHeight + 88, { size: 16, color: '#717987', maxChars: 18 });
  svg += textSvg('مساحة الختم', tableX + totalWidth - 22, tableY + headHeight + 88, { size: 16, color: '#717987', maxChars: 18 });

  return svg;
};

const buildPageSvg = async (
  options: ArabicReportOptions,
  table: ArabicReportTable | null,
  rows: PdfCell[][],
  pageNumber: number,
  totalPages: number,
  showStamp: boolean
) => {
  const fontCss = await getSvgFontCss();
  const footer = options.footer || [];
  const image = options.image || extractImageFromContent(options.contentHtml);
  let y = 52;
  let body = '';

  body += textSvg(options.title, PAGE_WIDTH - PAGE_MARGIN, y + 10, { size: 31, weight: 800, maxChars: 28 });
  if (options.subtitle) {
    body += textSvg(options.subtitle, PAGE_WIDTH - PAGE_MARGIN, y + 42, { size: 17, color: '#5f6673', maxChars: 45 });
  }
  body += `<text x="${PAGE_MARGIN}" y="${y + 16}" font-size="21" font-weight="800" fill="#f97316" text-anchor="start" direction="ltr" style="font-family: ${FONT_FAMILY};">THARAA MEDIA</text>`;
  body += `<line x1="${PAGE_MARGIN}" y1="${y + 66}" x2="${PAGE_WIDTH - PAGE_MARGIN}" y2="${y + 66}" stroke="#f97316" stroke-width="4" />`;
  y += 92;

  const meta = drawMeta(options.meta, y);
  body += meta.svg;
  y = meta.y;

  const summary = drawSummary(options.summary, y);
  body += summary.svg;
  y = summary.y;

  const imageBlock = drawImageBlock(image, y);
  body += imageBlock.svg;
  y = imageBlock.y;

  const tableBlock = drawTable(table, rows, y);
  body += tableBlock.svg;
  y = tableBlock.y;

  if (showStamp) {
    body += drawStamp(options.stamp, y);
  }

  body += `<line x1="${PAGE_MARGIN}" y1="1064" x2="${PAGE_WIDTH - PAGE_MARGIN}" y2="1064" stroke="#e5e7eb" stroke-width="1" />`;
  body += textSvg(footer.join(' · '), PAGE_WIDTH - PAGE_MARGIN, 1086, { size: 12, color: '#717987', maxChars: 60 });
  body += textSvg(`صفحة ${pageNumber} من ${totalPages}`, PAGE_MARGIN, 1086, { size: 12, color: '#717987', anchor: 'start', maxChars: 20 });

  return `
    <svg xmlns="http://www.w3.org/2000/svg" width="${PAGE_WIDTH}" height="${PAGE_HEIGHT}" viewBox="0 0 ${PAGE_WIDTH} ${PAGE_HEIGHT}">
      <defs>
        <style>
          ${fontCss}
          text { dominant-baseline: alphabetic; }
        </style>
      </defs>
      <rect width="100%" height="100%" fill="#ffffff" />
      ${body}
    </svg>
  `;
};

export const setupArabicPdf = async (doc: jsPDF) => {
  if (!fontBase64Cache) {
    const response = await fetch(`/fonts/${FONT_FILE}`);
    if (!response.ok) {
      throw new Error('Unable to load Arabic PDF font.');
    }
    const buffer = await response.arrayBuffer();
    fontBase64Cache = arrayBufferToBase64(buffer);
  }

  doc.addFileToVFS(FONT_FILE, fontBase64Cache);
  doc.addFont(FONT_FILE, FONT_NAME, 'normal');
  doc.setFont(FONT_NAME, 'normal');
  doc.setLanguage('ar');
  doc.setR2L(true);

  if (typeof (doc as any).viewerPreferences === 'function') {
    (doc as any).viewerPreferences({ Direction: 'R2L' });
  }

  return FONT_NAME;
};

export const arabicText = (doc: jsPDF, text: string, x: number, y: number, options: Record<string, any> = {}) => {
  doc.text(String(text || ''), x, y, { align: 'right', ...options });
};

export const arabicTableStyles = (fontName: string) => ({
  styles: { font: fontName, fontSize: 8, halign: 'right' as const, cellPadding: 2.5 },
  headStyles: { font: fontName, fillColor: [249, 115, 22] as [number, number, number], halign: 'right' as const, textColor: [255, 255, 255] as [number, number, number] },
  bodyStyles: { font: fontName, halign: 'right' as const },
});

export const saveArabicReportPdf = async (options: ArabicReportOptions) => {
  try {
    const doc = new jsPDF('p', 'mm', 'a4');
    const tables = options.tables || (options.table ? [options.table] : []);
    const pageSpecs: Array<{ table: ArabicReportTable | null; rows: PdfCell[][] }> = [];

    if (tables.length) {
      tables.forEach(table => {
        const rowsPerPage = table.rowsPerPage || (table.head.length > 7 ? 14 : table.head.length > 5 ? 17 : 20);
        chunkRows(table.rows, rowsPerPage).forEach(rows => pageSpecs.push({ table, rows }));
      });
    } else {
      pageSpecs.push({ table: null, rows: [] });
    }

    for (let index = 0; index < pageSpecs.length; index += 1) {
      if (index > 0) doc.addPage();
      const page = pageSpecs[index];
      const svg = await buildPageSvg(
        options,
        page.table,
        page.rows,
        index + 1,
        pageSpecs.length,
        Boolean(options.stamp && index === pageSpecs.length - 1)
      );
      const imageData = await getImageFromSvg(svg);
      doc.addImage(imageData, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
    }

    doc.save(options.filename);
  } catch (error) {
    console.error('PDF export failed:', error);
    alert('تعذر تصدير PDF. جرّب مرة ثانية أو افتح الصفحة من متصفح Chrome.');
  }
};
