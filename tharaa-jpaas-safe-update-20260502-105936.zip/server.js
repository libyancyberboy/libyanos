const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const path = require("path");
const { existsSync, mkdirSync, readFileSync, writeFileSync } = require("fs");
const { randomBytes } = require("crypto");
const dotenv = require("dotenv");

dotenv.config({ quiet: true });

const CONFIG_FILE = process.env.THARAA_CONFIG_FILE || path.join(__dirname, "tharaa.config.json");

function loadDeploymentConfig() {
  if (!existsSync(CONFIG_FILE)) return {};

  try {
    return JSON.parse(readFileSync(CONFIG_FILE, "utf8"));
  } catch (error) {
    console.warn(`[CONFIG] Could not read ${CONFIG_FILE}. Falling back to environment/defaults.`);
    return {};
  }
}

const appConfig = loadDeploymentConfig();

function toNumber(value, fallback) {
  const numericValue = Number(value);
  return Number.isFinite(numericValue) ? numericValue : fallback;
}

let COMPANY_NAME = process.env.COMPANY_NAME || appConfig.app?.name || "THARA PRODUCTION";
let PUBLIC_URL = process.env.APP_URL || appConfig.app?.publicUrl || "";
const JWT_SECRET = process.env.JWT_SECRET || appConfig.security?.jwtSecret || "erp_production_secret_2025";
const SESSION_HOURS = toNumber(process.env.SESSION_HOURS || appConfig.security?.sessionHours, 12);
const PORT = toNumber(process.env.PORT || appConfig.app?.port, 3000);
const DATA_DIR = process.env.DATA_DIR || appConfig.database?.jsonDataDir || path.join(__dirname, "data");
const DATA_FILE = path.resolve(__dirname, DATA_DIR, "db.json");
let DATABASE_MODE = process.env.DATABASE_MODE || appConfig.database?.mode || "json";
let DATABASE_URL = process.env.DATABASE_URL || appConfig.database?.url || "";
let DATABASE_API_URL = process.env.DATABASE_API_URL || appConfig.database?.apiUrl || "";
let DATABASE_API_KEY = process.env.DATABASE_API_KEY || appConfig.database?.apiKey || "";
let RESET_SYSTEM_CODE = process.env.RESET_SYSTEM_CODE || appConfig.security?.resetCode || "tharaproduction";
let pgPool = null;
let saveQueue = Promise.resolve();

let COMPANY_LAT = toNumber(process.env.COMPANY_LAT || appConfig.attendance?.companyLat, 32.8872);
let COMPANY_LNG = toNumber(process.env.COMPANY_LNG || appConfig.attendance?.companyLng, 13.1913);
let MAX_DISTANCE_METERS = toNumber(process.env.MAX_DISTANCE_METERS || appConfig.attendance?.maxDistanceMeters, 150);
let MIN_INTERVAL_MS = toNumber(process.env.MIN_ATTENDANCE_INTERVAL_SECONDS || appConfig.attendance?.minIntervalSeconds, 120) * 1000;
let ATTENDANCE_TIME_ZONE = process.env.ATTENDANCE_TIME_ZONE || appConfig.attendance?.timeZone || "Africa/Tripoli";
let ATTENDANCE_GRACE_MINUTES = toNumber(process.env.ATTENDANCE_GRACE_MINUTES || appConfig.attendance?.graceMinutes, 10);

const USER_ROLES = ["ADMIN", "MANAGER", "EMPLOYEE", "FREELANCER"];
const WORKER_ROLES = ["EMPLOYEE", "FREELANCER"];

function normalizeUserRole(value) {
  const raw = String(value || "EMPLOYEE").trim();
  const upper = raw.toUpperCase();
  const compact = raw.replace(/\s+/g, "").toLowerCase();

  if (upper === "FREELANCER" || upper === "FREELANCE" || compact.includes("فريلانسر") || compact.includes("فريلانس")) {
    return "FREELANCER";
  }
  if (upper === "EMPLOYEE" || compact === "موظف") {
    return "EMPLOYEE";
  }
  if (upper === "MANAGER" || compact === "مدير") {
    return "MANAGER";
  }
  if (upper === "ADMIN" || compact === "ادمن" || compact === "أدمن" || compact === "مسؤول") {
    return "ADMIN";
  }

  return upper;
}

function normalizeAvatarDataUrl(value) {
  const avatar = String(value || "").trim();
  if (!avatar) return "";
  if (avatar.length > 900000) return null;
  if (!/^data:image\/(png|jpe?g|webp);base64,[a-z0-9+/=]+$/i.test(avatar)) return null;
  return avatar;
}

function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function createDefaultDb() {
  return {
    users: [
      {
        id: "admin_root",
        username: appConfig.admin?.username || "admin",
        password: bcrypt.hashSync(appConfig.admin?.password || "admin", 10),
        role: "ADMIN",
        departmentId: "mgmt",
        salary: toNumber(appConfig.admin?.salary, 10000),
        accessCode: appConfig.admin?.password || "admin",
        isSupplier: false,
        attendanceStartTime: "09:00",
        attendanceEndTime: "17:00",
        createdAt: new Date().toISOString()
      }
    ],
    departments: [
      {
        id: "mgmt",
        name: "الإدارة العامة",
        description: "وحدة القيادة العليا",
        createdAt: new Date().toISOString(),
        config: { allowRemoteAttendance: false, budgetLimit: 0 }
      }
    ],
    finance: [],
    supplierInvoices: [],
    payroll: [],
    advanceRequests: [],
    tasks: [],
    attendance: [],
    qrTokens: [
      { token: "ROOT_QR_2025", departmentId: "mgmt", isActive: true }
    ],
    notifications: []
  };
}

function normalizeDb(input = {}) {
  const defaults = createDefaultDb();
  const users = (Array.isArray(input.users) && input.users.length > 0 ? input.users : defaults.users)
    .map(user => ({ ...user, accessCode: user.accessCode || "", isSupplier: Boolean(user.isSupplier) }));
  const userById = new Map(users.map(user => [user.id, user]));
  const finance = (Array.isArray(input.finance) ? input.finance : defaults.finance)
    .map(entry => {
      const employeeId = isEmployeeFinanceCategory(entry.category) ? (entry.employeeId || null) : null;
      const employee = employeeId ? userById.get(employeeId) : null;
      return {
        ...entry,
        departmentId: employee?.departmentId || entry.departmentId || null,
        employeeId
      };
    });

  return {
    users,
    departments: Array.isArray(input.departments) && input.departments.length > 0 ? input.departments : defaults.departments,
    finance,
    supplierInvoices: Array.isArray(input.supplierInvoices) ? input.supplierInvoices : defaults.supplierInvoices,
    payroll: Array.isArray(input.payroll) ? input.payroll : defaults.payroll,
    advanceRequests: Array.isArray(input.advanceRequests) ? input.advanceRequests : defaults.advanceRequests,
    tasks: Array.isArray(input.tasks) ? input.tasks : defaults.tasks,
    attendance: Array.isArray(input.attendance) ? input.attendance : defaults.attendance,
    qrTokens: Array.isArray(input.qrTokens) && input.qrTokens.length > 0 ? input.qrTokens : defaults.qrTokens,
    notifications: Array.isArray(input.notifications) ? input.notifications : defaults.notifications,
  };
}

function isPostgresMode() {
  return ["postgres", "postgresql", "supabase"].includes(String(DATABASE_MODE || "").toLowerCase()) && Boolean(DATABASE_URL);
}

function postgresSslConfig() {
  const lowerUrl = String(DATABASE_URL || "").toLowerCase();
  if (lowerUrl.includes("sslmode=require") || lowerUrl.includes("supabase.co") || lowerUrl.includes("pooler.supabase.com")) {
    return { rejectUnauthorized: false };
  }
  return false;
}

function loadJsonDb() {
  mkdirSync(path.dirname(DATA_FILE), { recursive: true });

  if (!existsSync(DATA_FILE)) {
    const freshDb = createDefaultDb();
    writeFileSync(DATA_FILE, JSON.stringify(freshDb, null, 2), "utf8");
    return freshDb;
  }

  try {
    return normalizeDb(JSON.parse(readFileSync(DATA_FILE, "utf8")));
  } catch (error) {
    const backupPath = path.join(path.dirname(DATA_FILE), `db.corrupt-${Date.now()}.json`);
    writeFileSync(backupPath, readFileSync(DATA_FILE, "utf8"), "utf8");
    const freshDb = createDefaultDb();
    writeFileSync(DATA_FILE, JSON.stringify(freshDb, null, 2), "utf8");
    return freshDb;
  }
}

async function loadPostgresDb() {
  let Pool;
  try {
    ({ Pool } = require("pg"));
  } catch (error) {
    console.error("[DATABASE] PostgreSQL mode needs the pg package. Run npm install before starting.");
    throw error;
  }

  pgPool = new Pool({
    connectionString: DATABASE_URL,
    ssl: postgresSslConfig(),
    max: 3,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
  });

  await pgPool.query(`
    create table if not exists public.tharaa_app_state (
      id text primary key,
      data jsonb not null,
      updated_at timestamptz not null default now()
    )
  `);

  const result = await pgPool.query("select data from public.tharaa_app_state where id = $1", ["main"]);
  if (result.rows[0]?.data) {
    return normalizeDb(result.rows[0].data);
  }

  const initialDb = existsSync(DATA_FILE) ? loadJsonDb() : createDefaultDb();
  await pgPool.query(
    `insert into public.tharaa_app_state (id, data, updated_at)
     values ($1, $2::jsonb, now())
     on conflict (id) do update set data = excluded.data, updated_at = now()`,
    ["main", JSON.stringify(normalizeDb(initialDb))]
  );
  return normalizeDb(initialDb);
}

async function loadDb() {
  if (isPostgresMode()) {
    console.log("[DATABASE] Using PostgreSQL/Supabase storage.");
    return loadPostgresDb();
  }

  console.log("[DATABASE] Using local JSON storage.");
  return loadJsonDb();
}

let db = createDefaultDb();

function saveDb() {
  const snapshot = JSON.stringify(normalizeDb(db));

  if (isPostgresMode() && pgPool) {
    saveQueue = saveQueue
      .then(() => pgPool.query(
        `insert into public.tharaa_app_state (id, data, updated_at)
         values ($1, $2::jsonb, now())
         on conflict (id) do update set data = excluded.data, updated_at = now()`,
        ["main", snapshot]
      ))
      .catch(error => {
        console.error("[DATABASE] PostgreSQL save failed:", error.message);
      });
    return;
  }

  mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  writeFileSync(DATA_FILE, JSON.stringify(JSON.parse(snapshot), null, 2), "utf8");
}

function toAmount(value) {
  const amount = Number(value);
  return Number.isFinite(amount) ? amount : 0;
}

function isSalaryPayment(category = "") {
  const text = String(category || "");
  return text.includes("راتب") || text.includes("Salary") || text.includes("استلام راتب") || text.includes("صرف راتب");
}

function isBonusPayment(category = "") {
  const text = String(category || "");
  return text.includes("مكافأة") || text.includes("Bonus") || text.includes("إضافة");
}

function isEmployeeFinanceCategory(category = "") {
  const text = String(category || "");
  return text === "خصم" ||
    text === "سلفة" ||
    text.includes("سلفة") ||
    text.includes("خصم") ||
    text.includes("موظف") ||
    text.includes("صرف قيمة") ||
    text.includes("دفعة") ||
    isSalaryPayment(text) ||
    isBonusPayment(text);
}

function enforceEmployeeFinanceDepartment(entry) {
  if (!entry?.employeeId) return entry;
  const employee = db.users.find(user => user.id === entry.employeeId);
  if (employee?.departmentId) {
    entry.departmentId = employee.departmentId;
  }
  return entry;
}

function getEmployeeLedger(employeeId) {
  const employee = db.users.find(user => user.id === employeeId);
  if (!employee) return null;

  const entries = db.finance.filter(entry => entry.employeeId === employeeId);
  const additions = entries
    .filter(entry => entry.type === "income" || (entry.type === "expense" && isBonusPayment(entry.category)))
    .reduce((sum, entry) => sum + toAmount(entry.amount), 0);
  const deductions = entries
    .filter(entry => entry.type === "expense" && !isSalaryPayment(entry.category) && !isBonusPayment(entry.category))
    .reduce((sum, entry) => sum + toAmount(entry.amount), 0);
  const paid = entries
    .filter(entry => entry.type === "expense" && isSalaryPayment(entry.category))
    .reduce((sum, entry) => sum + toAmount(entry.amount), 0);
  const balance = Math.max(0, toAmount(employee.salary) + additions - deductions - paid);

  return {
    employee,
    salary: toAmount(employee.salary),
    additions,
    deductions,
    paid,
    balance,
    entries
  };
}

function withEmployeeName(record) {
  const employee = db.users.find(user => user.id === record.employeeId);
  const { receiptPdf, ...safeRecord } = record;
  return {
    ...safeRecord,
    employeeName: employee?.username || record.employeeName || "غير معروف",
    departmentId: employee?.departmentId || record.departmentId || null
  };
}

function createPendingPayrollFromSalaryEntry(entry) {
  if (!entry?.id || entry.type !== "expense" || !entry.employeeId || !isSalaryPayment(entry.category)) return null;

  const employee = db.users.find(user => user.id === entry.employeeId);
  if (!employee || employee.role === "ADMIN") return null;

  enforceEmployeeFinanceDepartment(entry);

  const existing = db.payroll.find(item =>
    item.id === entry.payrollId ||
    item.financeEntryId === entry.id ||
    item.sourceFinanceEntryId === entry.id
  );

  if (existing) {
    entry.payrollId = existing.id;
    return existing;
  }

  const payrollItem = {
    id: `pay_${Date.now()}_${randomBytes(4).toString("hex")}`,
    employeeId: employee.id,
    employeeName: employee.username,
    departmentId: employee.departmentId,
    amount: toAmount(entry.amount),
    status: "pending",
    notes: entry.notes || "استلام راتب مسجل يحتاج توقيع",
    sourceFinanceEntryId: entry.id,
    financeEntryId: entry.id,
    createdAt: new Date(entry.timestamp || Date.now()).toISOString(),
    createdBy: entry.createdBy || "system"
  };

  entry.payrollId = payrollItem.id;
  db.payroll.push(payrollItem);
  return payrollItem;
}

function ensureEmployeeFinanceDepartments() {
  let changed = false;

  db.finance.forEach(entry => {
    const beforeDepartmentId = entry.departmentId;
    enforceEmployeeFinanceDepartment(entry);
    if (entry.departmentId !== beforeDepartmentId) {
      changed = true;
    }
  });

  if (changed) saveDb();
}

function ensurePendingPayrollForSalaryEntries() {
  let changed = false;

  db.finance.forEach(entry => {
    const beforePayrollId = entry.payrollId;
    const beforeDepartmentId = entry.departmentId;
    const beforeCount = db.payroll.length;
    createPendingPayrollFromSalaryEntry(entry);
    if (entry.payrollId !== beforePayrollId || entry.departmentId !== beforeDepartmentId || db.payroll.length !== beforeCount) {
      changed = true;
    }
  });

  if (changed) saveDb();
}

function getZonedParts(value = new Date(), timeZone = ATTENDANCE_TIME_ZONE) {
  const date = value instanceof Date ? value : new Date(value);
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    weekday: "short"
  }).formatToParts(date);

  const partMap = parts.reduce((acc, part) => {
    acc[part.type] = part.value;
    return acc;
  }, {});

  const hour = Number(partMap.hour) === 24 ? 0 : Number(partMap.hour);

  return {
    year: Number(partMap.year),
    month: Number(partMap.month),
    day: Number(partMap.day),
    hour,
    minute: Number(partMap.minute),
    second: Number(partMap.second),
    weekday: partMap.weekday
  };
}

function toDateKey(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return toDateKey(new Date());

  const parts = getZonedParts(date);
  const year = parts.year;
  const month = String(parts.month).padStart(2, "0");
  const day = String(parts.day).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function dateAtStart(value = new Date()) {
  const date = value instanceof Date ? new Date(value) : new Date(value);
  if (Number.isNaN(date.getTime())) return dateAtStart(new Date());
  date.setHours(0, 0, 0, 0);
  return date;
}

function addDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function eachDateKey(start, end) {
  const dates = [];
  for (let cursor = dateAtStart(start); cursor <= end; cursor = addDays(cursor, 1)) {
    dates.push(toDateKey(cursor));
  }
  return dates;
}

function getAttendanceRange(period = "daily", dateValue = new Date()) {
  const selected = dateAtStart(`${dateValue || toDateKey()}T00:00:00`);
  const today = dateAtStart(`${toDateKey(new Date())}T00:00:00`);
  let start = new Date(selected);
  let end = new Date(selected);

  if (period === "weekly") {
    const daysSinceSaturday = (selected.getDay() + 1) % 7;
    start = addDays(selected, -daysSinceSaturday);
    end = addDays(start, 6);
  } else if (period === "monthly") {
    start = new Date(selected.getFullYear(), selected.getMonth(), 1);
    end = new Date(selected.getFullYear(), selected.getMonth() + 1, 0);
  } else if (period === "annual") {
    start = new Date(selected.getFullYear(), 0, 1);
    end = new Date(selected.getFullYear(), 11, 31);
  }

  if (end > today) end = today;
  return { start, end, dateKeys: eachDateKey(start, end) };
}

function timeToSeconds(timeValue = "09:00", fallback = "09:00") {
  const [hours, minutes] = String(timeValue || fallback).split(":").map(Number);
  const fallbackParts = String(fallback).split(":").map(Number);
  const safeHours = Number.isFinite(hours) ? hours : fallbackParts[0];
  const safeMinutes = Number.isFinite(minutes) ? minutes : fallbackParts[1];
  return (safeHours * 60 * 60) + (safeMinutes * 60);
}

function secondsInWorkday(timestamp) {
  const parts = getZonedParts(timestamp);
  return (parts.hour * 60 * 60) + (parts.minute * 60) + parts.second;
}

function isAfterAttendanceTime(timestamp, attendanceStartTime = "09:00", graceMinutes = ATTENDANCE_GRACE_MINUTES) {
  const [hours, minutes] = String(attendanceStartTime || "09:00").split(":").map(Number);
  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return false;

  const checkSeconds = secondsInWorkday(timestamp);
  const startSeconds = timeToSeconds(attendanceStartTime, "09:00") + (toNumber(graceMinutes, 10) * 60);
  return checkSeconds > startSeconds;
}

function minutesAfterAttendanceTime(timestamp, attendanceStartTime = "09:00", graceMinutes = ATTENDANCE_GRACE_MINUTES) {
  if (!isAfterAttendanceTime(timestamp, attendanceStartTime, graceMinutes)) return 0;
  const checkSeconds = secondsInWorkday(timestamp);
  const startSeconds = timeToSeconds(attendanceStartTime, "09:00") + (toNumber(graceMinutes, 10) * 60);
  return Math.max(0, Math.ceil((checkSeconds - startSeconds) / 60));
}

function isBeforeDepartureTime(timestamp, attendanceEndTime = "17:00") {
  const checkSeconds = secondsInWorkday(timestamp);
  const endSeconds = timeToSeconds(attendanceEndTime, "17:00");
  return checkSeconds < endSeconds;
}

function minutesBeforeDepartureTime(timestamp, attendanceEndTime = "17:00") {
  if (!isBeforeDepartureTime(timestamp, attendanceEndTime)) return 0;
  const checkSeconds = secondsInWorkday(timestamp);
  const endSeconds = timeToSeconds(attendanceEndTime, "17:00");
  return Math.max(0, Math.ceil((endSeconds - checkSeconds) / 60));
}

function attendanceUsers() {
  return db.users.filter(user => user.role !== "ADMIN");
}

function publicUser(user) {
  const { password, ...safeUser } = user;
  return safeUser;
}

function buildSummary() {
  const adminFinance = db.finance.filter(f => !f.employeeId);
  const income = adminFinance.filter(f => f.type === "income").reduce((a, b) => a + toAmount(b.amount), 0);
  const expenses = adminFinance.filter(f => f.type === "expense").reduce((a, b) => a + toAmount(b.amount), 0);

  return {
    totalUsers: db.users.length,
    totalDepartments: db.departments.length,
    totalRevenue: income,
    totalExpenses: expenses,
    netProfit: income - expenses
  };
}

function canManageNotifications(user) {
  return ["ADMIN", "MANAGER"].includes(user.role);
}

function getNotificationRecipientIds(targetType, targetUserIds, senderId) {
  if (targetType === "all") {
    return db.users
      .filter(user => user.id !== senderId && user.role !== "ADMIN")
      .map(user => user.id);
  }

  const requestedIds = Array.isArray(targetUserIds) ? targetUserIds : [];
  const allowedIds = new Set(
    db.users
      .filter(user => user.role !== "ADMIN")
      .map(user => user.id)
  );

  return [...new Set(requestedIds.map(String))]
    .filter(id => allowedIds.has(id));
}

function userCanSeeNotification(notification, user) {
  if (canManageNotifications(user)) return true;
  return Array.isArray(notification.targetUserIds) && notification.targetUserIds.includes(user.id);
}

function serializeNotification(notification, viewerId) {
  const targetIds = Array.isArray(notification.targetUserIds) ? notification.targetUserIds : [];
  const sender = db.users.find(user => user.id === notification.senderId);
  const targetUsers = db.users
    .filter(user => targetIds.includes(user.id))
    .map(user => ({
      id: user.id,
      username: user.username,
      role: user.role,
      departmentId: user.departmentId
    }));

  return {
    ...notification,
    senderName: sender?.username || notification.senderName || "النظام",
    targetUsers,
    targetLabel: notification.targetType === "all"
      ? "كل الموظفين"
      : targetUsers.map(user => user.username).join(", "),
    readCount: Array.isArray(notification.readBy) ? notification.readBy.length : 0,
    isRead: Array.isArray(notification.readBy) && notification.readBy.includes(viewerId)
  };
}

function pushUserNotification({ title, message, targetUserIds = [], senderId = "system", metadata = {} }) {
  const cleanTargetIds = [...new Set((Array.isArray(targetUserIds) ? targetUserIds : [targetUserIds]).map(String))]
    .filter(id => db.users.some(user => user.id === id));

  if (!cleanTargetIds.length) return null;

  const notification = {
    id: `note_${Date.now()}_${randomBytes(4).toString("hex")}`,
    title: String(title || "إشعار").slice(0, 80),
    message: String(message || "").slice(0, 1200),
    targetType: "users",
    targetUserIds: cleanTargetIds,
    senderId,
    senderName: senderId === "system" ? "النظام" : undefined,
    metadata,
    createdAt: new Date().toISOString(),
    readBy: []
  };

  db.notifications.push(notification);
  return notification;
}

function pushManagementNotification({ title, message, senderId = "system", metadata = {} }) {
  const targetUserIds = db.users
    .filter(user => ["ADMIN", "MANAGER"].includes(user.role))
    .map(user => user.id);

  if (!targetUserIds.length) return null;

  const notification = {
    id: `note_${Date.now()}_${randomBytes(4).toString("hex")}`,
    title: String(title || "إشعار").slice(0, 80),
    message: String(message || "").slice(0, 1200),
    targetType: "users",
    targetUserIds,
    senderId,
    senderName: senderId === "system" ? "النظام" : undefined,
    metadata,
    createdAt: new Date().toISOString(),
    readBy: []
  };

  db.notifications.push(notification);
  return notification;
}

const app = express();

app.use(cors());
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "15mb" }));

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", environment: process.env.NODE_ENV || "production", storage: DATA_FILE });
});

app.get("/api/config/public", (req, res) => {
  res.json({
    companyName: COMPANY_NAME,
    publicUrl: PUBLIC_URL,
    attendance: {
      companyLat: COMPANY_LAT,
      companyLng: COMPANY_LNG,
      maxDistanceMeters: MAX_DISTANCE_METERS,
      minIntervalSeconds: Math.round(MIN_INTERVAL_MS / 1000),
      timeZone: ATTENDANCE_TIME_ZONE,
      graceMinutes: ATTENDANCE_GRACE_MINUTES
    }
  });
});

app.get("/api/settings", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  res.json({
    app: {
      name: COMPANY_NAME,
      publicUrl: PUBLIC_URL,
      port: PORT
    },
    attendance: {
      companyLat: COMPANY_LAT,
      companyLng: COMPANY_LNG,
      maxDistanceMeters: MAX_DISTANCE_METERS,
      minIntervalSeconds: Math.round(MIN_INTERVAL_MS / 1000),
      timeZone: ATTENDANCE_TIME_ZONE,
      graceMinutes: ATTENDANCE_GRACE_MINUTES
    },
    database: {
      mode: DATABASE_MODE,
      provider: isPostgresMode() ? "PostgreSQL / Supabase" : "JSON محلي",
      connected: isPostgresMode() ? Boolean(pgPool) : true,
      jsonDataDir: DATA_DIR
    }
  });
});

app.patch("/api/settings", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  const databasePatch = req.body.database && typeof req.body.database === "object" ? req.body.database : null;
  const nextDatabase = {
    ...(appConfig.database || {}),
    jsonDataDir: DATA_DIR
  };

  if (databasePatch) {
    const mode = databasePatch.mode?.trim();
    const url = databasePatch.url?.trim();
    const apiUrl = databasePatch.apiUrl?.trim();
    const apiKey = databasePatch.apiKey?.trim();

    if (mode) nextDatabase.mode = mode;
    if (url) nextDatabase.url = url;
    if (apiUrl) nextDatabase.apiUrl = apiUrl;
    if (apiKey) nextDatabase.apiKey = apiKey;
  }

  const nextConfig = {
    ...appConfig,
    app: {
      ...(appConfig.app || {}),
      name: req.body.app?.name?.trim() || COMPANY_NAME,
      publicUrl: req.body.app?.publicUrl?.trim() || PUBLIC_URL,
      port: PORT
    },
    attendance: {
      ...(appConfig.attendance || {}),
      companyLat: toNumber(req.body.attendance?.companyLat, COMPANY_LAT),
      companyLng: toNumber(req.body.attendance?.companyLng, COMPANY_LNG),
      maxDistanceMeters: toNumber(req.body.attendance?.maxDistanceMeters, MAX_DISTANCE_METERS),
      minIntervalSeconds: toNumber(req.body.attendance?.minIntervalSeconds, Math.round(MIN_INTERVAL_MS / 1000)),
      timeZone: req.body.attendance?.timeZone?.trim() || ATTENDANCE_TIME_ZONE,
      graceMinutes: toNumber(req.body.attendance?.graceMinutes, ATTENDANCE_GRACE_MINUTES)
    },
    database: nextDatabase
  };

  Object.assign(appConfig, nextConfig);
  COMPANY_NAME = nextConfig.app.name;
  PUBLIC_URL = nextConfig.app.publicUrl;
  COMPANY_LAT = nextConfig.attendance.companyLat;
  COMPANY_LNG = nextConfig.attendance.companyLng;
  MAX_DISTANCE_METERS = nextConfig.attendance.maxDistanceMeters;
  MIN_INTERVAL_MS = nextConfig.attendance.minIntervalSeconds * 1000;
  ATTENDANCE_TIME_ZONE = nextConfig.attendance.timeZone;
  ATTENDANCE_GRACE_MINUTES = nextConfig.attendance.graceMinutes;
  DATABASE_MODE = process.env.DATABASE_MODE || nextConfig.database.mode || DATABASE_MODE;
  DATABASE_URL = process.env.DATABASE_URL || nextConfig.database.url || DATABASE_URL;
  DATABASE_API_URL = process.env.DATABASE_API_URL || nextConfig.database.apiUrl || DATABASE_API_URL;
  DATABASE_API_KEY = process.env.DATABASE_API_KEY || nextConfig.database.apiKey || DATABASE_API_KEY;

  writeFileSync(CONFIG_FILE, JSON.stringify(nextConfig, null, 2), "utf8");
  res.json({ message: "تم حفظ الإعدادات", settings: nextConfig });
});

app.post("/api/system/reset", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  const code = String(req.body.code || "").trim();

  if (code !== RESET_SYSTEM_CODE) {
    return res.status(403).json({ message: "رمز التصفير غير صحيح" });
  }

  const currentAdmin = db.users.find(user => user.id === req.user.id) ||
    db.users.find(user => user.role === "ADMIN") ||
    createDefaultDb().users[0];
  const freshDb = createDefaultDb();

  freshDb.users = [{
    ...currentAdmin,
    role: "ADMIN",
    departmentId: "mgmt",
    isSupplier: false,
    attendanceStartTime: currentAdmin.attendanceStartTime || "09:00",
    attendanceEndTime: currentAdmin.attendanceEndTime || "17:00",
    createdAt: currentAdmin.createdAt || new Date().toISOString()
  }];

  db = normalizeDb(freshDb);
  saveDb();

  res.json({ message: "تم تصفير كل شيء: الموظفين، الأقسام، المالية، الحضور، المهام، الإشعارات، والفواتير. بقي حساب الأدمن فقط." });
});

app.patch("/api/system/reset-code", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  const currentCode = String(req.body.currentCode || "").trim();
  const newCode = String(req.body.newCode || "").trim();

  if (currentCode !== RESET_SYSTEM_CODE) {
    return res.status(403).json({ message: "الرمز الحالي غير صحيح" });
  }

  if (newCode.length < 6) {
    return res.status(400).json({ message: "الرمز الجديد يجب أن يكون 6 خانات على الأقل" });
  }

  RESET_SYSTEM_CODE = newCode;
  const nextConfig = {
    ...appConfig,
    security: {
      ...(appConfig.security || {}),
      resetCode: newCode
    }
  };

  Object.assign(appConfig, nextConfig);
  writeFileSync(CONFIG_FILE, JSON.stringify(nextConfig, null, 2), "utf8");
  res.json({ message: "تم تغيير رمز التصفير" });
});

function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "الوصول مرفوض: رمز مفقود" });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: "انتهت صلاحية الجلسة", detail: err.message });
    }

    req.user = user;
    next();
  });
}

function authorize(roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "صلاحيات غير كافية لهذه العملية" });
    }

    next();
  };
}

app.post("/api/auth/login", (req, res) => {
  const { username, password, role } = req.body;
  const user = db.users.find(u => u.username === username);

  if (!user || !bcrypt.compareSync(password || "", user.password)) {
    return res.status(401).json({ message: "بيانات الدخول غير صحيحة" });
  }

  if (role === "MANAGEMENT" && !["ADMIN", "MANAGER"].includes(user.role)) {
    return res.status(403).json({ message: "هذا الحساب لا يملك صلاحيات إدارية" });
  }

  if (role === "EMPLOYEE" && user.role !== "EMPLOYEE") {
    return res.status(403).json({ message: "هذا الحساب ليس حساب موظف" });
  }

  if (role === "FREELANCER" && user.role !== "FREELANCER") {
    return res.status(403).json({ message: "هذا الحساب ليس حساب فريلانسر" });
  }

  if (!["MANAGEMENT", "EMPLOYEE", "FREELANCER"].includes(role)) {
    return res.status(403).json({ message: "يرجى تسجيل الدخول من خلال بوابة الإدارة" });
  }

  const token = jwt.sign(
    { id: user.id, username: user.username, role: user.role, dept: user.departmentId, supplier: Boolean(user.isSupplier) },
    JWT_SECRET,
    { expiresIn: `${SESSION_HOURS}h` }
  );

  res.json({ token, user: publicUser(user) });
});

app.get("/api/public/departments", (req, res) => {
  res.json(db.departments.map(({ id, name }) => ({ id, name })));
});

app.get("/api/departments", authenticateToken, (req, res) => {
  res.json(db.departments);
});

app.post("/api/departments", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  const { name, description, config } = req.body;

  if (!name?.trim()) {
    return res.status(400).json({ message: "اسم القسم مطلوب" });
  }

  const dept = {
    id: `dept_${Date.now()}`,
    name: name.trim(),
    description: description || "",
    createdAt: new Date().toISOString(),
    config: {
      allowRemoteAttendance: Boolean(config?.allowRemoteAttendance),
      budgetLimit: toAmount(config?.budgetLimit)
    }
  };

  db.departments.push(dept);
  saveDb();
  res.status(201).json(dept);
});

app.patch("/api/departments/:id", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const index = db.departments.findIndex(d => d.id === req.params.id);

  if (index === -1) {
    return res.sendStatus(404);
  }

  const current = db.departments[index];
  db.departments[index] = {
    ...current,
    ...req.body,
    name: req.body.name?.trim() || current.name,
    config: { ...(current.config || {}), ...(req.body.config || {}) }
  };

  if (db.departments[index].config?.budgetLimit !== undefined) {
    db.departments[index].config.budgetLimit = toAmount(db.departments[index].config.budgetLimit);
  }

  saveDb();
  res.json(db.departments[index]);
});

app.delete("/api/departments/:id", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  if (req.params.id === "mgmt" || db.users.some(u => u.departmentId === req.params.id)) {
    return res.status(400).json({ message: "لا يمكن حذف قسم مرتبط بمستخدمين أو بالقسم الرئيسي" });
  }

  db.departments = db.departments.filter(d => d.id !== req.params.id);
  db.qrTokens = db.qrTokens.filter(q => q.departmentId !== req.params.id);
  saveDb();
  res.sendStatus(200);
});

app.get("/api/users", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  res.json(db.users.map(publicUser));
});

app.get("/api/users/me", authenticateToken, (req, res) => {
  const user = db.users.find(u => u.id === req.user.id);

  if (!user) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  res.json(publicUser(user));
});

app.patch("/api/users/me/profile", authenticateToken, (req, res) => {
  const user = db.users.find(u => u.id === req.user.id);

  if (!user) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  if (req.body.displayName !== undefined) {
    user.displayName = String(req.body.displayName || "").trim().slice(0, 80);
  }

  if (req.body.avatar !== undefined) {
    const avatar = normalizeAvatarDataUrl(req.body.avatar);
    if (avatar === null) {
      return res.status(400).json({ message: "صيغة صورة البروفايل غير صالحة أو حجمها كبير" });
    }
    user.avatar = avatar;
  }

  user.profileUpdatedAt = new Date().toISOString();
  saveDb();
  res.json(publicUser(user));
});

app.post("/api/users", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  const { username, password, departmentId, salary, attendanceStartTime, attendanceEndTime, isSupplier } = req.body;
  const role = normalizeUserRole(req.body.role);

  if (!username?.trim()) return res.status(400).json({ message: "اسم المستخدم مطلوب" });
  if (!password || password.length < 6) return res.status(400).json({ message: "كلمة المرور يجب أن تكون 6 خانات على الأقل" });
  if (!USER_ROLES.includes(role)) return res.status(400).json({ message: "نوع الصلاحية غير صالح" });
  if (!db.departments.some(d => d.id === departmentId)) return res.status(400).json({ message: "القسم المحدد غير موجود" });
  if (db.users.some(u => u.username === username.trim())) return res.status(400).json({ message: "المستخدم موجود" });

  const newUser = {
    id: `u_${Date.now()}`,
    username: username.trim(),
    password: bcrypt.hashSync(password, 10),
    accessCode: password,
    role,
    displayName: username.trim(),
    avatar: "",
    departmentId,
    salary: toAmount(salary),
    isSupplier: Boolean(isSupplier),
    attendanceStartTime: /^([01]\d|2[0-3]):[0-5]\d$/.test(attendanceStartTime || "") ? attendanceStartTime : "09:00",
    attendanceEndTime: /^([01]\d|2[0-3]):[0-5]\d$/.test(attendanceEndTime || "") ? attendanceEndTime : "17:00",
    createdAt: new Date().toISOString()
  };

  db.users.push(newUser);
  saveDb();
  res.status(201).json(publicUser(newUser));
});

app.patch("/api/users/:id", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  const index = db.users.findIndex(u => u.id === req.params.id);

  if (index === -1) {
    return res.sendStatus(404);
  }

  const { password, accessCode, ...body } = req.body;
  if (body.role !== undefined) {
    body.role = normalizeUserRole(body.role);
  }

  if (body.departmentId && !db.departments.some(d => d.id === body.departmentId)) {
    return res.status(400).json({ message: "القسم المحدد غير موجود" });
  }

  if (body.role && !USER_ROLES.includes(body.role)) {
    return res.status(400).json({ message: "نوع الصلاحية غير صالح" });
  }

  const nextAccessCode = String(accessCode || password || "").trim();
  if (nextAccessCode && nextAccessCode.length < 6) {
    return res.status(400).json({ message: "رمز الدخول يجب أن يكون 6 خانات على الأقل" });
  }

  db.users[index] = {
    ...db.users[index],
    ...body,
    username: body.username?.trim() || db.users[index].username,
    salary: body.salary !== undefined ? toAmount(body.salary) : db.users[index].salary,
    isSupplier: body.isSupplier !== undefined ? Boolean(body.isSupplier) : Boolean(db.users[index].isSupplier),
    attendanceStartTime: /^([01]\d|2[0-3]):[0-5]\d$/.test(body.attendanceStartTime || "")
      ? body.attendanceStartTime
      : (db.users[index].attendanceStartTime || "09:00"),
    attendanceEndTime: /^([01]\d|2[0-3]):[0-5]\d$/.test(body.attendanceEndTime || "")
      ? body.attendanceEndTime
      : (db.users[index].attendanceEndTime || "17:00")
  };

  if (nextAccessCode) {
    db.users[index].password = bcrypt.hashSync(nextAccessCode, 10);
    db.users[index].accessCode = nextAccessCode;
  }

  saveDb();
  res.json(publicUser(db.users[index]));
});

app.delete("/api/users/:id", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  if (req.params.id === "admin_root" || req.params.id === req.user.id) {
    return res.status(400).json({ message: "لا يمكن حذف المستخدم الرئيسي أو حسابك الحالي" });
  }

  db.users = db.users.filter(u => u.id !== req.params.id);
  saveDb();
  res.sendStatus(200);
});

app.post("/api/users/:id/change-password", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const { newPassword } = req.body;

  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ message: "كلمة المرور يجب أن تكون 6 خانات على الأقل" });
  }

  const user = db.users.find(u => u.id === req.params.id);

  if (!user) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  if (req.user.role !== "ADMIN" && !WORKER_ROLES.includes(user.role)) {
    return res.status(403).json({ message: "المدير يستطيع تغيير كلمات مرور الموظفين فقط" });
  }

  user.password = bcrypt.hashSync(newPassword, 10);
  user.accessCode = newPassword;
  saveDb();
  res.json({ message: "تم تحديث كلمة المرور بنجاح" });
});

function canManageSuppliers(user) {
  return user.role === "ADMIN" || user.role === "MANAGER";
}

function isValidAttachment(attachment) {
  if (!attachment || typeof attachment !== "object") return false;
  if (!attachment.name || !attachment.type || !attachment.dataUrl) return false;
  if (typeof attachment.dataUrl !== "string" || !attachment.dataUrl.startsWith("data:")) return false;
  return Buffer.byteLength(attachment.dataUrl, "utf8") <= 8 * 1024 * 1024;
}

function withSupplierName(invoice) {
  const supplier = db.users.find(user => user.id === invoice.supplierId);
  const department = db.departments.find(dept => dept.id === invoice.departmentId);
  return {
    ...invoice,
    supplierName: supplier?.username || "مورد غير محدد",
    departmentName: department?.name || invoice.departmentName || null
  };
}

app.get("/api/supplier-invoices", authenticateToken, (req, res) => {
  const manager = canManageSuppliers(req.user);
  const fullUser = db.users.find(user => user.id === req.user.id);

  if (!manager && !fullUser?.isSupplier) {
    return res.status(403).json({ message: "هذا الحساب غير مفعّل كمورد" });
  }

  const visibleInvoices = manager
    ? db.supplierInvoices
    : db.supplierInvoices.filter(invoice => invoice.supplierId === req.user.id);
  const visibleSupplierIds = new Set(visibleInvoices.map(invoice => invoice.supplierId));
  const suppliers = db.users
    .filter(user => user.isSupplier && (manager || user.id === req.user.id || visibleSupplierIds.has(user.id)))
    .map(publicUser);
  const total = visibleInvoices.reduce((sum, invoice) => sum + toAmount(invoice.amount), 0);

  res.json({
    suppliers,
    invoices: visibleInvoices.map(withSupplierName).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    total
  });
});

app.post("/api/supplier-invoices", authenticateToken, (req, res) => {
  const manager = canManageSuppliers(req.user);
  const supplierId = manager && req.body.supplierId ? req.body.supplierId : req.user.id;
  const supplier = db.users.find(user => user.id === supplierId);
  const amount = toAmount(req.body.amount);
  const description = String(req.body.description || "").trim();
  const departmentId = String(req.body.departmentId || supplier?.departmentId || req.user.dept || "mgmt");
  const department = db.departments.find(dept => dept.id === departmentId);

  if (!supplier?.isSupplier) {
    return res.status(403).json({ message: "الحساب المحدد غير مفعّل كمورد" });
  }

  if (!manager && supplierId !== req.user.id) {
    return res.status(403).json({ message: "لا يمكنك إضافة فاتورة لمورد آخر" });
  }

  if (!description) {
    return res.status(400).json({ message: "اكتب وصف الشيء الذي تم شراؤه" });
  }

  if (amount <= 0) {
    return res.status(400).json({ message: "قيمة الفاتورة يجب أن تكون أكبر من صفر" });
  }

  if (!department) {
    return res.status(400).json({ message: "القسم المحدد غير موجود" });
  }

  if (!isValidAttachment(req.body.attachment)) {
    return res.status(400).json({ message: "يرجى إرفاق الفاتورة PDF أو صورة بحجم مناسب" });
  }

  const invoice = {
    id: `supplier_invoice_${Date.now()}_${randomBytes(4).toString("hex")}`,
    supplierId,
    supplierName: supplier.username,
    departmentId,
    departmentName: department.name,
    description,
    amount,
    attachment: {
      name: String(req.body.attachment.name).slice(0, 160),
      type: String(req.body.attachment.type).slice(0, 80),
      size: toNumber(req.body.attachment.size, 0),
      dataUrl: req.body.attachment.dataUrl
    },
    createdAt: new Date().toISOString(),
    createdBy: req.user.id
  };

  db.supplierInvoices.push(invoice);
  saveDb();
  res.status(201).json(withSupplierName(invoice));
});

app.delete("/api/supplier-invoices/:id", authenticateToken, (req, res) => {
  const invoice = db.supplierInvoices.find(item => item.id === req.params.id);

  if (!invoice) {
    return res.sendStatus(404);
  }

  if (!canManageSuppliers(req.user) && invoice.supplierId !== req.user.id) {
    return res.status(403).json({ message: "لا يمكنك حذف هذه الفاتورة" });
  }

  db.supplierInvoices = db.supplierInvoices.filter(item => item.id !== req.params.id);
  saveDb();
  res.sendStatus(200);
});

app.get("/api/finance", authenticateToken, (req, res) => {
  const { employeeId, departmentId } = req.query;
  const includeEmployee = req.query.includeEmployee === "1" ||
    req.query.includeEmployee === "true" ||
    req.query.scope === "all";
  const user = req.user;

  if (user.role === "ADMIN" || user.role === "MANAGER") {
    if (employeeId) {
      const targetUser = db.users.find(u => u.id === employeeId);
      return res.json({
        salary: targetUser?.salary || 0,
        entries: db.finance.filter(f => f.employeeId === employeeId)
      });
    }

    if (departmentId) {
      return res.json(db.finance.filter(f => f.departmentId === departmentId && (includeEmployee || !f.employeeId)));
    }

    return res.json(db.finance.filter(f => includeEmployee || !f.employeeId));
  }

  const fullUser = db.users.find(u => u.id === user.id);
  res.json({
    salary: fullUser?.salary || 0,
    entries: db.finance.filter(f => f.employeeId === user.id)
  });
});

app.post("/api/finance", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const { type, amount, category, notes, departmentId, employeeId } = req.body;
  const numericAmount = toAmount(amount);
  const cleanCategory = String(category || "عام").trim() || "عام";
  const shouldAttachEmployee = Boolean(employeeId) && isEmployeeFinanceCategory(cleanCategory);
  const targetEmployee = shouldAttachEmployee ? db.users.find(u => u.id === employeeId) : null;
  const requiresEmployee = isEmployeeFinanceCategory(cleanCategory) && (
    cleanCategory.includes("راتب") ||
    cleanCategory.includes("خصم") ||
    cleanCategory.includes("سلفة") ||
    isBonusPayment(cleanCategory)
  );
  const resolvedEmployeeId = targetEmployee ? targetEmployee.id : null;
  const resolvedDepartmentId = targetEmployee?.departmentId || departmentId || req.user.dept;

  if (!["income", "expense"].includes(type)) return res.status(400).json({ message: "نوع العملية المالية غير صالح" });
  if (numericAmount <= 0) return res.status(400).json({ message: "المبلغ يجب أن يكون أكبر من صفر" });
  if (resolvedDepartmentId && !db.departments.some(d => d.id === resolvedDepartmentId)) return res.status(400).json({ message: "القسم المحدد غير موجود" });
  if (employeeId && shouldAttachEmployee && !targetEmployee) return res.status(400).json({ message: "الموظف المحدد غير موجود" });
  if (requiresEmployee && !resolvedEmployeeId) return res.status(400).json({ message: "هذه العملية تخص موظف، اختار الموظف أولاً" });

  const entry = {
    id: `trx_${Date.now()}`,
    type,
    amount: numericAmount,
    category: cleanCategory,
    notes: notes || "",
    departmentId: resolvedDepartmentId,
    employeeId: resolvedEmployeeId,
    timestamp: new Date()
  };

  enforceEmployeeFinanceDepartment(entry);
  db.finance.push(entry);
  createPendingPayrollFromSalaryEntry(entry);
  saveDb();
  res.status(201).json(entry);
});

app.patch("/api/finance/:id", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const index = db.finance.findIndex(f => f.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ message: "العملية المالية غير موجودة" });
  }

  const current = db.finance[index];
  if (current.employeeId && req.user.role !== "ADMIN") {
    return res.status(403).json({ message: "تعديل حركات الموظفين متاح للأدمن فقط" });
  }

  const type = req.body.type || current.type;
  const numericAmount = req.body.amount !== undefined ? toAmount(req.body.amount) : toAmount(current.amount);
  const cleanCategory = String(req.body.category ?? current.category ?? "عام").trim() || "عام";
  const employeeId = req.body.employeeId !== undefined ? req.body.employeeId : current.employeeId;
  const shouldAttachEmployee = Boolean(employeeId) && isEmployeeFinanceCategory(cleanCategory);
  const targetEmployee = shouldAttachEmployee ? db.users.find(u => u.id === employeeId) : null;
  const resolvedDepartmentId = targetEmployee?.departmentId || req.body.departmentId || current.departmentId || req.user.dept;
  const resolvedEmployeeId = targetEmployee ? targetEmployee.id : null;

  if (!["income", "expense"].includes(type)) return res.status(400).json({ message: "نوع العملية المالية غير صالح" });
  if (numericAmount <= 0) return res.status(400).json({ message: "المبلغ يجب أن يكون أكبر من صفر" });
  if (resolvedDepartmentId && !db.departments.some(d => d.id === resolvedDepartmentId)) return res.status(400).json({ message: "القسم المحدد غير موجود" });
  if (employeeId && shouldAttachEmployee && !targetEmployee) return res.status(400).json({ message: "الموظف المحدد غير موجود" });

  db.finance[index] = {
    ...current,
    type,
    amount: numericAmount,
    category: cleanCategory,
    notes: req.body.notes !== undefined ? String(req.body.notes || "") : (current.notes || ""),
    departmentId: resolvedDepartmentId,
    employeeId: shouldAttachEmployee ? resolvedEmployeeId : null,
    updatedAt: new Date().toISOString(),
    updatedBy: req.user.id
  };

  enforceEmployeeFinanceDepartment(db.finance[index]);
  saveDb();
  res.json(db.finance[index]);
});

app.delete("/api/finance/:id", authenticateToken, authorize(["ADMIN"]), (req, res) => {
  const entry = db.finance.find(f => f.id === req.params.id);
  if (!entry) {
    return res.status(404).json({ message: "العملية المالية غير موجودة" });
  }

  db.finance = db.finance.filter(f => f.id !== req.params.id);
  db.payroll = db.payroll.filter(item => item.sourceFinanceEntryId !== req.params.id && item.financeEntryId !== req.params.id);
  db.advanceRequests = db.advanceRequests.map(item => item.financeEntryId === req.params.id ? { ...item, financeEntryId: null } : item);
  saveDb();
  res.sendStatus(200);
});

app.get("/api/payroll", authenticateToken, (req, res) => {
  if (req.user.role === "ADMIN" || req.user.role === "MANAGER") {
    return res.json(db.payroll.map(withEmployeeName));
  }

  res.json(db.payroll.filter(item => item.employeeId === req.user.id).map(withEmployeeName));
});

app.get("/api/payroll/:id/receipt", authenticateToken, (req, res) => {
  const payrollItem = db.payroll.find(item => item.id === req.params.id);

  if (!payrollItem) {
    return res.status(404).json({ message: "إيصال الاستلام غير موجود" });
  }

  if (!["ADMIN", "MANAGER"].includes(req.user.role) && payrollItem.employeeId !== req.user.id) {
    return res.status(403).json({ message: "لا يمكنك فتح إيصال موظف آخر" });
  }

  if (!payrollItem.receiptPdf?.dataUrl) {
    return res.status(404).json({ message: "ملف PDF غير محفوظ لهذا الاستلام" });
  }

  res.json({
    receiptPdf: payrollItem.receiptPdf,
    payroll: withEmployeeName(payrollItem)
  });
});

app.post("/api/payroll", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const { employeeId, amount, notes } = req.body;
  const ledger = getEmployeeLedger(employeeId);

  if (!ledger) {
    return res.status(404).json({ message: "الموظف غير موجود" });
  }

  if (ledger.employee.role === "ADMIN") {
    return res.status(400).json({ message: "حساب الإدارة غير محسوب ضمن الاستلام" });
  }

  const pending = db.payroll.find(item => item.employeeId === employeeId && item.status === "pending");
  if (pending) {
    return res.status(400).json({ message: "يوجد استلام مفتوح لهذا الموظف ينتظر التوقيع" });
  }

  const payoutAmount = toAmount(amount) > 0 ? toAmount(amount) : ledger.balance;
  if (payoutAmount <= 0) {
    return res.status(400).json({ message: "لا يوجد مبلغ مستحق للتصفير" });
  }

  const payrollItem = {
    id: `pay_${Date.now()}`,
    employeeId,
    employeeName: ledger.employee.username,
    departmentId: ledger.employee.departmentId,
    amount: payoutAmount,
    status: "pending",
    notes: notes || "",
    createdAt: new Date().toISOString(),
    createdBy: req.user.id
  };

  db.payroll.push(payrollItem);
  saveDb();
  res.status(201).json(withEmployeeName(payrollItem));
});

app.post("/api/payroll/:id/receive", authenticateToken, (req, res) => {
  const payrollItem = db.payroll.find(item => item.id === req.params.id);

  if (!payrollItem) {
    return res.status(404).json({ message: "طلب الاستلام غير موجود" });
  }

  if (payrollItem.status !== "pending") {
    return res.status(400).json({ message: "تم استلام هذا الحساب سابقاً" });
  }

  if (WORKER_ROLES.includes(req.user.role) && payrollItem.employeeId !== req.user.id) {
    return res.status(403).json({ message: "لا يمكنك استلام حساب موظف آخر" });
  }

  if (![...WORKER_ROLES, "ADMIN", "MANAGER"].includes(req.user.role)) {
    return res.status(403).json({ message: "صلاحيات غير كافية لهذه العملية" });
  }

  const signature = String(req.body.signature || "");
  if (!signature.startsWith("data:image/") || Buffer.byteLength(signature, "utf8") > 1024 * 1024) {
    return res.status(400).json({ message: "التوقيع الإلكتروني مطلوب قبل الاستلام" });
  }

  const receiptPdf = req.body.receiptPdf;
  if (receiptPdf && (
    typeof receiptPdf !== "object" ||
    !String(receiptPdf.dataUrl || "").startsWith("data:application/pdf") ||
    Buffer.byteLength(String(receiptPdf.dataUrl || ""), "utf8") > 4 * 1024 * 1024
  )) {
    return res.status(400).json({ message: "ملف إيصال PDF غير صالح" });
  }

  const ledger = getEmployeeLedger(payrollItem.employeeId);
  if (!ledger) {
    return res.status(404).json({ message: "الموظف غير موجود" });
  }

  const sourceFinanceEntry = payrollItem.sourceFinanceEntryId
    ? db.finance.find(entry => entry.id === payrollItem.sourceFinanceEntryId)
    : null;
  const finalAmount = sourceFinanceEntry
    ? toAmount(sourceFinanceEntry.amount)
    : Math.min(toAmount(payrollItem.amount), ledger.balance || toAmount(payrollItem.amount));
  if (finalAmount <= 0) {
    return res.status(400).json({ message: "حساب الموظف صفر ولا يوجد مبلغ للاستلام" });
  }

  const financeEntry = sourceFinanceEntry || {
    id: `trx_${Date.now()}`,
    type: "expense",
    amount: finalAmount,
    category: "استلام راتب",
    notes: payrollItem.notes || "تم الاستلام بتوقيع إلكتروني",
    departmentId: ledger.employee.departmentId,
    employeeId: payrollItem.employeeId,
    payrollId: payrollItem.id,
    timestamp: new Date()
  };

  financeEntry.payrollId = payrollItem.id;
  financeEntry.employeeId = payrollItem.employeeId;
  enforceEmployeeFinanceDepartment(financeEntry);

  Object.assign(payrollItem, {
    amount: finalAmount,
    status: "received",
    signature,
    receiptPdf: receiptPdf ? {
      name: String(receiptPdf.name || `payroll-receipt-${payrollItem.id}.pdf`).slice(0, 160),
      type: "application/pdf",
      dataUrl: receiptPdf.dataUrl,
      createdAt: new Date().toISOString()
    } : undefined,
    receivedAt: new Date().toISOString(),
    receivedBy: req.user.id,
    financeEntryId: financeEntry.id
  });

  if (!sourceFinanceEntry) {
    db.finance.push(financeEntry);
  }
  pushManagementNotification({
    title: "إيصال استلام راتب",
    message: `وقّع ${ledger.employee.username} على استلام ${finalAmount.toLocaleString()} LYD. ملف PDF محفوظ في المالية ضمن إيصالات الاستلام.`,
    senderId: req.user.id,
    metadata: {
      type: "payroll_receipt",
      payrollId: payrollItem.id,
      employeeId: payrollItem.employeeId,
      amount: finalAmount
    }
  });
  saveDb();
  res.json({ message: "تم توقيع الاستلام وتصفير حساب الموظف", payroll: withEmployeeName(payrollItem), financeEntry });
});

app.get("/api/advance-requests", authenticateToken, (req, res) => {
  if (req.user.role === "ADMIN" || req.user.role === "MANAGER") {
    return res.json(db.advanceRequests.map(withEmployeeName));
  }

  res.json(db.advanceRequests.filter(item => item.employeeId === req.user.id).map(withEmployeeName));
});

app.post("/api/advance-requests", authenticateToken, (req, res) => {
  if (!WORKER_ROLES.includes(req.user.role)) {
    return res.status(403).json({ message: "طلب السلفة متاح من حساب الموظف أو الفريلانسر فقط" });
  }

  const amount = toAmount(req.body.amount);
  const employeeId = req.user.id;
  const employee = db.users.find(user => user.id === employeeId);

  if (!employee || employee.role === "ADMIN") {
    return res.status(400).json({ message: "الموظف المحدد غير صالح للسلفة" });
  }

  if (amount <= 0) {
    return res.status(400).json({ message: "قيمة السلفة يجب أن تكون أكبر من صفر" });
  }

  const request = {
    id: `adv_${Date.now()}`,
    employeeId,
    employeeName: employee.username,
    departmentId: employee.departmentId,
    amount,
    reason: req.body.reason || req.body.notes || "",
    status: "pending",
    createdAt: new Date().toISOString(),
    createdBy: req.user.id
  };

  db.advanceRequests.push(request);
  pushManagementNotification({
    title: "طلب سلفة جديد",
    message: `قدّم ${employee.username} طلب سلفة بقيمة ${amount.toLocaleString()} LYD.`,
    senderId: req.user.id,
    metadata: {
      type: "advance_request",
      advanceRequestId: request.id,
      employeeId,
      amount
    }
  });
  saveDb();
  res.status(201).json(withEmployeeName(request));
});

app.patch("/api/advance-requests/:id", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const request = db.advanceRequests.find(item => item.id === req.params.id);

  if (!request) {
    return res.status(404).json({ message: "طلب السلفة غير موجود" });
  }

  if (request.status !== "pending") {
    return res.status(400).json({ message: "تم التعامل مع هذا الطلب سابقاً" });
  }

  const action = req.body.action === "reject" ? "reject" : "approve";
  const employee = db.users.find(user => user.id === request.employeeId);

  if (!employee) {
    return res.status(404).json({ message: "الموظف غير موجود" });
  }

  request.status = action === "approve" ? "approved" : "rejected";
  request.reviewedAt = new Date().toISOString();
  request.reviewedBy = req.user.id;
  request.reviewNote = req.body.reviewNote || "";

  if (action === "approve") {
    const financeEntry = {
      id: `trx_${Date.now()}`,
      type: "expense",
      amount: toAmount(request.amount),
      category: "سلفة",
      notes: request.reason || "سلفة موظف",
      departmentId: employee.departmentId,
      employeeId: request.employeeId,
      advanceRequestId: request.id,
      timestamp: new Date()
    };
    request.financeEntryId = financeEntry.id;
    db.finance.push(financeEntry);
  }

  saveDb();
  res.json(withEmployeeName(request));
});

function withTaskAssignee(task) {
  const assignee = db.users.find(user => user.id === task.assignedTo);
  const department = db.departments.find(dept => dept.id === (task.departmentId || assignee?.departmentId));
  return {
    ...task,
    assigneeName: assignee?.username || "غير محدد",
    assigneeRole: assignee?.role || "",
    departmentName: department?.name || task.departmentName || null,
    isReceived: Boolean(task.receivedAt)
  };
}

app.get("/api/tasks", authenticateToken, (req, res) => {
  const user = req.user;

  if (user.role === "ADMIN" || user.role === "MANAGER") {
    return res.json(db.tasks.map(withTaskAssignee));
  }

  let changed = false;
  const assignedTasks = db.tasks.filter(t => t.assignedTo === user.id).map(task => {
    if (!task.receivedAt) {
      task.receivedAt = new Date().toISOString();
      task.receivedBy = user.id;
      pushManagementNotification({
        title: "استلام مهمة",
        message: `استلم ${user.username} المهمة: ${task.title}`,
        senderId: user.id,
        metadata: {
          type: "task_received",
          taskId: task.id,
          employeeId: user.id
        }
      });
      changed = true;
    }
    return task;
  });
  if (changed) saveDb();
  res.json(assignedTasks.map(withTaskAssignee));
});

app.post("/api/tasks", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const { title, description, assignedTo, status } = req.body;
  const assignee = assignedTo ? db.users.find(u => u.id === assignedTo) : null;

  if (!title?.trim()) return res.status(400).json({ message: "عنوان المهمة مطلوب" });
  if (!assignee || !WORKER_ROLES.includes(assignee.role)) {
    return res.status(400).json({ message: "اختار موظف أو فريلانسر لاستلام المهمة" });
  }

  const task = {
    id: `t_${Date.now()}`,
    title: title.trim(),
    description: description || "",
    assignedTo: assignee.id,
    departmentId: req.body.departmentId || assignee.departmentId || req.user.dept,
    status: ["todo", "doing", "done"].includes(status) ? status : "todo",
    receivedAt: null,
    receivedBy: null,
    createdAt: new Date().toISOString(),
    createdBy: req.user.id
  };

  db.tasks.push(task);
  pushUserNotification({
    title: "مهمة جديدة",
    message: `وصلتك مهمة جديدة: ${task.title}`,
    targetUserIds: [assignee.id],
    senderId: req.user.id,
    metadata: {
      type: "task",
      taskId: task.id,
      assignedTo: assignee.id
    }
  });
  saveDb();
  res.status(201).json(withTaskAssignee(task));
});

app.patch("/api/tasks/:id", authenticateToken, (req, res) => {
  const index = db.tasks.findIndex(t => t.id === req.params.id);

  if (index === -1) {
    return res.sendStatus(404);
  }

  const user = req.user;
  const task = db.tasks[index];

  if (WORKER_ROLES.includes(user.role) && task.assignedTo !== user.id) {
    return res.status(403).json({ message: "لا تملك صلاحية تعديل هذه المهمة" });
  }

  if (WORKER_ROLES.includes(user.role)) {
    const requestedStatus = req.body.status;

    if (!["todo", "doing", "done"].includes(requestedStatus)) {
      return res.status(400).json({ message: "حالة المهمة غير صالحة" });
    }

    db.tasks[index] = {
      ...task,
      status: requestedStatus,
      receivedAt: task.receivedAt || new Date().toISOString(),
      receivedBy: task.receivedBy || user.id
    };
    saveDb();
    return res.json(withTaskAssignee(db.tasks[index]));
  }

  if (req.body.assignedTo) {
    const assignee = db.users.find(u => u.id === req.body.assignedTo);
    if (!assignee || !WORKER_ROLES.includes(assignee.role)) {
      return res.status(400).json({ message: "اختار موظف أو فريلانسر لاستلام المهمة" });
    }
  }

  db.tasks[index] = { ...task, ...req.body };

  if (db.tasks[index].status && !["todo", "doing", "done"].includes(db.tasks[index].status)) {
    db.tasks[index].status = task.status;
  }

  saveDb();
  res.json(withTaskAssignee(db.tasks[index]));
});

app.delete("/api/tasks/:id", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  db.tasks = db.tasks.filter(t => t.id !== req.params.id);
  saveDb();
  res.sendStatus(200);
});

app.get("/api/attendance", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  res.json(db.attendance);
});

app.get("/api/attendance/daily", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const dateKey = typeof req.query.date === "string" && req.query.date ? req.query.date : toDateKey();
  const logsForDay = db.attendance
    .filter(log => toDateKey(log.timestamp) === dateKey)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const rows = attendanceUsers().map(user => {
    const userLogs = logsForDay.filter(log => log.userId === user.id);
    const firstIn = userLogs.find(log => log.type === "in");
    const lastOut = [...userLogs].reverse().find(log => log.type === "out");
    const lastLog = userLogs[userLogs.length - 1];
    const department = db.departments.find(dept => dept.id === user.departmentId);
    const isLate = Boolean(firstIn?.late || (firstIn && isAfterAttendanceTime(firstIn.timestamp, user.attendanceStartTime, ATTENDANCE_GRACE_MINUTES)));
    const earlyDeparture = Boolean(lastOut?.earlyDeparture || (lastOut && isBeforeDepartureTime(lastOut.timestamp, user.attendanceEndTime)));

    return {
      userId: user.id,
      username: user.username,
      role: user.role,
      departmentId: user.departmentId,
      departmentName: department?.name || "غير محدد",
      status: firstIn ? "present" : "absent",
      checkIn: firstIn?.timestamp || null,
      checkOut: lastOut?.timestamp || null,
      attendanceStartTime: user.attendanceStartTime || "09:00",
      attendanceEndTime: user.attendanceEndTime || "17:00",
      attendanceGraceMinutes: ATTENDANCE_GRACE_MINUTES,
      late: isLate,
      lateMinutes: firstIn ? (firstIn.lateMinutes || minutesAfterAttendanceTime(firstIn.timestamp, user.attendanceStartTime, ATTENDANCE_GRACE_MINUTES)) : 0,
      earlyDeparture,
      earlyMinutes: lastOut ? (lastOut.earlyMinutes || minutesBeforeDepartureTime(lastOut.timestamp, user.attendanceEndTime)) : 0,
      lastType: lastLog?.type || null,
      logsCount: userLogs.length
    };
  });

  res.json({
    date: dateKey,
    totals: {
      present: rows.filter(row => row.status === "present").length,
      absent: rows.filter(row => row.status === "absent").length,
      late: rows.filter(row => row.late).length,
      earlyDeparture: rows.filter(row => row.earlyDeparture).length,
      checkedOut: rows.filter(row => row.checkOut).length,
      total: rows.length
    },
    rows
  });
});

app.get("/api/attendance/report", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const period = ["daily", "weekly", "monthly", "annual"].includes(req.query.period) ? req.query.period : "daily";
  const dateKey = typeof req.query.date === "string" && req.query.date ? req.query.date : toDateKey();
  const employeeId = typeof req.query.employeeId === "string" ? req.query.employeeId : "";
  const { start, end, dateKeys } = getAttendanceRange(period, dateKey);
  const allowedUsers = attendanceUsers();
  const selectedUsers = employeeId ? allowedUsers.filter(user => user.id === employeeId) : allowedUsers;

  const logsInRange = db.attendance
    .filter(log => dateKeys.includes(toDateKey(log.timestamp)))
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const rows = selectedUsers.map(user => {
    const department = db.departments.find(dept => dept.id === user.departmentId);
    const days = dateKeys.map(date => {
      const dayLogs = logsInRange.filter(log => log.userId === user.id && toDateKey(log.timestamp) === date);
      const firstIn = dayLogs.find(log => log.type === "in");
      const lastOut = [...dayLogs].reverse().find(log => log.type === "out");
      const late = Boolean(firstIn?.late || (firstIn && isAfterAttendanceTime(firstIn.timestamp, user.attendanceStartTime, ATTENDANCE_GRACE_MINUTES)));
      const earlyDeparture = Boolean(lastOut?.earlyDeparture || (lastOut && isBeforeDepartureTime(lastOut.timestamp, user.attendanceEndTime)));

      return {
        date,
        status: firstIn ? "present" : "absent",
        checkIn: firstIn?.timestamp || null,
        checkOut: lastOut?.timestamp || null,
        late,
        lateMinutes: firstIn ? (firstIn.lateMinutes || minutesAfterAttendanceTime(firstIn.timestamp, user.attendanceStartTime, ATTENDANCE_GRACE_MINUTES)) : 0,
        earlyDeparture,
        earlyMinutes: lastOut ? (lastOut.earlyMinutes || minutesBeforeDepartureTime(lastOut.timestamp, user.attendanceEndTime)) : 0,
        logsCount: dayLogs.length
      };
    });

    const presentDays = days.filter(day => day.status === "present").length;
    const lateDays = days.filter(day => day.late).length;
    const earlyDepartureDays = days.filter(day => day.earlyDeparture).length;

    return {
      userId: user.id,
      username: user.username,
      role: user.role,
      departmentId: user.departmentId,
      departmentName: department?.name || "غير محدد",
      attendanceStartTime: user.attendanceStartTime || "09:00",
      attendanceEndTime: user.attendanceEndTime || "17:00",
      attendanceGraceMinutes: ATTENDANCE_GRACE_MINUTES,
      presentDays,
      absentDays: Math.max(0, dateKeys.length - presentDays),
      lateDays,
      earlyDepartureDays,
      checkedOutDays: days.filter(day => day.checkOut).length,
      totalDays: dateKeys.length,
      days
    };
  });

  res.json({
    period,
    startDate: toDateKey(start),
    endDate: toDateKey(end),
    employeeId: employeeId || null,
    totals: {
      employees: rows.length,
      totalDays: dateKeys.length,
      presentDays: rows.reduce((sum, row) => sum + row.presentDays, 0),
      absentDays: rows.reduce((sum, row) => sum + row.absentDays, 0),
      lateDays: rows.reduce((sum, row) => sum + row.lateDays, 0),
      earlyDepartureDays: rows.reduce((sum, row) => sum + row.earlyDepartureDays, 0),
      checkedOutDays: rows.reduce((sum, row) => sum + row.checkedOutDays, 0)
    },
    rows
  });
});

app.get("/api/attendance/qr-tokens", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  res.json(db.qrTokens);
});

app.post("/api/attendance/qr-tokens", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const { departmentId } = req.body;

  if (!db.departments.some(d => d.id === departmentId)) {
    return res.status(400).json({ message: "القسم المحدد غير موجود" });
  }

  const existing = db.qrTokens.find(q => q.departmentId === departmentId);

  if (existing) {
    existing.isActive = true;
    saveDb();
    return res.json(existing);
  }

  const qrBody = { token: `QR_${departmentId}_${randomBytes(8).toString("hex").toUpperCase()}`, departmentId, isActive: true };
  db.qrTokens.push(qrBody);
  saveDb();
  res.json(qrBody);
});

app.post("/api/attendance/check", authenticateToken, (req, res) => {
  const { token, departmentId, lat, lng } = req.body;
  const user = req.user;
  const fullUser = db.users.find(u => u.id === user.id);
  const qr = db.qrTokens.find(q => q.token === token && q.departmentId === departmentId && q.isActive);

  if (!fullUser) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  if (fullUser.role === "ADMIN") {
    return res.status(403).json({ message: "الأدمن غير محسوب في سجل الحضور والغياب" });
  }

  if (!qr) {
    return res.status(403).json({ message: "رمز QR غير صالح أو منتهي الصلاحية" });
  }

  if (lat === undefined || lng === undefined) {
    return res.status(400).json({ message: "يرجى تفعيل GPS لتسجيل الحضور" });
  }

  const distance = getDistance(Number(lat), Number(lng), COMPANY_LAT, COMPANY_LNG);

  if (distance > MAX_DISTANCE_METERS) {
    return res.status(403).json({ message: `أنت خارج نطاق الشركة (${Math.round(distance)} متر)` });
  }

  const now = new Date();
  const today = toDateKey(now);
  const lastLog = [...db.attendance].reverse().find(a => a.userId === user.id);
  const lastLogToday = [...db.attendance].reverse().find(a => a.userId === user.id && toDateKey(a.timestamp) === today);

  if (lastLog && (Date.now() - new Date(lastLog.timestamp).getTime()) < MIN_INTERVAL_MS) {
    return res.status(429).json({ message: "يرجى الانتظار دقيقتين بين كل عملية تسجيل" });
  }

  const type = lastLogToday?.type === "in" ? "out" : "in";
  const attendanceStartTime = fullUser.attendanceStartTime || "09:00";
  const attendanceEndTime = fullUser.attendanceEndTime || "17:00";
  const late = type === "in" && isAfterAttendanceTime(now, attendanceStartTime, ATTENDANCE_GRACE_MINUTES);
  const lateMinutes = late ? minutesAfterAttendanceTime(now, attendanceStartTime, ATTENDANCE_GRACE_MINUTES) : 0;
  const earlyDeparture = type === "out" && isBeforeDepartureTime(now, attendanceEndTime);
  const earlyMinutes = earlyDeparture ? minutesBeforeDepartureTime(now, attendanceEndTime) : 0;
  const log = {
    id: `att_${Date.now()}`,
    userId: user.id,
    username: user.username,
    departmentId,
    type,
    lat: Number(lat),
    lng: Number(lng),
    userAgent: req.headers["user-agent"],
    ip: req.ip,
    timestamp: now,
    verified: true,
    attendanceStartTime,
    attendanceEndTime,
    attendanceGraceMinutes: ATTENDANCE_GRACE_MINUTES,
    late,
    lateMinutes,
    earlyDeparture,
    earlyMinutes,
    deductionPending: late || earlyDeparture
  };

  db.attendance.push(log);
  saveDb();
  res.status(201).json({
    message: type === "in"
      ? (late ? "تم تسجيل الدخول، لكن بعد مهلة الحضور وسيتم احتساب خصم" : "تم تسجيل الحضور بنجاح")
      : (earlyDeparture ? "تم تسجيل الانصراف، لكن قبل وقت الانصراف المحدد وسيتم احتساب خصم" : "تم تسجيل الانصراف بنجاح"),
    log
  });
});

app.get("/api/reports", authenticateToken, (req, res) => {
  res.json(buildSummary());
});

app.get("/api/reports/summary", authenticateToken, (req, res) => {
  res.json(buildSummary());
});

app.get("/api/notifications", authenticateToken, (req, res) => {
  const visibleNotifications = db.notifications
    .filter(notification => userCanSeeNotification(notification, req.user))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .map(notification => serializeNotification(notification, req.user.id));

  res.json({
    notifications: visibleNotifications,
    unreadCount: visibleNotifications.filter(notification => !notification.isRead).length
  });
});

app.post("/api/notifications", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  const targetType = req.body.targetType === "users" ? "users" : "all";
  const title = String(req.body.title || "إشعار").trim().slice(0, 80) || "إشعار";
  const message = String(req.body.message || "").trim();
  const targetUserIds = getNotificationRecipientIds(targetType, req.body.targetUserIds, req.user.id);

  if (!message) {
    return res.status(400).json({ message: "اكتب نص الإشعار قبل الإرسال" });
  }

  if (!targetUserIds.length) {
    return res.status(400).json({ message: "حدد موظف واحد على الأقل لاستلام الإشعار" });
  }

  const notification = {
    id: `note_${Date.now()}_${randomBytes(4).toString("hex")}`,
    title,
    message: message.slice(0, 1200),
    targetType,
    targetUserIds,
    senderId: req.user.id,
    senderName: req.user.username,
    createdAt: new Date().toISOString(),
    readBy: []
  };

  db.notifications.push(notification);
  saveDb();
  res.status(201).json(serializeNotification(notification, req.user.id));
});

app.patch("/api/notifications/read-all", authenticateToken, (req, res) => {
  db.notifications.forEach(notification => {
    if (!userCanSeeNotification(notification, req.user)) return;
    if (!Array.isArray(notification.readBy)) notification.readBy = [];
    if (!notification.readBy.includes(req.user.id)) {
      notification.readBy.push(req.user.id);
    }
  });

  saveDb();
  res.json({ message: "تمت قراءة الإشعارات", unreadCount: 0 });
});

app.patch("/api/notifications/:id/read", authenticateToken, (req, res) => {
  const notification = db.notifications.find(item => item.id === req.params.id);

  if (!notification) {
    return res.sendStatus(404);
  }

  if (!userCanSeeNotification(notification, req.user)) {
    return res.status(403).json({ message: "لا يمكنك فتح هذا الإشعار" });
  }

  if (!Array.isArray(notification.readBy)) {
    notification.readBy = [];
  }

  if (!notification.readBy.includes(req.user.id)) {
    notification.readBy.push(req.user.id);
    saveDb();
  }

  res.json(serializeNotification(notification, req.user.id));
});

app.delete("/api/notifications/:id", authenticateToken, authorize(["ADMIN", "MANAGER"]), (req, res) => {
  db.notifications = db.notifications.filter(notification => notification.id !== req.params.id);
  saveDb();
  res.sendStatus(200);
});

app.use("/api", (req, res) => {
  res.status(404).json({ message: `API Route ${req.method} ${req.url} not found` });
});

const distPath = path.join(__dirname, "dist");
app.use(express.static(distPath));

app.get(/.*/, (req, res) => {
  res.sendFile(path.join(distPath, "index.html"));
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Internal Server Error", error: err.message });
});

async function initializeDatabase() {
  db = normalizeDb(await loadDb());
  ensureEmployeeFinanceDepartments();
  ensurePendingPayrollForSalaryEntries();
}

if (require.main === module) {
  initializeDatabase()
    .then(() => {
      app.listen(PORT, () => {
        console.log(`THARA PRODUCTION Manager running on port ${PORT}`);
      });
    })
    .catch(error => {
      console.error("[STARTUP] Database initialization failed:", error.message);
      process.exit(1);
    });
}

module.exports = app;
module.exports.initializeDatabase = initializeDatabase;
