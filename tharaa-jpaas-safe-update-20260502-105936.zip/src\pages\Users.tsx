import React, { useState, useEffect, useMemo } from 'react';
import { Copy, KeyRound, Plus, Users as UsersIcon, Shield, Trash2, Edit3, X, Check } from 'lucide-react';
import Modal from '../components/Modal';

export default function Users() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [departments, setDepartments] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);

  // Form State
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'EMPLOYEE',
    departmentId: 'mgmt',
    salary: '3500',
    accessCode: '',
    isSupplier: false,
    attendanceStartTime: '09:00',
    attendanceEndTime: '17:00'
  });

  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [newPassword, setNewPassword] = useState('');
  const departmentNameById = useMemo(() => {
    return departments.reduce<Record<string, string>>((acc, dept: any) => {
      acc[dept.id] = dept.name;
      return acc;
    }, {});
  }, [departments]);

  useEffect(() => {
    fetchUsers();
    fetchDepartments();
  }, []);

  const fetchDepartments = () => {
    fetch('/api/departments', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(r => r.json())
    .then(data => {
      setDepartments(data);
      if (data.length > 0) {
        setFormData(prev => ({
          ...prev,
          departmentId: data.some((dept: any) => dept.id === prev.departmentId) ? prev.departmentId : data[0].id
        }));
      }
    });
  };

  const handleChangePassword = async () => {
    try {
      const resp = await fetch(`/api/users/${selectedUser.id}/change-password`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ newPassword })
      });
      if (resp.ok) {
        setIsPasswordModalOpen(false);
        setNewPassword('');
        fetchUsers();
        alert('تم تحديث كلمة المرور');
      } else {
        const err = await resp.json();
        alert(err.message || 'تعذر تحديث كلمة المرور');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchUsers = () => {
    setLoading(true);
    fetch('/api/users', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(r => r.json())
    .then(data => {
      setUsers(data);
      setLoading(false);
    });
  };

  const handleOpenAdd = () => {
    setEditingUser(null);
    setFormData({
      username: '',
      password: '',
      role: 'EMPLOYEE',
      departmentId: departments[0]?.id || 'mgmt',
      salary: '3500',
      accessCode: '',
      isSupplier: false,
      attendanceStartTime: '09:00',
      attendanceEndTime: '17:00'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (user: any) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      password: '', // Password usually kept same unless changed
      role: user.role,
      departmentId: user.departmentId || departments[0]?.id || 'mgmt',
      salary: user.salary?.toString() || '0',
      accessCode: user.accessCode || '',
      isSupplier: Boolean(user.isSupplier),
      attendanceStartTime: user.attendanceStartTime || '09:00',
      attendanceEndTime: user.attendanceEndTime || '17:00'
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = editingUser ? `/api/users/${editingUser.id}` : '/api/users';
    const method = editingUser ? 'PATCH' : 'POST';
    
    // Don't send empty password if editing
    const payload = { ...formData };
    if (editingUser && !payload.password) delete (payload as any).password;

    const resp = await fetch(url, {
      method,
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify(payload)
    });

    if (resp.ok) {
      fetchUsers();
      setIsModalOpen(false);
    } else {
      const err = await resp.json();
      alert(err.message);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا الموظف من النظام؟")) return;
    if (id === 'admin_root') return alert("لا يمكن حذف المستخدم الرئيسي");
    
    const resp = await fetch(`/api/users/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (resp.ok) {
      setUsers(users.filter((u: any) => u.id !== id));
    }
  };

  const copyAccessCode = async (code?: string) => {
    if (!code) {
      alert('لا يوجد رمز محفوظ لهذا الموظف. حدّث كلمة المرور مرة واحدة ليظهر هنا.');
      return;
    }

    await navigator.clipboard?.writeText(code);
    alert('تم نسخ رمز الدخول');
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black text-white">الموظفين</h1>
          <p className="text-[#6b7280]">إدارة الكوادر وصلاحيات الوصول والمكافآت (RBAC)</p>
        </div>
        <button 
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
        >
          <Plus size={18} />
          <span>إضافة كادر جديد</span>
        </button>
      </div>

      <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] overflow-x-auto custom-scrollbar">
        <table className="w-full min-w-[980px] text-right">
          <thead className="bg-[#16191e] border-b border-[#1f2127]">
            <tr>
              <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280]">Identity</th>
              <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280]">Role</th>
              <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280]">Salary</th>
              <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280]">Access Code</th>
              <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280]">Attendance</th>
              <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280]">Department</th>
              <th className="px-6 py-4 text-[10px] uppercase font-mono tracking-widest text-[#6b7280]">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f2127]">
            {users.length === 0 ? (
              <tr>
                <td className="px-6 py-12 text-center text-[#4b5563] italic font-mono uppercase tracking-widest" colSpan={7}>
                  {loading ? 'Fetching_HR_Data...' : 'NO_RECORDS_FOUND'}
                </td>
              </tr>
            ) : (
              users.map((user: any) => (
                <tr key={user.id} className="hover:bg-[#16191e] transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#1f2127] flex items-center justify-center text-orange-500 font-black">
                        {user.avatar ? (
                          <img src={user.avatar} alt={user.username} className="w-full h-full rounded-full object-cover" />
                        ) : (
                          user.username[0].toUpperCase()
                        )}
                      </div>
                      <div>
                        <span className="text-white font-bold">{user.displayName || user.username}</span>
                        {user.displayName && user.displayName !== user.username && (
                          <p className="text-[10px] text-[#6b7280] font-mono mt-0.5">{user.username}</p>
                        )}
                        {user.isSupplier && (
                          <p className="text-[10px] text-orange-500 font-bold mt-0.5">موظف + مورد</p>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-mono border px-2 py-0.5 rounded ${
                      user.role === 'ADMIN' ? 'border-red-500/30 text-red-500 bg-red-500/5' :
                      user.role === 'MANAGER' ? 'border-orange-500/30 text-orange-500 bg-orange-500/5' :
                      'border-[#1f2127] text-[#6b7280]'
                    }`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-white font-mono font-bold">
                    {user.salary?.toLocaleString() || 0} <span className="text-[10px] text-[#4b5563]">LYD</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <KeyRound size={15} className="text-orange-500" />
                      <span className="text-white font-mono font-bold">{user.accessCode || 'غير محفوظ'}</span>
                      <button
                        type="button"
                        onClick={() => copyAccessCode(user.accessCode)}
                        className="p-1.5 text-[#6b7280] hover:text-white rounded-lg hover:bg-[#1f2127] transition-all"
                        title="نسخ الرمز"
                      >
                        <Copy size={14} />
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-white font-mono font-bold">
                    {user.attendanceStartTime || '09:00'} - {user.attendanceEndTime || '17:00'}
                  </td>
                  <td className="px-6 py-4 text-[#6b7280] font-bold">{departmentNameById[user.departmentId] || user.departmentId || '-'}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                      <button 
                        onClick={() => {
                          setSelectedUser(user);
                          setIsPasswordModalOpen(true);
                        }}
                        className="p-2 text-orange-500 hover:bg-orange-500/10 rounded-lg transition-colors border border-transparent hover:border-orange-500/20"
                        title="تغيير كلمة المرور"
                      >
                         <Shield size={16} />
                      </button>
                      <button 
                        onClick={() => handleOpenEdit(user)}
                        className="p-2 text-[#6b7280] hover:text-orange-500 transition-all"
                      >
                         <Edit3 size={16} />
                      </button>
                      <button 
                        onClick={() => handleDeleteUser(user.id)}
                        className="p-2 text-red-500/50 hover:text-red-500 transition-all"
                      >
                         <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingUser ? 'تعديل بيانات كادر' : 'إضافة كادر جديد'}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">اسم المستخدم</label>
            <input
              type="text"
              required
              value={formData.username}
              onChange={(e) => setFormData({...formData, username: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="مثال: ahmed_ali"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">كلمة المرور (الرمز الشخصي)</label>
            <input
              type="password"
              required={!editingUser}
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="••••••••"
            />
          </div>

          {editingUser && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">رمز الدخول الظاهر في لوحة الإدارة</label>
              <input
                type="text"
                value={formData.accessCode}
                onChange={(e) => setFormData({...formData, accessCode: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all font-mono"
                placeholder="اكتب رمز جديد لو الموظف نسيه"
              />
              <p className="text-[10px] text-[#6b7280]">عند تغييره سيتم تحديث كلمة مرور الموظف بنفس الرمز.</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">الدور الوظيفي</label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({...formData, role: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              >
                <option value="EMPLOYEE">موظف (EMPLOYEE)</option>
                <option value="FREELANCER">فريلانسر (FREELANCER)</option>
                <option value="MANAGER">مدير (MANAGER)</option>
                <option value="ADMIN">مسؤول (ADMIN)</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">الراتب الأساسي</label>
              <input
                type="number"
                value={formData.salary}
                onChange={(e) => setFormData({...formData, salary: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">القسم التابع له</label>
            <select
              value={formData.departmentId}
              onChange={(e) => setFormData({...formData, departmentId: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            >
              {departments.map((dept: any) => (
                <option key={dept.id} value={dept.id}>{dept.name}</option>
              ))}
            </select>
          </div>

          <label className="flex items-center justify-between gap-4 p-4 bg-[#0a0b0d] border border-[#1f2127] rounded-xl cursor-pointer hover:border-orange-500/40 transition-all">
            <div>
              <p className="text-sm font-bold text-white">موظف + مورد</p>
              <p className="text-[11px] text-[#6b7280] mt-1">يفتح له قسم الموردين لإضافة المشتريات والفواتير.</p>
            </div>
            <input
              type="checkbox"
              checked={formData.isSupplier}
              onChange={(e) => setFormData({ ...formData, isSupplier: e.target.checked })}
              className="w-5 h-5 accent-orange-600"
            />
          </label>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">وقت الحضور اليومي</label>
              <input
                type="time"
                value={formData.attendanceStartTime}
                onChange={(e) => setFormData({...formData, attendanceStartTime: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              />
              <p className="text-[10px] text-[#6b7280]">مهلة الدخول 10 دقائق.</p>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">وقت الانصراف اليومي</label>
              <input
                type="time"
                value={formData.attendanceEndTime}
                onChange={(e) => setFormData({...formData, attendanceEndTime: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-500/20"
            >
              {editingUser ? 'حفظ التغييرات' : 'إضافة الموظف'}
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-6 py-3 bg-[#1f2127] text-white font-bold rounded-xl hover:bg-[#2a2d35] transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
        title={`تعديل رمز الوصول: ${selectedUser?.username}`}
      >
        <div className="space-y-6">
          <div className="p-4 bg-orange-500/5 border border-orange-500/20 rounded-xl">
             <p className="text-[10px] text-orange-500 font-mono uppercase tracking-widest leading-relaxed">
               Security_Protocol: 512-bit Hash Encryption will be applied to the new key.
             </p>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">كلمة المرور الجديدة</label>
            <input 
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] rounded-xl px-4 py-3 text-white focus:border-orange-500 transition-all font-mono"
              placeholder="Min 6 characters"
            />
          </div>
          <button 
            onClick={handleChangePassword}
            className="w-full py-4 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-orange-500/20"
          >
            تحديث رمز الوصول الآمن
          </button>
        </div>
      </Modal>
    </div>
  );
}
