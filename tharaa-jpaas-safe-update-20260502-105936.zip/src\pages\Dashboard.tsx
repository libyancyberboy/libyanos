import React, { useMemo, useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Package,
  CheckCircle2,
  ListTodo,
  FileDown
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { saveArabicReportPdf } from '../lib/pdfArabic';

interface DashboardProps {
  user: any;
}

export default function Dashboard({ user }: DashboardProps) {
  if (!user) return null;
  const [summary, setSummary] = useState({
    totalUsers: 0,
    totalDepartments: 0,
    totalRevenue: 0,
    totalExpenses: 0
  });

  const [personalStats, setPersonalStats] = useState({
    tasksTodo: 0,
    tasksDone: 0,
    totalDeductions: 0
  });

  const [recentTrx, setRecentTrx] = useState([]);
  const [usersList, setUsersList] = useState([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [attendanceQr, setAttendanceQr] = useState({ departmentId: 'mgmt', token: 'ROOT_QR_2025' });

  useEffect(() => {
    if (user.role === 'ADMIN' || user.role === 'MANAGER') {
      const fetchJson = async (url: string) => {
        const r = await fetch(url, { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` } });
        if (!r.ok) {
          const t = await r.text();
          throw new Error(`HTTP ${r.status} ${url}: ${t.substring(0, 50)}`);
        }
        return r.json();
      };

      fetchJson('/api/reports/summary')
      .then(data => setSummary(data))
      .catch(err => console.error("Summary error:", err));

      fetchJson('/api/users')
      .then(data => setUsersList(data))
      .catch(err => console.error("Users error:", err));

      fetchJson('/api/departments')
      .then(data => setDepartments(Array.isArray(data) ? data : []))
      .catch(err => console.error("Departments error:", err));

      fetchJson('/api/attendance/qr-tokens')
      .then(tokens => {
        const firstToken = tokens?.find((token: any) => token.isActive) || tokens?.[0];
        if (firstToken) {
          setAttendanceQr({ departmentId: firstToken.departmentId, token: firstToken.token });
        }
      })
      .catch(err => console.error("QR token error:", err));
    } else {
      const fetchJson = async (url: string) => {
        const r = await fetch(url, { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` } });
        if (!r.ok) {
          const t = await r.text();
          throw new Error(`HTTP ${r.status} ${url}: ${t.substring(0, 50)}`);
        }
        return r.json();
      };

      Promise.all([
        fetchJson('/api/tasks'),
        fetchJson('/api/finance')
      ]).then(([tasks, financeData]) => {
        const transactions = Array.isArray(financeData) ? financeData : (financeData.entries || []);
        const tasksArray = Array.isArray(tasks) ? tasks : [];
        
        // Define salary payment detection
        const isSalaryPayment = (category: string) => 
          category?.includes('راتب') || category?.includes('Salary') || category?.includes('صرف');

        setPersonalStats({
          tasksTodo: tasksArray.filter((t: any) => t.status !== 'done').length,
          tasksDone: tasksArray.filter((t: any) => t.status === 'done').length,
          totalDeductions: transactions
            .filter((f: any) => f.type === 'expense' && !isSalaryPayment(f.category))
            .reduce((a: any, b: any) => a + (b.amount || 0), 0)
        });
      }).catch(err => {
        console.error("Personal stats fetch error:", err);
      });
    }

    fetch('/api/finance', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(async r => {
      if (!r.ok) {
        const text = await r.text();
        throw new Error(`HTTP ${r.status}: ${text.substring(0, 100)}`);
      }
      return r.json();
    })
    .then(data => {
      // Admin/Manager get array, employees get { salary, entries }
      const transactions = Array.isArray(data) ? data : (data.entries || []);
      setRecentTrx(transactions.slice(0, 5));
    })
    .catch(err => console.error("Error fetching finance for dashboard:", err));
  }, [user]);

  const departmentNameById = useMemo(() => {
    return departments.reduce<Record<string, string>>((acc, dept: any) => {
      acc[dept.id] = dept.name;
      return acc;
    }, {});
  }, [departments]);

  const getDepartmentName = (departmentId?: string) => (
    departmentId ? (departmentNameById[departmentId] || departmentId) : 'عام'
  );

  const svgToPng = async (svg: Element) => {
    const svgData = new XMLSerializer().serializeToString(svg);
    const img = new Image();
    const source = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));

    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = reject;
      img.src = source;
    });

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 420;
    canvas.height = 420;
    if (!ctx) throw new Error('Canvas is not available.');
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 20, 20, 380, 380);
    return canvas.toDataURL('image/png');
  };

  const downloadQRCode = async () => {
    const svg = document.getElementById('attendance-qr');
    if (!svg) return;
    const qrData = await svgToPng(svg);
    await saveArabicReportPdf({
      filename: 'attendance_qr.pdf',
      title: 'رمز QR لتسجيل الحضور والانصراف',
      subtitle: 'THARA PRODUCTION',
      meta: [{ label: 'القسم', value: getDepartmentName(attendanceQr.departmentId) }],
      contentHtml: `
        <div class="qr-card">
          <img src="${qrData}" alt="Attendance QR" />
          <p>قم بمسح الكود عبر تطبيق الموظف لتسجيل الحضور</p>
        </div>
      `,
      footer: ['THARA PRODUCTION']
    });
  };

  const isAdmin = user.role === 'ADMIN' || user.role === 'MANAGER';

  const stats = isAdmin ? [
    { label: 'إجمالي الموظفين', value: summary.totalUsers, icon: Users, color: 'text-blue-500' },
    { label: 'إجمالي الأقسام', value: summary.totalDepartments, icon: Package, color: 'text-orange-600' },
    { label: 'الدخل الكلي', value: summary.totalRevenue.toLocaleString() + ' LYD', icon: TrendingUp, color: 'text-green-500' },
    { label: 'إجمالي المصاريف', value: summary.totalExpenses.toLocaleString() + ' LYD', icon: TrendingDown, color: 'text-orange-700' },
  ] : [
    { label: 'مهام قيد الإنجاز', value: personalStats.tasksTodo, icon: ListTodo, color: 'text-orange-500' },
    { label: 'مهام مكتملة', value: personalStats.tasksDone, icon: CheckCircle2, color: 'text-green-500' },
    { label: 'إجمالي الخصميات', value: personalStats.totalDeductions.toLocaleString() + ' LYD', icon: TrendingDown, color: 'text-orange-700' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-black text-white">لوحة التحكم</h1>
        <p className="text-[#6b7280]">نظرة عامة على أداء المنظومة (Live_Link)</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-[#111318] p-5 sm:p-6 border border-[#1f2127] rounded-2xl relative overflow-hidden">
            <div className="flex items-center justify-between gap-4">
              <div className={`p-4 rounded-2xl bg-[#0a0b0d] border border-[#1f2127] ${stat.color} shrink-0`}>
                <stat.icon size={28} />
              </div>
              <p className="text-3xl sm:text-4xl font-black text-white tracking-tight text-left flex-1 break-words">{stat.value}</p>
            </div>
            <p className="mt-4 text-sm font-bold text-[#9ca3af]">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 overflow-hidden">
            <div className="flex items-center justify-between mb-6">
               <h3 className="text-sm font-black text-[#6b7280] uppercase font-mono tracking-widest">Recent_Activity_Log</h3>
               <span className="text-[10px] font-mono text-orange-500">LEDGER_FEED</span>
            </div>
            <div className="space-y-4">
              {recentTrx.length === 0 ? (
                <div className="py-12 text-center">
                   <p className="text-[#4b5563] italic font-mono uppercase tracking-[0.3em]">No_Activity_Detected</p>
                </div>
              ) : (
                recentTrx.map((trx: any) => (
                  <div key={trx.id} className="flex items-center justify-between p-4 bg-[#0a0b0d] border border-[#1f2127] rounded-2xl">
                     <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${trx.type === 'income' ? 'bg-green-500' : 'bg-orange-500'}`}></div>
                        <div>
                           <p className="text-xs font-bold text-white">{trx.type === 'income' ? 'إيراد' : 'مصروف'} - {trx.category || 'عام'}</p>
                           <p className="text-[10px] text-[#6b7280]">
                             القسم: <span className="text-orange-500 font-bold">{getDepartmentName(trx.departmentId)}</span> · {new Date(trx.timestamp).toLocaleTimeString()}
                           </p>
                        </div>
                     </div>
                     <span className={`text-xs font-mono font-bold ${trx.type === 'income' ? 'text-green-500' : 'text-orange-500'}`}>
                        {trx.type === 'income' ? '+' : '-'}{trx.amount}
                     </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {isAdmin && (
            <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 overflow-hidden">
              <div className="flex items-center justify-between mb-6">
                 <h3 className="text-sm font-black text-[#6b7280] uppercase font-mono tracking-widest">Employee_Database</h3>
                 <span className="text-[10px] font-mono text-orange-500">STAFF_VIEW</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {usersList.slice(0, 4).map((u: any) => (
                  <div key={u.id} className="flex items-center gap-4 p-4 bg-[#0a0b0d] border border-[#1f2127] rounded-2xl hover:border-orange-500/50 transition-all cursor-pointer">
                    <div className="w-10 h-10 rounded-full bg-orange-600/20 border border-orange-500/30 flex items-center justify-center text-orange-500 font-black">
                      {u.username?.[0]?.toUpperCase()}
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <p className="text-sm font-bold text-white truncate">{u.username}</p>
                      <p className="text-[10px] text-[#4b5563] uppercase italic">{u.role} | {getDepartmentName(u.departmentId)} | {u.salary} LYD</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {isAdmin ? (
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 flex flex-col items-center justify-center text-center">
            <h3 className="text-sm font-black text-[#6b7280] uppercase font-mono tracking-widest mb-6">Attendance_QR</h3>
            <div className="bg-white p-4 rounded-3xl mb-6 shadow-[0_0_50px_rgba(249,115,22,0.15)]">
               <QRCodeSVG 
                 id="attendance-qr"
                 value={`${window.location.origin}/attendance?dept=${attendanceQr.departmentId}&token=${attendanceQr.token}`}
                 size={160}
                 level="H"
               />
            </div>
            <p className="text-[10px] text-[#6b7280] font-mono uppercase tracking-wider mb-6">رمز ثابت لتسجيل الحضور</p>
            <button 
              onClick={downloadQRCode}
              className="w-full py-4 bg-orange-500 hover:bg-orange-600 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all flex items-center justify-center gap-2 group"
            >
              <FileDown size={18} className="group-hover:translate-y-0.5 transition-transform" />
              طباعة PDF
            </button>
          </div>
        ) : (
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 flex flex-col items-center justify-center">
            <p className="text-[#4b5563] italic font-mono uppercase tracking-[0.3em] mb-4">Traffic_Monitor</p>
            <div className="w-full h-1 bg-[#1f2127] rounded-full overflow-hidden">
               <div className="w-1/3 h-full bg-orange-600"></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
