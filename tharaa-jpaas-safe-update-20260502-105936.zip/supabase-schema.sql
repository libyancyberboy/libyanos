create table if not exists public.tharaa_app_state (
  id text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.tharaa_app_state enable row level security;
