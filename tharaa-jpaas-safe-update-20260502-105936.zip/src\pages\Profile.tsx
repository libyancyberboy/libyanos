import React, { useEffect, useState } from 'react';
import { Camera, Save, Trash2, UserCircle2 } from 'lucide-react';

interface ProfileProps {
  user: any;
  onUserUpdate: (user: any) => void;
}

const compressAvatar = (file: File) => new Promise<string>((resolve, reject) => {
  if (!file.type.startsWith('image/')) {
    reject(new Error('اختار ملف صورة فقط'));
    return;
  }

  const image = new Image();
  const objectUrl = URL.createObjectURL(file);

  image.onload = () => {
    URL.revokeObjectURL(objectUrl);
    const maxSize = 512;
    const ratio = Math.min(1, maxSize / Math.max(image.width, image.height));
    const width = Math.max(1, Math.round(image.width * ratio));
    const height = Math.max(1, Math.round(image.height * ratio));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      reject(new Error('تعذر تجهيز الصورة'));
      return;
    }

    ctx.fillStyle = '#0a0b0d';
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(image, 0, 0, width, height);
    resolve(canvas.toDataURL('image/jpeg', 0.82));
  };

  image.onerror = () => {
    URL.revokeObjectURL(objectUrl);
    reject(new Error('تعذر قراءة الصورة'));
  };

  image.src = objectUrl;
});

export default function Profile({ user, onUserUpdate }: ProfileProps) {
  const [account, setAccount] = useState<any>(user || {});
  const [displayName, setDisplayName] = useState(user?.displayName || user?.username || '');
  const [avatar, setAvatar] = useState(user?.avatar || '');
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);
  const [loadingImage, setLoadingImage] = useState(false);

  useEffect(() => {
    fetch('/api/users/me', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    })
      .then((response) => response.ok ? response.json() : null)
      .then((data) => {
        if (!data) return;
        setAccount(data);
        setDisplayName(data.displayName || data.username || '');
        setAvatar(data.avatar || '');
        localStorage.setItem('user', JSON.stringify(data));
        onUserUpdate(data);
      })
      .catch(() => undefined);
  }, []);

  const handleAvatarChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setMessage('');
    setLoadingImage(true);
    try {
      const dataUrl = await compressAvatar(file);
      if (dataUrl.length > 900000) {
        setMessage('الصورة كبيرة حتى بعد الضغط، جرّب صورة أخف');
        return;
      }
      setAvatar(dataUrl);
    } catch (error: any) {
      setMessage(error.message || 'تعذر تحميل الصورة');
    } finally {
      setLoadingImage(false);
      event.target.value = '';
    }
  };

  const saveProfile = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setMessage('');

    const response = await fetch('/api/users/me/profile', {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({
        displayName,
        avatar,
      }),
    });

    const data = await response.json().catch(() => ({}));
    setSaving(false);

    if (!response.ok) {
      setMessage(data.message || 'تعذر حفظ إعدادات الحساب');
      return;
    }

    setAccount(data);
    setDisplayName(data.displayName || data.username || '');
    setAvatar(data.avatar || '');
    localStorage.setItem('user', JSON.stringify(data));
    onUserUpdate(data);
    setMessage('تم حفظ إعدادات الحساب');
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-10">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-orange-600/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
          <UserCircle2 size={25} />
        </div>
        <div>
          <h1 className="text-3xl font-black text-white">حسابي</h1>
          <p className="text-[#6b7280] text-sm">إعدادات البروفايل وصورة الحساب</p>
        </div>
      </div>

      <form onSubmit={saveProfile} className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-5 sm:p-8 max-w-3xl space-y-7">
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="relative">
            <div className="w-32 h-32 rounded-[2rem] overflow-hidden bg-[#0a0b0d] border border-[#1f2127] flex items-center justify-center">
              {avatar ? (
                <img src={avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <UserCircle2 size={62} className="text-[#343842]" />
              )}
            </div>
            <label className="absolute -bottom-3 -left-3 w-11 h-11 rounded-2xl bg-orange-600 hover:bg-orange-500 text-white flex items-center justify-center cursor-pointer shadow-lg shadow-orange-500/20">
              <Camera size={19} />
              <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </label>
          </div>

          <div className="flex-1 w-full space-y-3 text-center sm:text-right">
            <h2 className="text-2xl font-black text-white">{account.displayName || account.username}</h2>
            <p className="text-sm text-[#6b7280]">{account.role} | {account.departmentName || account.departmentId || 'بدون قسم'}</p>
            <div className="flex flex-col sm:flex-row gap-3">
              <label className="inline-flex items-center justify-center gap-2 px-4 py-3 bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl cursor-pointer hover:border-orange-500/50 transition-all font-bold">
                <Camera size={17} />
                {loadingImage ? 'جاري تجهيز الصورة' : 'اختيار صورة'}
                <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
              </label>
              {avatar && (
                <button
                  type="button"
                  onClick={() => setAvatar('')}
                  className="inline-flex items-center justify-center gap-2 px-4 py-3 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl hover:bg-red-500/15 transition-all font-bold"
                >
                  <Trash2 size={17} />
                  حذف الصورة
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-[#6b7280]">اسم العرض</label>
          <input
            value={displayName}
            onChange={(event) => setDisplayName(event.target.value)}
            className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            placeholder={account.username || 'اسم العرض'}
            maxLength={80}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
            <p className="text-[10px] text-[#6b7280] mb-1">اسم الدخول</p>
            <p className="text-white font-bold">{account.username}</p>
          </div>
          <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
            <p className="text-[10px] text-[#6b7280] mb-1">الصلاحية</p>
            <p className="text-white font-bold">{account.role}</p>
          </div>
        </div>

        {message && (
          <div className={`rounded-2xl p-4 text-sm font-bold ${message.includes('تعذر') || message.includes('كبيرة') ? 'bg-red-500/10 border border-red-500/20 text-red-500' : 'bg-green-500/10 border border-green-500/20 text-green-500'}`}>
            {message}
          </div>
        )}

        <button
          type="submit"
          disabled={saving || loadingImage}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-black rounded-2xl transition-all shadow-lg shadow-orange-500/20"
        >
          <Save size={18} />
          {saving ? 'جاري الحفظ' : 'حفظ الحساب'}
        </button>
      </form>
    </div>
  );
}
