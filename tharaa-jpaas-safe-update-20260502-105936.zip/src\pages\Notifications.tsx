import React, { useEffect, useMemo, useState } from 'react';
import { Bell, CheckCircle2, Megaphone, Send, Smartphone, Trash2, UserCheck, Users, Volume2 } from 'lucide-react';
import { getDeviceNotificationPermission, playNotificationSound, requestDeviceNotificationPermission } from '../lib/deviceNotifications';

interface NotificationsProps {
  user: any;
  onReadAll?: () => void;
}

type TargetMode = 'all' | 'users';

export default function Notifications({ user, onReadAll }: NotificationsProps) {
  const canManage = user?.role === 'ADMIN' || user?.role === 'MANAGER';
  const [notifications, setNotifications] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [devicePermission, setDevicePermission] = useState(getDeviceNotificationPermission());
  const [targetMode, setTargetMode] = useState<TargetMode>('all');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    message: ''
  });

  const token = localStorage.getItem('token');

  const recipients = useMemo(
    () => usersList.filter((item: any) => item.role !== 'ADMIN' && item.id !== user?.id),
    [usersList, user?.id]
  );

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/notifications', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      const list = Array.isArray(data.notifications) ? data.notifications : [];
      const unreadCount = Number.isFinite(Number(data?.unreadCount))
        ? Number(data.unreadCount)
        : list.filter((item: any) => !item.isRead).length;

      setNotifications(unreadCount > 0 ? list.map((item: any) => ({ ...item, isRead: true })) : list);
      onReadAll?.();

      if (unreadCount > 0) {
        fetch('/api/notifications/read-all', {
          method: 'PATCH',
          headers: { Authorization: `Bearer ${token}` }
        }).catch(() => undefined);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    if (!canManage) return;
    try {
      const response = await fetch('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setUsersList(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchNotifications();
    fetchUsers();
  }, []);

  const toggleUser = (id: string) => {
    setSelectedUserIds(current => (
      current.includes(id) ? current.filter(item => item !== id) : [...current, id]
    ));
  };

  const handleSend = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!formData.message.trim()) {
      alert('اكتب نص الإشعار قبل الإرسال');
      return;
    }

    if (targetMode === 'users' && selectedUserIds.length === 0) {
      alert('حدد موظف واحد على الأقل');
      return;
    }

    setSending(true);
    try {
      const response = await fetch('/api/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          targetType: targetMode,
          targetUserIds: selectedUserIds,
          title: formData.title || 'إشعار',
          message: formData.message
        })
      });

      if (!response.ok) {
        const error = await response.json();
        alert(error.message || 'تعذر إرسال الإشعار');
        return;
      }

      setFormData({ title: '', message: '' });
      setSelectedUserIds([]);
      setTargetMode('all');
      await fetchNotifications();
    } finally {
      setSending(false);
    }
  };

  const markAsRead = async (id: string) => {
    const response = await fetch(`/api/notifications/${id}/read`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}` }
    });

    if (response.ok) {
      const updated = await response.json();
      setNotifications(current => current.map(item => item.id === id ? updated : item));
    }
  };

  const deleteNotification = async (id: string) => {
    if (!confirm('حذف هذا الإشعار من السجل؟')) return;

    const response = await fetch(`/api/notifications/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });

    if (response.ok) {
      setNotifications(current => current.filter(item => item.id !== id));
    }
  };

  const selectAllRecipients = () => {
    setSelectedUserIds(recipients.map((item: any) => item.id));
  };

  const enableDeviceNotifications = async () => {
    const permission = await requestDeviceNotificationPermission();
    setDevicePermission(permission);
    if (permission === 'granted') {
      playNotificationSound();
      alert('تم تفعيل إشعارات الهاتف لهذا الجهاز');
    } else if (permission === 'denied') {
      alert('المتصفح مانع الإشعارات. افتح إعدادات الموقع وفعّل Notifications.');
    } else if (permission === 'unsupported') {
      alert('هذا المتصفح لا يدعم إشعارات الهاتف');
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-orange-600/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
            <Bell size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-white">الإشعارات</h1>
            <p className="text-[#6b7280] text-sm">رسائل داخلية للموظفين والتنبيهات العامة</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={enableDeviceNotifications}
            className={`flex items-center justify-center gap-2 px-5 py-3 rounded-2xl border font-bold transition-all ${
              devicePermission === 'granted'
                ? 'bg-green-500/10 border-green-500/25 text-green-500'
                : 'bg-[#111318] border-orange-500/25 text-orange-500 hover:bg-orange-600 hover:text-white'
            }`}
          >
            {devicePermission === 'granted' ? <Volume2 size={18} /> : <Smartphone size={18} />}
            {devicePermission === 'granted' ? 'إشعارات الهاتف مفعلة' : 'تفعيل إشعارات الهاتف'}
          </button>
          <div className="bg-[#111318] border border-[#1f2127] rounded-2xl px-5 py-3">
            <p className="text-xs text-[#6b7280]">{canManage ? 'إجمالي السجل' : 'غير مقروء'}</p>
            <p className="text-2xl font-black text-white">
              {canManage ? notifications.length : notifications.filter(item => !item.isRead).length}
            </p>
          </div>
        </div>
      </div>

      <div className={`grid grid-cols-1 ${canManage ? 'xl:grid-cols-[420px_1fr]' : ''} gap-6`}>
        {canManage && (
          <form onSubmit={handleSend} className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-5 sm:p-6 h-fit space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-orange-600/10 text-orange-500 flex items-center justify-center">
                <Send size={20} />
              </div>
              <div>
                <h2 className="text-lg font-black text-white">إرسال إشعار</h2>
                <p className="text-xs text-[#6b7280]">نفس الرسالة لموظف أو لكل الموظفين</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-[#0a0b0d] border border-[#1f2127] rounded-xl p-1">
              <button
                type="button"
                onClick={() => setTargetMode('all')}
                className={`flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-bold transition-all ${targetMode === 'all' ? 'bg-orange-600 text-white' : 'text-[#6b7280] hover:text-white'}`}
              >
                <Megaphone size={16} />
                عام
              </button>
              <button
                type="button"
                onClick={() => setTargetMode('users')}
                className={`flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-bold transition-all ${targetMode === 'users' ? 'bg-orange-600 text-white' : 'text-[#6b7280] hover:text-white'}`}
              >
                <UserCheck size={16} />
                موظفين
              </button>
            </div>

            {targetMode === 'users' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <label className="text-xs font-bold text-[#6b7280]">المستلمين</label>
                  <div className="flex gap-2">
                    <button type="button" onClick={selectAllRecipients} className="text-xs text-orange-500 font-bold">
                      تحديد الكل
                    </button>
                    <button type="button" onClick={() => setSelectedUserIds([])} className="text-xs text-[#6b7280] font-bold">
                      مسح
                    </button>
                  </div>
                </div>
                <div className="max-h-56 overflow-y-auto custom-scrollbar space-y-2 pr-1">
                  {recipients.map((item: any) => (
                    <label key={item.id} className="flex items-center justify-between gap-3 bg-[#0a0b0d] border border-[#1f2127] rounded-xl p-3 cursor-pointer hover:border-orange-500/40">
                      <span className="text-sm font-bold text-white">{item.username}</span>
                      <input
                        type="checkbox"
                        checked={selectedUserIds.includes(item.id)}
                        onChange={() => toggleUser(item.id)}
                        className="w-5 h-5 accent-orange-600"
                      />
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">العنوان</label>
              <input
                type="text"
                value={formData.title}
                onChange={(event) => setFormData({ ...formData, title: event.target.value })}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
                placeholder="مثال: تنبيه مهم"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">نص الإشعار</label>
              <textarea
                value={formData.message}
                onChange={(event) => setFormData({ ...formData, message: event.target.value })}
                className="w-full min-h-[150px] bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all resize-none"
                placeholder="اكتب الرسالة التي ستصل للموظفين"
              />
            </div>

            <button
              type="submit"
              disabled={sending}
              className="w-full flex items-center justify-center gap-2 py-4 bg-orange-600 hover:bg-orange-500 disabled:opacity-60 text-white font-black rounded-2xl transition-all shadow-lg shadow-orange-500/20"
            >
              <Send size={18} />
              {sending ? 'جاري الإرسال' : 'إرسال الإشعار'}
            </button>
          </form>
        )}

        <div className="space-y-4">
          {loading ? (
            <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-10 text-center text-[#6b7280] font-bold">
              جاري تحميل الإشعارات
            </div>
          ) : notifications.length === 0 ? (
            <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-10 text-center">
              <Bell className="mx-auto text-[#343842] mb-4" size={36} />
              <p className="text-[#6b7280] font-bold">لا توجد إشعارات حالياً</p>
            </div>
          ) : (
            notifications.map((item: any) => (
              <div
                key={item.id}
                className={`bg-[#111318] border rounded-[1.5rem] p-5 sm:p-6 transition-all ${item.isRead || canManage ? 'border-[#1f2127]' : 'border-orange-500/60 shadow-lg shadow-orange-500/10'}`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-xl font-black text-white">{item.title || 'إشعار'}</h3>
                      {!item.isRead && !canManage && (
                        <span className="px-2 py-1 rounded-full bg-orange-600/15 text-orange-500 text-[10px] font-black">
                          جديد
                        </span>
                      )}
                    </div>
                    <p className="text-[#d1d5db] leading-8 whitespace-pre-wrap">{item.message}</p>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-[#6b7280]">
                      <span>المرسل: {item.senderName}</span>
                      <span>{new Date(item.createdAt).toLocaleString('ar-LY')}</span>
                      {canManage && (
                        <span className="flex items-center gap-1">
                          <Users size={14} />
                          {item.targetLabel || 'موظفين'}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {!item.isRead && !canManage && (
                      <button
                        type="button"
                        onClick={() => markAsRead(item.id)}
                        className="p-3 text-green-500 hover:bg-green-500/10 border border-green-500/20 rounded-xl transition-all"
                        title="تحديد كمقروء"
                      >
                        <CheckCircle2 size={18} />
                      </button>
                    )}
                    {canManage && (
                      <button
                        type="button"
                        onClick={() => deleteNotification(item.id)}
                        className="p-3 text-red-500 hover:bg-red-500/10 border border-red-500/20 rounded-xl transition-all"
                        title="حذف الإشعار"
                      >
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
