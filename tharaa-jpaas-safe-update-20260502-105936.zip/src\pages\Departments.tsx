import React, { useEffect, useMemo, useState } from 'react';
import { Plus, Building2, Trash2, Settings2, ArrowUpRight, ArrowDownRight, FileDown, WalletCards, Edit3 } from 'lucide-react';
import Modal from '../components/Modal';
import { saveArabicReportPdf } from '../lib/pdfArabic';

interface DepartmentsProps {
  user: any;
}

interface Department {
  id: string;
  name: string;
  description?: string;
  config?: {
    budgetLimit?: number;
    [key: string]: any;
  };
}

interface FinanceEntry {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category?: string;
  notes?: string;
  departmentId?: string;
  timestamp?: string;
}

type FinanceType = 'income' | 'expense';

export default function Departments({ user }: DepartmentsProps) {
  const [depts, setDepts] = useState<Department[]>([]);
  const [finance, setFinance] = useState<FinanceEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [financeDept, setFinanceDept] = useState<Department | null>(null);
  const [editingFinanceEntry, setEditingFinanceEntry] = useState<FinanceEntry | null>(null);
  const [financeType, setFinanceType] = useState<FinanceType>('income');
  const [isFinanceModalOpen, setIsFinanceModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    budgetLimit: '0'
  });

  const [financeForm, setFinanceForm] = useState({
    category: '',
    amount: '',
    notes: ''
  });

  const isAdmin = user?.role === 'ADMIN';
  const canManageMoney = user?.role === 'ADMIN' || user?.role === 'MANAGER';

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    setLoading(true);
    await Promise.all([fetchDepts(), fetchFinance()]);
    setLoading(false);
  };

  const fetchDepts = async () => {
    const resp = await fetch('/api/departments', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    const data = await resp.json();
    setDepts(Array.isArray(data) ? data : []);
  };

  const fetchFinance = async () => {
    const resp = await fetch('/api/finance?includeEmployee=1', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    const data = await resp.json();
    setFinance(Array.isArray(data) ? data : []);
  };

  const departmentFinance = useMemo(() => {
    return depts.reduce<Record<string, { entries: FinanceEntry[]; income: number; expenses: number; profit: number }>>((acc, dept) => {
      const entries = finance.filter(entry => entry.departmentId === dept.id);
      const income = entries.filter(entry => entry.type === 'income').reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
      const expenses = entries.filter(entry => entry.type === 'expense').reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
      acc[dept.id] = { entries, income, expenses, profit: income - expenses };
      return acc;
    }, {});
  }, [depts, finance]);

  const handleOpenAdd = () => {
    setEditingDept(null);
    setFormData({ name: '', description: '', budgetLimit: '0' });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (dept: Department) => {
    setEditingDept(dept);
    setFormData({
      name: dept.name,
      description: dept.description || '',
      budgetLimit: dept.config?.budgetLimit?.toString() || '0'
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = editingDept ? `/api/departments/${editingDept.id}` : '/api/departments';
    const method = editingDept ? 'PATCH' : 'POST';

    const payload = {
      name: formData.name,
      description: formData.description,
      config: { ...editingDept?.config, budgetLimit: parseFloat(formData.budgetLimit) || 0 }
    };

    const resp = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify(payload)
    });

    if (resp.ok) {
      await fetchDepts();
      setIsModalOpen(false);
    } else {
      const err = await resp.json();
      alert(err.message || 'تعذر حفظ بيانات القسم');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('هل تريد حذف هذا القسم؟ سيؤثر ذلك على ارتباطات الموظفين.')) return;
    const resp = await fetch(`/api/departments/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (resp.ok) {
      setDepts(depts.filter(dept => dept.id !== id));
    }
  };

  const openFinanceModal = (dept: Department, type: FinanceType) => {
    setFinanceDept(dept);
    setEditingFinanceEntry(null);
    setFinanceType(type);
    setFinanceForm({
      category: type === 'income' ? 'إيراد القسم' : 'مصروف القسم',
      amount: '',
      notes: ''
    });
    setIsFinanceModalOpen(true);
  };

  const openEditFinanceModal = (dept: Department, entry: FinanceEntry) => {
    setFinanceDept(dept);
    setEditingFinanceEntry(entry);
    setFinanceType(entry.type);
    setFinanceForm({
      category: entry.category || '',
      amount: String(entry.amount || ''),
      notes: entry.notes || ''
    });
    setIsFinanceModalOpen(true);
  };

  const handleFinanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!financeDept) return;

    const resp = await fetch(editingFinanceEntry ? `/api/finance/${editingFinanceEntry.id}` : '/api/finance', {
      method: editingFinanceEntry ? 'PATCH' : 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({
        type: financeType,
        amount: parseFloat(financeForm.amount),
        category: financeForm.category,
        notes: financeForm.notes,
        departmentId: financeDept.id
      })
    });

    if (resp.ok) {
      await fetchFinance();
      setIsFinanceModalOpen(false);
      setEditingFinanceEntry(null);
    } else {
      const err = await resp.json();
      alert(err.message || 'تعذر تسجيل العملية المالية');
    }
  };

  const handleDeleteFinanceEntry = async (entryId: string) => {
    if (!confirm('هل تريد حذف هذه العملية المالية؟')) return;
    const resp = await fetch(`/api/finance/${entryId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });

    if (resp.ok) {
      setFinance(current => current.filter(entry => entry.id !== entryId));
    } else {
      const err = await resp.json().catch(() => ({}));
      alert(err.message || 'تعذر حذف العملية');
    }
  };

  const exportDepartmentReport = async (dept: Department) => {
    const stats = departmentFinance[dept.id] || { entries: [], income: 0, expenses: 0, profit: 0 };
    await saveArabicReportPdf({
      filename: `department-${dept.id}-report-${Date.now()}.pdf`,
      title: `تقرير القسم المالي - ${dept.name}`,
      meta: [
        { label: 'القسم', value: dept.name },
        { label: 'تاريخ التصدير', value: new Date().toLocaleString('ar-LY') },
        { label: 'سقف الميزانية', value: `${(dept.config?.budgetLimit || 0).toLocaleString()} LYD` }
      ],
      summary: [
        { label: 'الإيرادات', value: `${stats.income.toLocaleString()} LYD`, tone: 'green' },
        { label: 'المصاريف', value: `${stats.expenses.toLocaleString()} LYD`, tone: 'orange' },
        { label: 'الصافي', value: `${stats.profit.toLocaleString()} LYD`, tone: 'dark' }
      ],
      table: {
        title: `حركات قسم ${dept.name}`,
        head: ['التاريخ', 'القسم', 'النوع', 'الفئة', 'المبلغ', 'ملاحظات'],
        rows: stats.entries.map(entry => [
          entry.timestamp ? new Date(entry.timestamp).toLocaleDateString('ar-LY') : '-',
          dept.name,
          entry.type === 'income' ? 'إيراد' : 'مصروف',
          entry.category || '-',
          `${Number(entry.amount || 0).toLocaleString()} LYD`,
          entry.notes || '-'
        ])
      },
      footer: [`القسم: ${dept.name}`]
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black text-white">الأقسام</h1>
          <p className="text-[#6b7280]">إدارة الأقسام مع مصاريف وأرباح وتقرير مستقل لكل قسم</p>
        </div>
        {isAdmin && (
          <button
            onClick={handleOpenAdd}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
          >
            <Plus size={18} />
            <span>إضافة قسم جديد</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {depts.length === 0 ? (
          <div className="lg:col-span-2 py-20 flex flex-col items-center justify-center text-[#4b5563] border-2 border-dashed border-[#1f2127] rounded-[2rem]">
            <Building2 size={48} className="mb-4 opacity-20" />
            <p className="font-mono uppercase tracking-[0.2em] font-bold">{loading ? 'Loading_Nodes...' : 'No_Departments_Found'}</p>
          </div>
        ) : (
          depts.map((dept) => {
            const stats = departmentFinance[dept.id] || { entries: [], income: 0, expenses: 0, profit: 0 };
            return (
              <div key={dept.id} className="bg-[#111318] p-6 border border-[#1f2127] rounded-[2rem] technical-card group space-y-6">
                <div className="flex justify-between items-start gap-4">
                  <div className="flex items-start gap-4 min-w-0">
                    <div className="p-3 rounded-2xl bg-[#0a0b0d] border border-[#1f2127] text-orange-500 shrink-0">
                      <Building2 size={24} />
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-lg font-bold text-white">{dept.name}</h3>
                        <span className="text-[9px] font-mono text-[#4b5563] uppercase bg-[#0a0b0d] px-2 py-0.5 rounded border border-[#1f2127]">{dept.id}</span>
                      </div>
                      <p className="text-xs text-[#6b7280] leading-relaxed mt-1">{dept.description || 'وحدة تنظيمية نشطة ضمن الهيكل الإداري.'}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => handleOpenEdit(dept)}
                      className="p-2 text-[#6b7280] hover:text-white transition-all"
                      title="تعديل القسم"
                    >
                      <Settings2 size={16} />
                    </button>
                    {isAdmin && (
                      <button
                        onClick={() => handleDelete(dept.id)}
                        className="p-2 text-red-500/50 hover:text-red-500 transition-all"
                        title="حذف القسم"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
                    <p className="text-[10px] text-green-500 mb-1">الإيرادات</p>
                    <p className="text-xl font-black text-white">{stats.income.toLocaleString()} <span className="text-[10px] text-green-500">LYD</span></p>
                  </div>
                  <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
                    <p className="text-[10px] text-orange-500 mb-1">المصاريف</p>
                    <p className="text-xl font-black text-white">{stats.expenses.toLocaleString()} <span className="text-[10px] text-orange-500">LYD</span></p>
                  </div>
                  <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
                    <p className="text-[10px] text-[#6b7280] mb-1">الصافي</p>
                    <p className={`text-xl font-black ${stats.profit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {stats.profit.toLocaleString()} <span className="text-[10px]">LYD</span>
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t border-[#1f2127] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-[10px] text-[#4b5563] font-mono">
                    <WalletCards size={14} className="text-orange-500" />
                    <span>BUDGET_CAP: {(dept.config?.budgetLimit || 0).toLocaleString()} LYD</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {canManageMoney && (
                      <>
                        <button
                          onClick={() => openFinanceModal(dept, 'expense')}
                          className="flex items-center gap-2 px-3 py-2 bg-[#0a0b0d] border border-orange-500/20 text-orange-500 text-xs font-bold rounded-xl hover:bg-orange-600 hover:text-white transition-all"
                        >
                          <ArrowDownRight size={14} />
                          مصروف
                        </button>
                        <button
                          onClick={() => openFinanceModal(dept, 'income')}
                          className="flex items-center gap-2 px-3 py-2 bg-[#0a0b0d] border border-green-500/20 text-green-500 text-xs font-bold rounded-xl hover:bg-green-600 hover:text-white transition-all"
                        >
                          <ArrowUpRight size={14} />
                          إيراد
                        </button>
                      </>
                    )}
                    <button
                      onClick={() => exportDepartmentReport(dept)}
                      className="flex items-center gap-2 px-3 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl hover:bg-orange-500 transition-all"
                    >
                      <FileDown size={14} />
                      تقرير
                    </button>
                  </div>
                </div>

                {stats.entries.length > 0 && (
                  <div className="pt-4 border-t border-[#1f2127] space-y-2">
                    <p className="text-[10px] text-[#6b7280] font-bold">آخر عمليات القسم</p>
                    <div className="space-y-2 max-h-56 overflow-y-auto custom-scrollbar pr-1">
                      {stats.entries.slice(0, 8).map((entry) => (
                        <div key={entry.id} className="bg-[#0a0b0d] border border-[#1f2127] rounded-xl p-3 flex items-center justify-between gap-3">
                          <div className="min-w-0">
                            <p className="text-sm font-bold text-white truncate">{entry.category || (entry.type === 'income' ? 'إيراد' : 'مصروف')}</p>
                            <p className="text-[10px] text-[#6b7280] truncate">
                              {entry.timestamp ? new Date(entry.timestamp).toLocaleDateString('ar-LY') : '-'} · {entry.notes || 'بدون ملاحظات'}
                            </p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className={`font-black text-sm ${entry.type === 'income' ? 'text-green-500' : 'text-orange-500'}`}>
                              {entry.type === 'income' ? '+' : '-'}{Number(entry.amount || 0).toLocaleString()}
                            </span>
                            {canManageMoney && (
                              <button
                                type="button"
                                onClick={() => openEditFinanceModal(dept, entry)}
                                className="p-2 text-[#6b7280] hover:text-white rounded-lg hover:bg-[#1f2127]"
                                title="تعديل العملية"
                              >
                                <Edit3 size={14} />
                              </button>
                            )}
                            {isAdmin && (
                              <button
                                type="button"
                                onClick={() => handleDeleteFinanceEntry(entry.id)}
                                className="p-2 text-red-500/60 hover:text-red-500 rounded-lg hover:bg-red-500/10"
                                title="حذف العملية"
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingDept ? 'تعديل بيانات القسم' : 'إضافة قسم جديد'}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">اسم القسم</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="مثال: الإنتاج، التسويق، المالية"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">وصف القسم</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all h-24 resize-none"
              placeholder="وصف مختصر لمهام القسم..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">سقف الميزانية (LYD)</label>
            <input
              type="number"
              value={formData.budgetLimit}
              onChange={(e) => setFormData({ ...formData, budgetLimit: e.target.value })}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-500/20"
            >
              {editingDept ? 'حفظ البيانات' : 'إنشاء القسم'}
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-6 py-3 bg-[#1f2127] text-white font-bold rounded-xl hover:bg-[#2a2d35] transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={isFinanceModalOpen}
        onClose={() => {
          setIsFinanceModalOpen(false);
          setEditingFinanceEntry(null);
        }}
        title={`${editingFinanceEntry ? 'تعديل' : 'إضافة'} ${financeType === 'income' ? 'إيراد' : 'مصروف'} قسم ${financeDept?.name || ''}`}
      >
        <form onSubmit={handleFinanceSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">الفئة</label>
            <input
              type="text"
              required
              value={financeForm.category}
              onChange={(e) => setFinanceForm({ ...financeForm, category: e.target.value })}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">المبلغ (LYD)</label>
            <input
              type="number"
              min="0"
              step="0.01"
              required
              value={financeForm.amount}
              onChange={(e) => setFinanceForm({ ...financeForm, amount: e.target.value })}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">ملاحظات</label>
            <textarea
              value={financeForm.notes}
              onChange={(e) => setFinanceForm({ ...financeForm, notes: e.target.value })}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all h-24 resize-none"
              placeholder="تفاصيل العملية..."
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-500/20"
            >
              {editingFinanceEntry ? 'حفظ التعديل' : 'حفظ العملية'}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsFinanceModalOpen(false);
                setEditingFinanceEntry(null);
              }}
              className="px-6 py-3 bg-[#1f2127] text-white font-bold rounded-xl hover:bg-[#2a2d35] transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
