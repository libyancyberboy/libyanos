
export type UserRole = 'ADMIN' | 'MANAGER' | 'EMPLOYEE' | 'FREELANCER';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  departmentId?: string;
  avatarUrl?: string;
  baseSalary?: number;
  joinDate: string;
}

export interface Department {
  id: string;
  name: string;
  description: string;
  managerId?: string;
  createdAt: string;
}

export interface FinanceTransaction {
  id: string;
  type: 'INCOME' | 'EXPENSE';
  amount: number;
  source?: string; // For income
  category?: 'OPERATIONAL' | 'PURCHASE' | 'SERVICE' | 'PRIVATE' | 'FREELANCE' | 'OTHER'; // For expense
  departmentId: string;
  date: string;
  paymentMethod: 'CASH' | 'BANK' | 'ONLINE';
  notes?: string;
  attachmentUrl?: string;
  vendor?: string; // For expense
}

export interface Payroll {
  id: string;
  employeeUid: string;
  employeeName: string;
  role: string;
  baseSalary: number;
  bonuses: number;
  deductions: number;
  netSalary: number;
  paymentDate: string;
  departmentId: string;
}

export type TaskStatus = 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
export type TaskPriority = 'LOW' | 'MEDIUM' | 'HIGH';

export interface Task {
  id: string;
  title: string;
  description: string;
  assignedTo: string; // User UID
  departmentId: string;
  priority: TaskPriority;
  status: TaskStatus;
  deadline: string;
  attachments?: string[];
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  employeeUid: string;
  departmentId: string;
  timestamp: string;
  type: 'CHECK_IN' | 'CHECK_OUT';
  deviceInfo?: string;
}
