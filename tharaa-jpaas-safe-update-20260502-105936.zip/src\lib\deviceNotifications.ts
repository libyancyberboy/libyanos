export const getDeviceNotificationPermission = () => {
  if (!('Notification' in window)) return 'unsupported';
  return Notification.permission;
};

export const requestDeviceNotificationPermission = async () => {
  if (!('Notification' in window)) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  if (Notification.permission === 'denied') return 'denied';
  return Notification.requestPermission();
};

export const playNotificationSound = () => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const audio = new AudioContextClass();
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(920, audio.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(680, audio.currentTime + 0.2);
    gain.gain.setValueAtTime(0.0001, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.2, audio.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 0.25);
    oscillator.connect(gain);
    gain.connect(audio.destination);
    oscillator.start();
    oscillator.stop(audio.currentTime + 0.28);
    window.setTimeout(() => audio.close().catch(() => undefined), 450);
  } catch {
    // Some browsers allow the system notification but block custom sound until user interaction.
  }
};

export const showDeviceNotification = async (item: any) => {
  if (!item || !('Notification' in window) || Notification.permission !== 'granted') return;

  const title = item.title || 'إشعار من ثراء';
  const body = item.message || '';
  const options: NotificationOptions = {
    body,
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-180.png',
    tag: item.id || `tharaa-${Date.now()}`,
    dir: 'rtl',
    lang: 'ar',
    silent: false,
    data: { url: '/notifications', id: item.id },
  };

  try {
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification(title, options);
    } else {
      const notification = new Notification(title, options);
      notification.onclick = () => {
        window.focus();
        window.history.pushState({}, '', '/notifications');
        window.dispatchEvent(new PopStateEvent('popstate'));
        notification.close();
      };
    }
  } catch {
    const notification = new Notification(title, options);
    notification.onclick = () => {
      window.focus();
      window.history.pushState({}, '', '/notifications');
      window.dispatchEvent(new PopStateEvent('popstate'));
      notification.close();
    };
  }
};
