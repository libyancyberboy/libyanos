import React, { useEffect, useMemo, useState } from 'react';
import { BadgeDollarSign, BriefcaseBusiness, Building2, CalendarPlus, ClipboardList, FileDown, Percent, Phone, Plus, Trash2, UserPlus, UserRound } from 'lucide-react';
import Modal from '../components/Modal';
import { saveArabicReportPdf } from '../lib/pdfArabic';

interface FreelanceJob {
  id: string;
  title: string;
  value: number;
  hasDiscount: boolean;
  discount: number;
  program: string;
  date: string;
  notes: string;
}

interface Freelancer {
  id: string;
  name: string;
  phone: string;
  specialty: string;
  departmentId: string;
  notes: string;
  createdAt: string;
  jobs: FreelanceJob[];
  isSystemUser?: boolean;
}

interface SystemUser {
  id: string;
  username: string;
  role: string;
  departmentId?: string;
  createdAt?: string;
}

const STORAGE_KEY = 'tharaa.freelance.people.v2';

const defaultPersonForm = {
  name: '',
  phone: '',
  specialty: '',
  departmentId: '',
  notes: '',
};

const defaultJobForm = {
  title: '',
  value: '',
  program: 'غير محدد',
  hasDiscount: false,
  discount: '',
  date: new Date().toISOString().slice(0, 10),
  notes: '',
};

const PROGRAM_OPTIONS = [
  'غير محدد',
  'Adobe Premiere Pro',
  'Adobe After Effects',
  'Adobe Photoshop',
  'Adobe Illustrator',
  'DaVinci Resolve',
  'CapCut',
  'Lightroom',
  'Blender',
  'Cinema 4D',
  'برنامج آخر',
];

export default function Freelance() {
  const [people, setPeople] = useState<Freelancer[]>([]);
  const [systemFreelancers, setSystemFreelancers] = useState<SystemUser[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [isPersonModalOpen, setIsPersonModalOpen] = useState(false);
  const [isJobModalOpen, setIsJobModalOpen] = useState(false);
  const [selectedPersonId, setSelectedPersonId] = useState('');
  const [personForm, setPersonForm] = useState(defaultPersonForm);
  const [jobForm, setJobForm] = useState(defaultJobForm);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      if (Array.isArray(saved)) {
        setPeople(saved.map((person: Freelancer) => ({
          ...person,
          departmentId: person.departmentId || '',
          jobs: Array.isArray(person.jobs)
            ? person.jobs.map((job: FreelanceJob) => ({ ...job, program: job.program || 'غير محدد' }))
            : []
        })));
      }
    } catch {
      setPeople([]);
    }
  }, []);

  useEffect(() => {
    fetch('/api/departments', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
      .then((response) => response.ok ? response.json() : [])
      .then((data) => {
        const list = Array.isArray(data) ? data : [];
        setDepartments(list);
        if (list.length > 0) {
          setPersonForm((prev) => ({
            ...prev,
            departmentId: prev.departmentId || list[0].id,
          }));
        }
      })
      .catch(() => setDepartments([]));
  }, []);

  useEffect(() => {
    fetch('/api/users', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
      .then((response) => response.ok ? response.json() : [])
      .then((data) => {
        const list = Array.isArray(data) ? data : [];
        setSystemFreelancers(list.filter((user: SystemUser) => user.role === 'FREELANCER'));
      })
      .catch(() => setSystemFreelancers([]));
  }, []);

  const departmentNameById = useMemo(() => {
    return departments.reduce<Record<string, string>>((acc, dept: any) => {
      acc[dept.id] = dept.name;
      return acc;
    }, {});
  }, [departments]);

  const savePeople = (nextPeople: Freelancer[]) => {
    setPeople(nextPeople);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(nextPeople));
  };

  const freelancers = useMemo(() => {
    const merged = new Map<string, Freelancer>();

    people.forEach((person) => merged.set(person.id, person));
    systemFreelancers.forEach((user) => {
      const saved = merged.get(user.id);
      merged.set(user.id, {
        id: user.id,
        name: saved?.name || user.username,
        phone: saved?.phone || '',
        specialty: saved?.specialty || 'فريلانسر',
        departmentId: saved?.departmentId || user.departmentId || departments[0]?.id || '',
        notes: saved?.notes || '',
        createdAt: saved?.createdAt || user.createdAt || new Date().toISOString(),
        jobs: saved?.jobs || [],
        isSystemUser: true,
      });
    });

    return Array.from(merged.values());
  }, [departments, people, systemFreelancers]);

  const jobs = useMemo(() => freelancers.flatMap((person) => person.jobs.map((job) => ({ ...job, person }))), [freelancers]);

  const summary = useMemo(() => {
    const totalValue = jobs.reduce((sum, job) => sum + Number(job.value || 0), 0);
    const totalDiscount = jobs.reduce((sum, job) => sum + Number(job.discount || 0), 0);

    return {
      peopleCount: freelancers.length,
      jobsCount: jobs.length,
      totalValue,
      totalDiscount,
      netValue: totalValue - totalDiscount,
    };
  }, [freelancers.length, jobs]);

  const openAddPerson = () => {
    setPersonForm({ ...defaultPersonForm, departmentId: departments[0]?.id || '' });
    setIsPersonModalOpen(true);
  };

  const openAddJob = (personId: string) => {
    setSelectedPersonId(personId);
    setJobForm(defaultJobForm);
    setIsJobModalOpen(true);
  };

  const handlePersonSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const person: Freelancer = {
      id: `fl_${Date.now()}`,
      name: personForm.name.trim(),
      phone: personForm.phone.trim(),
      specialty: personForm.specialty.trim() || 'عمل حر',
      departmentId: personForm.departmentId || departments[0]?.id || '',
      notes: personForm.notes.trim(),
      createdAt: new Date().toISOString(),
      jobs: [],
    };

    savePeople([person, ...people]);
    setIsPersonModalOpen(false);
  };

  const handleJobSubmit = (event: React.FormEvent) => {
    event.preventDefault();

    const value = Number(jobForm.value);
    const discount = jobForm.hasDiscount ? Number(jobForm.discount || 0) : 0;
    if (!Number.isFinite(value) || value <= 0) return alert('اكتب قيمة صحيحة أكبر من صفر');
    if (!Number.isFinite(discount) || discount < 0 || discount > value) return alert('قيمة الخصم غير صحيحة');

    const job: FreelanceJob = {
      id: `job_${Date.now()}`,
      title: jobForm.title.trim() || 'مهمة فري لانس',
      value,
      hasDiscount: jobForm.hasDiscount,
      discount,
      program: jobForm.program || 'غير محدد',
      date: jobForm.date,
      notes: jobForm.notes.trim(),
    };

    const selectedPerson = freelancers.find((person) => person.id === selectedPersonId);
    const isSavedPerson = people.some((person) => person.id === selectedPersonId);

    if (isSavedPerson) {
      savePeople(people.map((person) => (
        person.id === selectedPersonId
          ? { ...person, jobs: [job, ...person.jobs] }
          : person
      )));
    } else if (selectedPerson) {
      savePeople([
        {
          ...selectedPerson,
          isSystemUser: false,
          jobs: [job],
        },
        ...people,
      ]);
    }
    setIsJobModalOpen(false);
  };

  const deletePerson = (personId: string) => {
    if (!confirm('هل تريد حذف هذا الشخص مع كامل أرشيفه؟')) return;
    savePeople(people.filter((person) => person.id !== personId));
  };

  const deleteJob = (personId: string, jobId: string) => {
    if (!confirm('هل تريد حذف هذه المهمة من الأرشيف؟')) return;
    savePeople(people.map((person) => (
      person.id === personId
        ? { ...person, jobs: person.jobs.filter((job) => job.id !== jobId) }
        : person
    )));
  };

  const exportPDF = async (person?: Freelancer) => {
    const targetPeople = person ? [person] : freelancers;
    const targetJobs = targetPeople.flatMap((item) => item.jobs.map((job) => ({ ...job, person: item })));
    const value = targetJobs.reduce((sum, job) => sum + job.value, 0);
    const discount = targetJobs.reduce((sum, job) => sum + job.discount, 0);

    await saveArabicReportPdf({
      filename: `freelance-archive-${Date.now()}.pdf`,
      title: person ? `أرشيف الفري لانس - ${person.name}` : 'تقرير الفري لانس',
      meta: [
        { label: 'عدد الأشخاص', value: targetPeople.length },
        { label: 'عدد المهام', value: targetJobs.length },
        { label: 'تاريخ التصدير', value: new Date().toLocaleString('ar-LY') }
      ],
      summary: [
        { label: 'إجمالي القيمة', value: `${value.toLocaleString()} LYD`, tone: 'green' },
        { label: 'إجمالي الخصم', value: `${discount.toLocaleString()} LYD`, tone: 'orange' },
        { label: 'الصافي', value: `${(value - discount).toLocaleString()} LYD`, tone: 'dark' }
      ],
      table: {
        title: 'أرشيف المهام',
        head: ['الشخص', 'القسم', 'المهمة', 'البرنامج', 'التاريخ', 'القيمة', 'الخصم', 'الصافي', 'ملاحظات'],
        rows: targetJobs.map((job) => [
          job.person.name,
          departmentNameById[job.person.departmentId] || job.person.departmentId || 'غير محدد',
          job.title,
          job.program || 'غير محدد',
          job.date,
          `${job.value.toLocaleString()} LYD`,
          `${job.discount.toLocaleString()} LYD`,
          `${(job.value - job.discount).toLocaleString()} LYD`,
          job.notes || '-',
        ]),
        rowsPerPage: 18
      },
      footer: ['الفري لانس']
    });
  };

  const stats = [
    { label: 'الأشخاص', value: summary.peopleCount, icon: UserRound, color: 'text-blue-400' },
    { label: 'المهام', value: summary.jobsCount, icon: ClipboardList, color: 'text-orange-500' },
    { label: 'القيمة', value: `${summary.totalValue.toLocaleString()} LYD`, icon: BadgeDollarSign, color: 'text-green-500' },
    { label: 'الخصومات', value: `${summary.totalDiscount.toLocaleString()} LYD`, icon: Percent, color: 'text-red-500' },
  ];

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black text-white">الفري لانس</h1>
          <p className="text-[#6b7280]">أرشيف أشخاص ومهام، مع القيمة والخصم لكل مرة يرجع يخدم فيها</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={openAddPerson}
            className="flex items-center justify-center gap-2 px-5 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20"
          >
            <UserPlus size={18} />
            إضافة شخص
          </button>
          <button
            onClick={() => exportPDF()}
            className="flex items-center justify-center gap-2 px-5 py-3 bg-[#111318] border border-[#1f2127] text-white font-bold rounded-2xl hover:border-orange-500 transition-all"
          >
            <FileDown size={18} />
            تقرير كامل
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-[#111318] border border-[#1f2127] rounded-2xl p-5">
            <div className="flex items-center justify-between gap-3">
              <div className={`w-12 h-12 rounded-2xl bg-[#0a0b0d] border border-[#1f2127] flex items-center justify-center ${stat.color}`}>
                <stat.icon size={23} />
              </div>
              <p className="text-2xl font-black text-white text-left flex-1">{stat.value}</p>
            </div>
            <p className="mt-3 text-sm text-[#9ca3af] font-bold">{stat.label}</p>
          </div>
        ))}
      </div>

      {freelancers.length === 0 ? (
        <div className="py-16 text-center text-[#4b5563] border border-dashed border-[#1f2127] rounded-[2rem]">
          <BriefcaseBusiness size={42} className="mx-auto mb-4 opacity-30" />
          <p className="font-bold">مازال ما ضفتش أي شخص فري لانس</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          {freelancers.map((person) => {
            const total = person.jobs.reduce((sum, job) => sum + job.value, 0);
            const discount = person.jobs.reduce((sum, job) => sum + job.discount, 0);

            return (
              <div key={person.id} className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-5 md:p-6 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#0a0b0d] border border-[#1f2127] text-orange-500 flex items-center justify-center shrink-0">
                      <UserRound size={24} />
                    </div>
                    <div className="min-w-0">
                      <h2 className="text-xl font-black text-white">{person.name}</h2>
                      <p className="text-xs text-[#6b7280]">{person.specialty}</p>
                      <p className="text-xs text-orange-500/80 flex items-center gap-1 mt-1">
                        <Building2 size={12} />
                        {departmentNameById[person.departmentId] || person.departmentId || 'غير محدد'}
                      </p>
                      {person.phone && <p className="text-xs text-[#6b7280] flex items-center gap-1 mt-1"><Phone size={12} /> {person.phone}</p>}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => openAddJob(person.id)} className="flex items-center gap-2 px-3 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl hover:bg-orange-500 transition-all">
                      <CalendarPlus size={14} />
                      مهمة
                    </button>
                    <button onClick={() => exportPDF(person)} className="p-2 bg-[#0a0b0d] border border-[#1f2127] text-[#9ca3af] hover:text-white rounded-xl transition-all">
                      <FileDown size={16} />
                    </button>
                    {!person.isSystemUser && (
                      <button onClick={() => deletePerson(person.id)} className="p-2 bg-[#0a0b0d] border border-[#1f2127] text-red-500/70 hover:text-red-500 rounded-xl transition-all">
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-3">
                    <p className="text-[10px] text-[#6b7280]">المهام</p>
                    <p className="text-xl font-black text-white">{person.jobs.length}</p>
                  </div>
                  <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-3">
                    <p className="text-[10px] text-[#6b7280]">القيمة</p>
                    <p className="text-xl font-black text-green-500">{total.toLocaleString()}</p>
                  </div>
                  <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-3">
                    <p className="text-[10px] text-[#6b7280]">الصافي</p>
                    <p className="text-xl font-black text-orange-500">{(total - discount).toLocaleString()}</p>
                  </div>
                </div>

                <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
                  {person.jobs.length === 0 ? (
                    <div className="py-8 text-center text-[#4b5563] text-sm">لا توجد مهام في أرشيف هذا الشخص</div>
                  ) : (
                    person.jobs.map((job) => (
                      <div key={job.id} className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <p className="text-white font-bold">{job.title}</p>
                          <p className="text-xs text-[#6b7280]">{job.date} | البرنامج: {job.program || 'غير محدد'} | خصم: {job.hasDiscount ? `${job.discount.toLocaleString()} LYD` : 'لا يوجد'}</p>
                          {job.notes && <p className="text-[11px] text-[#4b5563] mt-1">{job.notes}</p>}
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-black text-green-500">{(job.value - job.discount).toLocaleString()} LYD</span>
                          <button onClick={() => deleteJob(person.id, job.id)} className="p-2 text-red-500/60 hover:text-red-500 transition-colors">
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal isOpen={isPersonModalOpen} onClose={() => setIsPersonModalOpen(false)} title="إضافة شخص فري لانس">
        <form onSubmit={handlePersonSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">اسم الشخص</label>
            <input required value={personForm.name} onChange={(event) => setPersonForm({ ...personForm, name: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">رقم الهاتف</label>
              <input value={personForm.phone} onChange={(event) => setPersonForm({ ...personForm, phone: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">نوع العمل</label>
              <input value={personForm.specialty} onChange={(event) => setPersonForm({ ...personForm, specialty: event.target.value })} placeholder="تصوير، مونتاج، تصميم..." className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">القسم التابع له</label>
            <select
              value={personForm.departmentId}
              onChange={(event) => setPersonForm({ ...personForm, departmentId: event.target.value })}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
            >
              {departments.length === 0 ? (
                <option value="">غير محدد</option>
              ) : departments.map((dept: any) => (
                <option key={dept.id} value={dept.id}>{dept.name}</option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">ملاحظات</label>
            <textarea value={personForm.notes} onChange={(event) => setPersonForm({ ...personForm, notes: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none h-24 resize-none" />
          </div>
          <button type="submit" className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all">حفظ الشخص</button>
        </form>
      </Modal>

      <Modal isOpen={isJobModalOpen} onClose={() => setIsJobModalOpen(false)} title="إضافة مهمة للأرشيف">
        <form onSubmit={handleJobSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">اسم المهمة</label>
            <input required value={jobForm.title} onChange={(event) => setJobForm({ ...jobForm, title: event.target.value })} placeholder="مثال: تصوير يوم، مونتاج فيديو، تصميم إعلان" className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">البرنامج المستخدم</label>
            <select value={jobForm.program} onChange={(event) => setJobForm({ ...jobForm, program: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none">
              {PROGRAM_OPTIONS.map((program) => (
                <option key={program} value={program}>{program}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">القيمة LYD</label>
              <input required type="number" min="0" step="0.01" value={jobForm.value} onChange={(event) => setJobForm({ ...jobForm, value: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">التاريخ</label>
              <input type="date" value={jobForm.date} onChange={(event) => setJobForm({ ...jobForm, date: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none" />
            </div>
          </div>
          <label className="flex items-center gap-3 bg-[#0a0b0d] border border-[#1f2127] rounded-xl p-4 text-sm font-bold text-white">
            <input type="checkbox" checked={jobForm.hasDiscount} onChange={(event) => setJobForm({ ...jobForm, hasDiscount: event.target.checked, discount: event.target.checked ? jobForm.discount : '' })} />
            يوجد خصم
          </label>
          {jobForm.hasDiscount && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">قيمة الخصم LYD</label>
              <input type="number" min="0" step="0.01" value={jobForm.discount} onChange={(event) => setJobForm({ ...jobForm, discount: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none" />
            </div>
          )}
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">ملاحظات</label>
            <textarea value={jobForm.notes} onChange={(event) => setJobForm({ ...jobForm, notes: event.target.value })} className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none h-24 resize-none" />
          </div>
          <button type="submit" className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all">حفظ المهمة</button>
        </form>
      </Modal>
    </div>
  );
}
