import React, { useState, useEffect, useMemo } from 'react';
import { BellRing, CheckCircle2, CheckSquare, Clock3, Plus, Filter, Trash2 } from 'lucide-react';
import Modal from '../components/Modal';

interface TasksProps {
  user: any;
}

export default function Tasks({ user }: TasksProps) {
  if (!user) return null;
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    assignedTo: user.id
  });

  const columns = [
    { id: 'todo', label: 'قيد الانتظار' },
    { id: 'doing', label: 'قيد التنفيذ' },
    { id: 'done', label: 'مكتمل' }
  ];

  useEffect(() => {
    fetchTasks();
    if (user.role === 'ADMIN' || user.role === 'MANAGER') {
      fetch('/api/users', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      .then(r => r.json())
      .then(d => {
        const list = Array.isArray(d) ? d : [];
        setUsers(list);
        const firstWorker = list.find((item: any) => item.role === 'EMPLOYEE' || item.role === 'FREELANCER');
        if (firstWorker) {
          setFormData(current => ({
            ...current,
            assignedTo: list.some((item: any) => item.id === current.assignedTo && (item.role === 'EMPLOYEE' || item.role === 'FREELANCER'))
              ? current.assignedTo
              : firstWorker.id
          }));
        }
      });
    }
  }, [user]);

  const fetchTasks = () => {
    fetch('/api/tasks', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(r => r.json())
    .then(d => setTasks(d));
  };

  const handleOpenAdd = () => {
    const firstWorker = users.find((item: any) => item.role === 'EMPLOYEE' || item.role === 'FREELANCER');
    setFormData({ title: '', description: '', assignedTo: firstWorker?.id || '' });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.assignedTo) {
      alert('اختار موظف أو فريلانسر لاستلام المهمة');
      return;
    }
    const resp = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ ...formData, status: 'todo' })
    });
    if (resp.ok) {
      const newTask = await resp.json();
      setTasks([...tasks, newTask] as any);
      setIsModalOpen(false);
    } else {
      const err = await resp.json();
      alert(err.message || 'تعذر إنشاء المهمة');
    }
  };

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    const resp = await fetch(`/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ status: newStatus })
    });
    if (resp.ok) {
      const updatedTask = await resp.json();
      setTasks(tasks.map((t: any) => t.id === id ? updatedTask : t) as any);
    }
  };

  const handleDeleteTask = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذه المهمة؟")) return;
    const resp = await fetch(`/api/tasks/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (resp.ok) {
      setTasks(tasks.filter((t: any) => t.id !== id) as any);
    }
  };

  const isAdmin = user.role === 'ADMIN' || user.role === 'MANAGER';
  const workerUsers = useMemo(() => (
    users.filter((item: any) => item.role === 'EMPLOYEE' || item.role === 'FREELANCER')
  ), [users]);
  const receivedCount = tasks.filter((task: any) => task.receivedAt).length;
  const notReceivedCount = tasks.length - receivedCount;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black text-white">المهام</h1>
          <p className="text-[#6b7280]">توجيه وتتبع سير العمل اليومي</p>
        </div>
        {isAdmin && (
          <div className="flex gap-3">
            <button className="p-3 bg-[#111318] border border-[#1f2127] text-[#6b7280] rounded-xl hover:text-white transition-all">
              <Filter size={18} />
            </button>
            <button 
              onClick={handleOpenAdd}
              className="flex items-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
            >
              <Plus size={18} />
              <span>مهمة جديدة</span>
            </button>
          </div>
        )}
      </div>

      {isAdmin && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-[#111318] border border-green-500/20 rounded-2xl p-5 flex items-center justify-between">
            <div>
              <p className="text-xs text-[#6b7280] font-bold">المهام المستلمة</p>
              <p className="text-3xl font-black text-green-500">{receivedCount}</p>
            </div>
            <CheckCircle2 className="text-green-500" size={28} />
          </div>
          <div className="bg-[#111318] border border-orange-500/20 rounded-2xl p-5 flex items-center justify-between">
            <div>
              <p className="text-xs text-[#6b7280] font-bold">المهام غير المستلمة</p>
              <p className="text-3xl font-black text-orange-500">{notReceivedCount}</p>
            </div>
            <Clock3 className="text-orange-500" size={28} />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {columns.map(col => (
          <div key={col.id} className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-xs font-black text-[#6b7280] uppercase tracking-widest font-mono">{col.label}</h3>
              <span className="text-[10px] bg-[#1f2127] text-orange-500 px-2 py-0.5 rounded font-mono font-black">
                {tasks.filter((t: any) => t.status === col.id).length}
              </span>
            </div>
            <div className="min-h-[500px] bg-[#111318]/50 border-2 border-dashed border-[#1f2127] rounded-[2rem] flex flex-col p-4 space-y-4">
              {tasks.filter((t: any) => t.status === col.id).length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center opacity-20">
                  <CheckSquare size={32} className="mb-2" />
                  <p className="text-[9px] font-mono uppercase tracking-widest">No_Tasks_Found</p>
                </div>
              ) : (
                tasks.filter((t: any) => t.status === col.id).map((task: any) => (
                  <div key={task.id} className="bg-[#0a0b0d] p-4 border border-[#1f2127] rounded-2xl technical-card group">
                    <div className="flex justify-between items-start mb-2">
                       <h4 className="font-bold text-white text-sm">{task.title}</h4>
                       {isAdmin && (
                         <button onClick={() => handleDeleteTask(task.id)} className="opacity-0 group-hover:opacity-100 p-1 text-red-500/50 hover:text-red-500 transition-all">
                            <Trash2 size={14} />
                         </button>
                       )}
                    </div>
                    <p className="text-[10px] text-[#6b7280] mb-4 line-clamp-2">{task.description}</p>
                    <div className="space-y-2 mb-4">
                      {isAdmin && (
                        <p className="text-[10px] text-[#8b929f]">
                          المستلم: <span className="text-white font-bold">{task.assigneeName || task.assignedTo}</span>
                          {task.assigneeRole && <span className="text-orange-500"> · {task.assigneeRole === 'FREELANCER' ? 'فريلانسر' : 'موظف'}</span>}
                        </p>
                      )}
                      <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-lg text-[10px] font-black border ${task.receivedAt ? 'bg-green-500/10 border-green-500/20 text-green-500' : 'bg-orange-500/10 border-orange-500/20 text-orange-500'}`}>
                        {task.receivedAt ? <CheckCircle2 size={13} /> : <BellRing size={13} />}
                        {task.receivedAt ? 'تم استلام المهمة' : 'لم يستلم بعد'}
                      </div>
                      {task.receivedAt && (
                        <p className="text-[9px] text-[#6b7280]">{new Date(task.receivedAt).toLocaleString('ar-LY')}</p>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                       {col.id !== 'todo' && (
                         <button 
                           onClick={() => handleUpdateStatus(task.id, col.id === 'doing' ? 'todo' : 'doing')}
                           className="text-[8px] font-mono font-bold uppercase tracking-tighter bg-[#1f2127] text-[#6b7280] px-2 py-1 rounded hover:text-white transition-colors"
                         >
                           Prev_State
                         </button>
                       )}
                       {col.id !== 'done' && (
                         <button 
                           onClick={() => handleUpdateStatus(task.id, col.id === 'todo' ? 'doing' : 'done')}
                           className="text-[8px] font-mono font-bold uppercase tracking-tighter bg-orange-600/10 text-orange-500 px-2 py-1 rounded hover:bg-orange-600 hover:text-white transition-all"
                         >
                           Next_Action
                         </button>
                       )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="إنشاء مهمة عمل جديدة"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">عنوان المهمة</label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="مثال: مراجعة كشوفات الحسابات"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">تفاصيل المهمة</label>
            <textarea
              required
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all h-24 resize-none"
              placeholder="وصف المهام المطلوب تنفيذها..."
            />
          </div>

          {isAdmin && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">إرسال إلى موظف / فريلانسر</label>
              <select
                value={formData.assignedTo}
                onChange={(e) => setFormData({...formData, assignedTo: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              >
                {workerUsers.map(u => (
                  <option key={u.id} value={u.id}>{u.username} ({u.role === 'FREELANCER' ? 'فريلانسر' : 'موظف'})</option>
                ))}
              </select>
              {workerUsers.length === 0 && (
                <p className="text-xs text-orange-500 font-bold">أضف موظف أو فريلانسر من قسم الموظفين أولاً.</p>
              )}
            </div>
          )}

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              disabled={!formData.assignedTo}
              className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-500/20"
            >
              توزيع المهمة
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-6 py-3 bg-[#1f2127] text-white font-bold rounded-xl hover:bg-[#2a2d35] transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
