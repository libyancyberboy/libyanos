import React, { useState, useEffect, useMemo, useRef } from 'react';
import { jsPDF } from 'jspdf';
import { Wallet, ArrowUpRight, ArrowDownRight, Printer, Trash2, PenLine, CheckCircle2, HandCoins, XCircle, FileDown } from 'lucide-react';
import Modal from '../components/Modal';
import { saveArabicReportPdf } from '../lib/pdfArabic';

interface FinanceProps {
  user: any;
}

function SignaturePad({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);

  const getPoint = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (canvas.width / rect.width),
      y: (event.clientY - rect.top) * (canvas.height / rect.height)
    };
  };

  const startDrawing = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    canvas.setPointerCapture(event.pointerId);
    const point = getPoint(event);
    drawingRef.current = true;
    ctx.strokeStyle = '#111318';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(point.x, point.y);
  };

  const draw = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const point = getPoint(event);
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    const canvas = canvasRef.current;
    if (!canvas || !drawingRef.current) return;
    drawingRef.current = false;
    onChange(canvas.toDataURL('image/png'));
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    onChange('');
  };

  return (
    <div className="space-y-3">
      <div className="rounded-2xl bg-white border border-orange-500/30 overflow-hidden">
        <canvas
          ref={canvasRef}
          width={760}
          height={190}
          onPointerDown={startDrawing}
          onPointerMove={draw}
          onPointerUp={stopDrawing}
          onPointerLeave={stopDrawing}
          className="w-full h-[150px] touch-none cursor-crosshair"
        />
      </div>
      <div className="flex items-center justify-between gap-3">
        <p className="text-[10px] text-[#6b7280]">وقّع داخل المربع، بعدها يفتح زر الاستلام.</p>
        <button
          type="button"
          onClick={clearSignature}
          className="px-3 py-2 rounded-xl bg-[#1f2127] text-white text-xs font-bold hover:bg-[#2a2d35]"
        >
          مسح التوقيع
        </button>
      </div>
      {value && <p className="text-[10px] text-green-500 font-bold">تم التقاط التوقيع الإلكتروني</p>}
    </div>
  );
}

const loadCanvasImage = (src: string) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = src;
  });

const safeFilePart = (value: string) =>
  String(value || 'employee').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 80);

const downloadDataUrl = (dataUrl: string, filename: string) => {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
};

const buildPayrollReceiptPdf = async (item: any, signatureDataUrl: string) => {
  if (document.fonts) {
    await document.fonts.ready.catch(() => undefined);
  }

  const canvas = document.createElement('canvas');
  const scale = 2;
  const width = 794;
  const height = 1123;
  canvas.width = width * scale;
  canvas.height = height * scale;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas is not available');
  ctx.scale(scale, scale);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  const draw = (
    text: string,
    x: number,
    y: number,
    size = 18,
    weight = 400,
    align: CanvasTextAlign = 'right',
    color = '#111318'
  ) => {
    ctx.save();
    ctx.font = `${weight} ${size}px "ThmanyahSans", Tahoma, Arial, sans-serif`;
    ctx.fillStyle = color;
    ctx.textAlign = align;
    ctx.textBaseline = 'alphabetic';
    (ctx as any).direction = align === 'left' ? 'ltr' : 'rtl';
    ctx.fillText(String(text || '-'), x, y);
    ctx.restore();
  };

  const right = width - 70;
  draw('إيصال استلام راتب', width / 2, 165, 30, 800, 'center');
  draw('تم توقيع هذا الإيصال إلكترونياً من الموظف', width / 2, 198, 15, 600, 'center', '#6b7280');

  const rows = [
    ['الموظف', item.employeeName || '-'],
    ['القسم', item.departmentName || item.departmentId || '-'],
    ['المبلغ المستلم', `${Number(item.amount || 0).toLocaleString()} LYD`],
    ['تاريخ الاستلام', item.receivedAt ? new Date(item.receivedAt).toLocaleString('ar-LY') : new Date().toLocaleString('ar-LY')],
    ['رقم الإيصال', item.id || '-'],
  ];

  let y = 270;
  rows.forEach(([label, value]) => {
    ctx.fillStyle = '#f7f8fa';
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(70, y - 28, width - 140, 48, 12);
    ctx.fill();
    ctx.stroke();
    draw(label, right, y, 15, 800, 'right', '#6b7280');
    draw(value, right - 185, y, 17, 800, 'right');
    y += 60;
  });

  draw('توقيع الموظف الإلكتروني', right, y + 42, 19, 800);
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#e5e7eb';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(160, y + 70, 475, 160, 16);
  ctx.fill();
  ctx.stroke();

  try {
    const signatureImage = await loadCanvasImage(signatureDataUrl);
    ctx.drawImage(signatureImage, 205, y + 94, 385, 102);
  } catch {
    draw('تعذر إدراج التوقيع', width / 2, y + 155, 16, 800, 'center', '#ef4444');
  }

  draw('نسخة محفوظة للمدير', width / 2, 955, 16, 800, 'center', '#ea580c');

  const pdf = new jsPDF('p', 'mm', 'a4');
  pdf.addImage(canvas.toDataURL('image/jpeg', 0.96), 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
  return pdf.output('datauristring');
};

export default function Finance({ user }: FinanceProps) {
  if (!user) return null;
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [personalSalary, setSalary] = useState(0);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [payroll, setPayroll] = useState<any[]>([]);
  const [advanceRequests, setAdvanceRequests] = useState<any[]>([]);
  const [signature, setSignature] = useState('');
  const [advanceForm, setAdvanceForm] = useState({ amount: '', reason: '', employeeId: '' });
  const [actionLoading, setActionLoading] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'income' | 'expense'>('income');
  const [formData, setFormData] = useState({
    category: '',
    amount: '',
    notes: '',
    employeeId: ''
  });

  useEffect(() => {
    fetchFinance();
    fetchPayroll();
    fetchAdvanceRequests();
    if (user.role === 'ADMIN' || user.role === 'MANAGER') {
      fetch('/api/users', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      .then(r => r.json())
      .then(d => setUsers(d));
      fetch('/api/departments', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      .then(r => r.json())
      .then(d => setDepartments(Array.isArray(d) ? d : []));
    }
  }, [user, selectedEmployeeId]);

  const authHeaders = {
    'Authorization': `Bearer ${localStorage.getItem('token')}`
  };
  const isAdmin = user.role === 'ADMIN' || user.role === 'MANAGER';
  const isWorker = user.role === 'EMPLOYEE' || user.role === 'FREELANCER';

  const fetchFinance = () => {
    setLoading(true);
    const query = (user.role === 'ADMIN' || user.role === 'MANAGER') && selectedEmployeeId 
      ? `?employeeId=${selectedEmployeeId}` 
      : '';

    fetch(`/api/finance${query}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(r => r.json())
    .then(d => {
      // Role is employee/freelancer or Admin has selected a specific worker
      if (isWorker || (isAdmin && selectedEmployeeId)) {
        setData(d.entries || []);
        setSalary(d.salary || 0);
      } else {
        setData(d || []);
        setSalary(0);
      }
      setLoading(false);
    });
  };

  const fetchPayroll = () => {
    fetch('/api/payroll', { headers: authHeaders })
      .then(r => r.json())
      .then(d => setPayroll(Array.isArray(d) ? d : []))
      .catch(() => setPayroll([]));
  };

  const fetchAdvanceRequests = () => {
    fetch('/api/advance-requests', { headers: authHeaders })
      .then(r => r.json())
      .then(d => setAdvanceRequests(Array.isArray(d) ? d : []))
      .catch(() => setAdvanceRequests([]));
  };

  const isSalaryPaymentCategory = (category: string) =>
    category?.includes('راتب') || category?.includes('Salary') || category?.includes('استلام راتب') || category?.includes('صرف راتب');
  const isBonusCategory = (category: string) =>
    category?.includes('مكافأة') || category?.includes('Bonus') || category?.includes('إضافة');
  const isEmployeeFinanceCategory = (category: string) =>
    category === 'خصم' ||
    category === 'سلفة' ||
    category?.includes('خصم') ||
    category?.includes('سلفة') ||
    category?.includes('موظف') ||
    category?.includes('صرف قيمة') ||
    category?.includes('دفعة') ||
    isSalaryPaymentCategory(category) ||
    isBonusCategory(category);

  const handleOpenModal = (type: 'income' | 'expense', category?: string) => {
    const nextCategory = category || (type === 'expense' ? 'مصروف إداري' : 'إيراد عام');
    setModalType(type);
    setFormData({
      category: nextCategory,
      amount: '',
      notes: '',
      employeeId: isEmployeeFinanceCategory(nextCategory) ? (selectedEmployeeId || '') : ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const shouldLinkEmployee = isEmployeeFinanceCategory(formData.category);
    if (shouldLinkEmployee && !formData.employeeId) {
      return alert('هذه العملية تخص موظف، اختار الموظف أولاً');
    }

    const resp = await fetch('/api/finance', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ 
        type: modalType, 
        amount: parseFloat(formData.amount), 
        category: formData.category, 
        notes: formData.notes, 
        employeeId: shouldLinkEmployee ? (formData.employeeId || null) : null
      })
    });
    if (resp.ok) {
      await fetchFinance(); // Refresh to get correct stats
      setIsModalOpen(false);
    } else {
      const err = await resp.json();
      alert(err.message || 'تعذر تسجيل العملية المالية');
    }
  };

  const departmentNameById = useMemo(() => {
    return departments.reduce<Record<string, string>>((acc, dept: any) => {
      acc[dept.id] = dept.name;
      return acc;
    }, {});
  }, [departments]);

  const getDepartmentName = (departmentId?: string) => (
    departmentId ? (departmentNameById[departmentId] || departmentId) : 'عام'
  );

  const refreshFinancialViews = () => {
    fetchFinance();
    fetchPayroll();
    fetchAdvanceRequests();
  };

  const handleCreatePayroll = async () => {
    if (!selectedEmployeeId) return alert('اختار الموظف أولاً');
    const amount = Math.max(0, employeeNetBalance);
    if (amount <= 0) return alert('حساب الموظف صفر ولا يوجد مبلغ للتصفير');

    setActionLoading('create-payroll');
    const response = await fetch('/api/payroll', {
      method: 'POST',
      headers: {
        ...authHeaders,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ employeeId: selectedEmployeeId, amount, notes: 'استلام حساب الموظف' })
    });

    const data = await response.json().catch(() => ({}));
    setActionLoading('');
    if (!response.ok) return alert(data.message || 'تعذر تجهيز الاستلام');
    refreshFinancialViews();
  };

  const handleReceivePayroll = async (payrollId: string) => {
    if (!signature) return alert('لازم توقّع قبل تم الاستلام');

    const payrollItem = payroll.find((item: any) => item.id === payrollId);
    setActionLoading(payrollId);
    let receiptPdfDataUrl = '';
    try {
      receiptPdfDataUrl = await buildPayrollReceiptPdf(payrollItem || { id: payrollId, employeeName: user.username }, signature);
    } catch (error) {
      setActionLoading('');
      console.error('Receipt PDF error:', error);
      return alert('تعذر تجهيز إيصال PDF، جرّب مرة ثانية من Chrome');
    }

    const response = await fetch(`/api/payroll/${payrollId}/receive`, {
      method: 'POST',
      headers: {
        ...authHeaders,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        signature,
        receiptPdf: {
          name: `payroll-receipt-${safeFilePart(payrollItem?.employeeName || user.username)}.pdf`,
          type: 'application/pdf',
          dataUrl: receiptPdfDataUrl
        }
      })
    });
    const data = await response.json().catch(() => ({}));
    setActionLoading('');
    if (!response.ok) return alert(data.message || 'تعذر تأكيد الاستلام');
    setSignature('');
    refreshFinancialViews();
    alert('تم الاستلام، وتم إرسال إيصال PDF للمدير');
  };

  const handleDownloadPayrollReceipt = async (item: any) => {
    setActionLoading(`receipt-${item.id}`);
    const response = await fetch(`/api/payroll/${item.id}/receipt`, { headers: authHeaders });
    const data = await response.json().catch(() => ({}));
    setActionLoading('');

    if (response.ok && data.receiptPdf?.dataUrl) {
      downloadDataUrl(data.receiptPdf.dataUrl, data.receiptPdf.name || `payroll-receipt-${safeFilePart(item.employeeName)}.pdf`);
      return;
    }

    if (item.signature) {
      const pdfDataUrl = await buildPayrollReceiptPdf(item, item.signature);
      downloadDataUrl(pdfDataUrl, `payroll-receipt-${safeFilePart(item.employeeName)}.pdf`);
      return;
    }

    alert(data.message || 'لا يوجد إيصال PDF لهذا الاستلام');
  };

  const handleAdvanceSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setActionLoading('advance-request');
    const response = await fetch('/api/advance-requests', {
      method: 'POST',
      headers: {
        ...authHeaders,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        amount: parseFloat(advanceForm.amount),
        reason: advanceForm.reason,
        employeeId: advanceForm.employeeId || selectedEmployeeId || undefined
      })
    });
    const data = await response.json().catch(() => ({}));
    setActionLoading('');
    if (!response.ok) return alert(data.message || 'تعذر إرسال طلب السلفة');
    setAdvanceForm({ amount: '', reason: '', employeeId: '' });
    fetchAdvanceRequests();
  };

  const handleAdvanceAction = async (id: string, action: 'approve' | 'reject') => {
    setActionLoading(`${action}-${id}`);
    const response = await fetch(`/api/advance-requests/${id}`, {
      method: 'PATCH',
      headers: {
        ...authHeaders,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ action })
    });
    const data = await response.json().catch(() => ({}));
    setActionLoading('');
    if (!response.ok) return alert(data.message || 'تعذر تحديث طلب السلفة');
    refreshFinancialViews();
  };

  const handleDeleteTrx = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذه العملية المالية؟")) return;
    const resp = await fetch(`/api/finance/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (resp.ok) {
      setData(data.filter((d: any) => d.id !== id));
    }
  };

  // Filter logic for summaries
  const relevantEntries = isAdmin && selectedEmployeeId 
    ? data.filter((f: any) => f.employeeId === selectedEmployeeId) 
    : data;

  const totalIncome = relevantEntries.filter((f: any) => f.type === 'income').reduce((a, b: any) => a + b.amount, 0);
  const totalExpense = relevantEntries.filter((f: any) => f.type === 'expense').reduce((a, b: any) => a + b.amount, 0);

  // General Deductions (Non-Salaries)
  const totalDeductionsAll = data.filter((f: any) => f.type === 'expense' && f.category === 'خصم').reduce((a, b: any) => a + b.amount, 0);

  // Employee specific logic (Deductions vs Payouts)
  const employeeDeductions = data.filter((f: any) => f.type === 'expense' && (f.category === 'خصم' || (!isSalaryPaymentCategory(f.category) && !isBonusCategory(f.category) && f.employeeId))).reduce((a, b: any) => a + b.amount, 0);
  const employeeBonuses = data.filter((f: any) => f.type === 'income' || (f.type === 'expense' && isBonusCategory(f.category))).reduce((a, b: any) => a + b.amount, 0);
  const paidAmount = data.filter((f: any) => f.type === 'expense' && isSalaryPaymentCategory(f.category)).reduce((a, b: any) => a + b.amount, 0);
  const employeeNetBalance = Math.max(0, personalSalary + employeeBonuses - employeeDeductions - paidAmount);
  const pendingPayroll = payroll.filter((item: any) =>
    item.status === 'pending' && (isWorker ? item.employeeId === user.id : (!selectedEmployeeId || item.employeeId === selectedEmployeeId))
  );
  const visibleReceivedPayroll = payroll.filter((item: any) =>
    item.status === 'received' && (isWorker ? item.employeeId === user.id : (!selectedEmployeeId || item.employeeId === selectedEmployeeId))
  );
  const visibleAdvanceRequests = advanceRequests.filter((item: any) =>
    isWorker ? item.employeeId === user.id : (!selectedEmployeeId || item.employeeId === selectedEmployeeId)
  );
  const pendingPayrollTotal = pendingPayroll.reduce((sum: number, item: any) => sum + Number(item.amount || 0), 0);
  const receivedPayrollTotal = visibleReceivedPayroll.reduce((sum: number, item: any) => sum + Number(item.amount || 0), 0);

  const handleExportPDF = async () => {
    try {
      const tableRows = data.map((item: any) => [
        new Date(item.timestamp).toLocaleDateString('ar-LY'),
        getDepartmentName(item.departmentId),
        item.category || 'General',
        item.type === 'income' ? 'إيراد' : 'مصروف',
        `${Number(item.amount || 0).toLocaleString()} LYD`,
        item.notes || '-'
      ]);

      await saveArabicReportPdf({
        filename: `finance_report_${Date.now()}.pdf`,
        title: 'التقرير المالي',
        meta: [
          { label: 'تاريخ التصدير', value: new Date().toLocaleString('ar-LY') },
          { label: 'النطاق', value: selectedEmployeeId ? `الموظف: ${users.find(u => u.id === selectedEmployeeId)?.username || selectedEmployeeId}` : 'الخزينة العامة' }
        ],
        summary: [
          { label: 'إجمالي الإيرادات', value: `${totalIncome.toLocaleString()} LYD`, tone: 'green' },
          { label: 'إجمالي المصروفات', value: `${totalExpense.toLocaleString()} LYD`, tone: 'orange' },
          { label: 'الصافي', value: `${(totalIncome - totalExpense).toLocaleString()} LYD`, tone: 'dark' }
        ],
        table: {
          title: 'الحركات المالية',
          head: ['التاريخ', 'القسم', 'الفئة', 'النوع', 'المبلغ', 'التفاصيل'],
          rows: tableRows
        },
        footer: ['التقرير المالي']
      });
    } catch (err) {
      console.error("PDF Export Error:", err);
      alert("حدث خطأ أثناء تصدير PDF. تأكد من أن جميع البيانات صحيحة.");
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-10">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black text-white">المالية</h1>
          <p className="text-[#6b7280]">إدارة التدفقات النقدية والرواتب والميزانيات</p>
        </div>
        {isAdmin && (
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <select
              value={selectedEmployeeId}
              onChange={(e) => setSelectedEmployeeId(e.target.value)}
              className="bg-[#111318] border border-[#1f2127] text-white rounded-2xl px-4 py-3 text-sm focus:border-orange-500 outline-none w-full md:w-auto"
            >
              <option value="">جميع الموظفين (الخزينة العامة)</option>
              {users.filter((u: any) => u.role === 'EMPLOYEE' || u.role === 'FREELANCER').map(u => (
                <option key={u.id} value={u.id}>{u.username}</option>
              ))}
            </select>
            <div className="flex gap-3 w-full md:w-auto">
              {selectedEmployeeId && (
                <>
                  <button
                    onClick={handleCreatePayroll}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-green-600/10 border border-green-500/30 text-green-500 font-bold rounded-2xl hover:bg-green-600 hover:text-white transition-all active:scale-95"
                  >
                    <CheckCircle2 size={18} />
                    <span>إرسال للتوقيع</span>
                  </button>
                  <button
                    onClick={() => handleOpenModal('expense', 'صرف قيمة')}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#111318] border border-green-500/30 text-green-500 font-bold rounded-2xl hover:bg-green-600 hover:text-white transition-all active:scale-95"
                  >
                    <Wallet size={18} />
                    <span>صرف قيمة</span>
                  </button>
                  <button
                    onClick={() => handleOpenModal('income', 'مكافأة')}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#111318] border border-yellow-500/30 text-yellow-500 font-bold rounded-2xl hover:bg-yellow-500 hover:text-black transition-all active:scale-95"
                  >
                    <ArrowUpRight size={18} />
                    <span>مكافأة</span>
                  </button>
                </>
              )}
              <button 
                onClick={() => handleOpenModal('expense', 'خصم')}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#111318] border border-red-500/30 text-red-500 font-bold rounded-2xl hover:bg-red-500 hover:text-white transition-all active:scale-95"
              >
                <ArrowDownRight size={18} />
                <span>تسجيل خصم</span>
              </button>
              <button 
                onClick={() => handleOpenModal('expense', 'مصروف إداري')}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#111318] border border-[#1f2127] text-white font-bold rounded-2xl hover:border-orange-500 transition-all active:scale-95"
              >
                <ArrowDownRight size={18} className="text-orange-500" />
                <span>مصروف</span>
              </button>
              <button 
                onClick={() => handleOpenModal('income')}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
              >
                <ArrowUpRight size={18} />
                <span>إيراد</span>
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-1 gap-6 mb-8">
        <div className={`bg-[#111318] p-8 border border-[#1f2127] rounded-[2rem] ${isWorker || selectedEmployeeId ? 'glow-orange' : ''}`}>
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="space-y-1 text-center md:text-right w-full">
              <h3 className="text-[#6b7280] text-xs font-mono tracking-widest uppercase mb-4 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></div>
                {isWorker || selectedEmployeeId ? 'Personal_Financial_Profile' : 'General_Ledger_Active'}
              </h3>
              {isWorker || (isAdmin && selectedEmployeeId) ? (
                <div className="flex flex-col sm:flex-row flex-wrap gap-4 sm:gap-8 justify-center md:justify-start w-full">
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[200px]">
                     <p className="text-[10px] text-[#4b5563] mb-1">الراتب الأساسي + الإضافات</p>
                     <p className="text-3xl font-black text-white">{(personalSalary + employeeBonuses).toLocaleString()} <span className="text-xs text-orange-500">LYD</span></p>
                     {employeeBonuses > 0 && <p className="text-[9px] text-green-500 mt-1">يتضمن {employeeBonuses.toLocaleString()} إضافات/مكافآت</p>}
                   </div>
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[200px]">
                     <p className="text-[10px] text-orange-600 mb-1">الخصميات الفردية</p>
                     <p className="text-3xl font-black text-orange-600">{employeeDeductions.toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                   <div className="bg-orange-600 p-6 rounded-2xl flex-1 min-w-[200px] shadow-lg shadow-orange-600/20">
                     <p className="text-[10px] text-white/50 mb-1">الصافي المتبقي</p>
                     <p className="text-3xl font-black text-white">{employeeNetBalance.toLocaleString()} <span className="text-xs">LYD</span></p>
                     {paidAmount > 0 && <p className="text-[9px] text-white/70 mt-1">تم صرف {paidAmount.toLocaleString()} سابقاً</p>}
                   </div>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row flex-wrap gap-4 sm:gap-8 w-full">
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[180px]">
                     <p className="text-[10px] text-green-500 mb-1">إجمالي الدخل</p>
                     <p className="text-3xl font-black text-white">{totalIncome.toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[180px]">
                     <p className="text-[10px] text-orange-600 mb-1">إجمالي الخصميات</p>
                     <p className="text-3xl font-black text-white">{totalDeductionsAll.toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                   <div className="bg-[#0a0b0d] p-6 rounded-2xl border border-[#1f2127] flex-1 min-w-[180px]">
                     <p className="text-[10px] text-[#6b7280] mb-1">صافي الخزينة</p>
                     <p className="text-3xl font-black text-white">{(totalIncome - totalExpense).toLocaleString()} <span className="text-xs">LYD</span></p>
                   </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {(isWorker || isAdmin) && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6 md:p-8 space-y-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  <PenLine size={20} className="text-orange-500" />
                  الاستلام والتوقيع
                </h2>
                <p className="text-xs text-[#6b7280] mt-1">الموظف لا يقدر يضغط تم الاستلام إلا بعد التوقيع الإلكتروني.</p>
              </div>
              <span className="text-orange-500 font-black">{pendingPayroll.length}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
              <div className="bg-[#0a0b0d] border border-green-500/20 rounded-2xl p-4">
                <p className="text-[10px] text-[#6b7280] font-bold mb-1">المبالغ المستلمة</p>
                <p className="text-2xl font-black text-green-500">{receivedPayrollTotal.toLocaleString()} <span className="text-xs">LYD</span></p>
              </div>
              <div className="bg-[#0a0b0d] border border-orange-500/20 rounded-2xl p-4">
                <p className="text-[10px] text-[#6b7280] font-bold mb-1">المبالغ غير المستلمة</p>
                <p className="text-2xl font-black text-orange-500">{pendingPayrollTotal.toLocaleString()} <span className="text-xs">LYD</span></p>
              </div>
              <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 sm:col-span-2 xl:col-span-1">
                <p className="text-[10px] text-[#6b7280] font-bold mb-1">حالة الاستلام</p>
                <p className={`text-2xl font-black ${pendingPayrollTotal > 0 ? 'text-orange-500' : receivedPayrollTotal > 0 ? 'text-green-500' : 'text-[#8b929f]'}`}>
                  {pendingPayrollTotal > 0 ? 'غير مستلم' : receivedPayrollTotal > 0 ? 'استلم' : 'لا يوجد'}
                </p>
              </div>
            </div>

            {isAdmin && selectedEmployeeId && (
              <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-white font-black">تجهيز استلام للموظف</p>
                  <p className="text-xs text-[#6b7280]">المبلغ الحالي: {employeeNetBalance.toLocaleString()} LYD</p>
                </div>
                <button
                  type="button"
                  onClick={handleCreatePayroll}
                  disabled={actionLoading === 'create-payroll' || employeeNetBalance <= 0}
                  className="px-5 py-3 rounded-2xl bg-orange-600 disabled:opacity-50 text-white font-bold hover:bg-orange-500"
                >
                  {actionLoading === 'create-payroll' ? 'جاري التجهيز...' : 'إرسال للموظف للتوقيع'}
                </button>
              </div>
            )}

            {pendingPayroll.length === 0 ? (
              <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-5 text-sm text-[#6b7280]">
                لا يوجد استلام مفتوح حالياً.
              </div>
            ) : pendingPayroll.map((item: any) => (
              <div key={item.id} className="bg-[#0a0b0d] border border-orange-500/20 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-white font-black">{item.employeeName}</p>
                    <p className="text-xs text-[#6b7280]">{new Date(item.createdAt).toLocaleString('ar-LY')}</p>
                  </div>
                  <p className="text-2xl font-black text-orange-500">{Number(item.amount || 0).toLocaleString()} <span className="text-xs">LYD</span></p>
                </div>
                {isWorker ? (
                  <>
                    <SignaturePad value={signature} onChange={setSignature} />
                    <button
                      type="button"
                      onClick={() => handleReceivePayroll(item.id)}
                      disabled={!signature || actionLoading === item.id}
                      className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-green-600 disabled:bg-[#1f2127] disabled:text-[#6b7280] text-white font-black hover:bg-green-500"
                    >
                      <CheckCircle2 size={18} />
                      {actionLoading === item.id ? 'جاري التأكيد...' : 'تم الاستلام'}
                    </button>
                  </>
                ) : (
                  <p className="text-xs text-orange-500 font-bold">ينتظر توقيع الموظف ثم يتصفر حسابه تلقائياً.</p>
                )}
              </div>
            ))}

            {isAdmin && visibleReceivedPayroll.length > 0 && (
              <div className="space-y-3 pt-3 border-t border-[#1f2127]">
                <h3 className="text-sm font-black text-white">إيصالات موقعة</h3>
                {visibleReceivedPayroll.slice(0, 6).map((item: any) => (
                  <div key={item.id} className="bg-[#0a0b0d] border border-green-500/20 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="text-white font-bold">{item.employeeName}</p>
                      <p className="text-xs text-[#6b7280]">
                        {Number(item.amount || 0).toLocaleString()} LYD · {item.receivedAt ? new Date(item.receivedAt).toLocaleString('ar-LY') : '-'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDownloadPayrollReceipt(item)}
                      disabled={actionLoading === `receipt-${item.id}`}
                      className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-green-600/10 border border-green-500/20 text-green-500 text-xs font-bold hover:bg-green-600 hover:text-white"
                    >
                      <FileDown size={15} />
                      {actionLoading === `receipt-${item.id}` ? 'جاري التحميل...' : 'PDF الاستلام'}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6 md:p-8 space-y-5">
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                <HandCoins size={20} className="text-orange-500" />
                {isWorker ? 'طلب سلفة' : 'مراجعة طلبات السلفة'}
              </h2>
              <p className="text-xs text-[#6b7280] mt-1">
                {isWorker ? 'قدّم طلب السلفة من حسابك فقط.' : 'الأدمن يراجع الطلبات ولا ينشئ سلفة بدل الموظف.'}
              </p>
            </div>

            {isWorker && (
              <form onSubmit={handleAdvanceSubmit} className="space-y-3">
                <input
                  type="number"
                  min="1"
                  required
                  value={advanceForm.amount}
                  onChange={(e) => setAdvanceForm({ ...advanceForm, amount: e.target.value })}
                  className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
                  placeholder="قيمة السلفة"
                />
                <input
                  value={advanceForm.reason}
                  onChange={(e) => setAdvanceForm({ ...advanceForm, reason: e.target.value })}
                  className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
                  placeholder="السبب أو ملاحظة"
                />
                <button
                  type="submit"
                  disabled={actionLoading === 'advance-request'}
                  className="w-full py-3 rounded-2xl bg-orange-600 disabled:opacity-50 text-white font-bold hover:bg-orange-500"
                >
                  {actionLoading === 'advance-request' ? 'جاري الإرسال...' : 'إرسال طلب السلفة'}
                </button>
              </form>
            )}

            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {visibleAdvanceRequests.length === 0 ? (
                <p className="text-sm text-[#6b7280] bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">لا توجد طلبات سلفة.</p>
              ) : visibleAdvanceRequests.slice(0, 8).map((item: any) => (
                <div key={item.id} className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-white font-bold">{item.employeeName}</p>
                      <p className="text-xs text-[#6b7280]">{item.reason || 'بدون ملاحظة'}</p>
                    </div>
                    <div className="text-left">
                      <p className="text-orange-500 font-black">{Number(item.amount || 0).toLocaleString()} LYD</p>
                      <p className={`text-[10px] font-bold ${item.status === 'approved' ? 'text-green-500' : item.status === 'rejected' ? 'text-red-500' : 'text-yellow-500'}`}>
                        {item.status === 'approved' ? 'مقبولة' : item.status === 'rejected' ? 'مرفوضة' : 'تنتظر'}
                      </p>
                    </div>
                  </div>
                  {isAdmin && item.status === 'pending' && (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleAdvanceAction(item.id, 'approve')}
                        disabled={actionLoading === `approve-${item.id}`}
                        className="flex items-center justify-center gap-2 py-2 rounded-xl bg-green-600 text-white text-xs font-bold hover:bg-green-500"
                      >
                        <CheckCircle2 size={14} />
                        موافقة
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAdvanceAction(item.id, 'reject')}
                        disabled={actionLoading === `reject-${item.id}`}
                        className="flex items-center justify-center gap-2 py-2 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-500"
                      >
                        <XCircle size={14} />
                        رفض
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 flex flex-col min-h-[400px]">
          {data.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center opacity-30">
              <Wallet size={48} className="mb-4" />
              <p className="font-mono font-bold uppercase tracking-[0.3em]">{loading ? 'Syncing_Ledger...' : 'No_Transactions'}</p>
            </div>
          ) : (
            <div className="space-y-4 w-full">
              {data.map((trx: any) => {
                const salaryPayment = isSalaryPaymentCategory(trx.category);
                const deductionPayment = trx.category === 'خصم' || trx.category === 'سلفة';
                return (
                <div key={trx.id} className={`bg-[#0a0b0d] p-4 border rounded-2xl flex justify-between items-center group transition-all gap-4 ${deductionPayment ? 'border-red-500/20 hover:border-red-500/50' : salaryPayment ? 'border-green-500/20 hover:border-green-500/50' : 'border-[#1f2127] hover:border-orange-500/30'}`}>
                  <div className="flex items-center gap-4 overflow-hidden">
                    <div className={trx.type === 'income' || salaryPayment ? 'text-green-500 shrink-0' : (deductionPayment ? 'text-red-500 shrink-0' : 'text-orange-500 shrink-0')}>
                      {salaryPayment ? <CheckCircle2 size={20} /> : trx.type === 'income' ? <ArrowUpRight size={20} /> : <ArrowDownRight size={20} />}
                    </div>
                    <div className="truncate">
                      <p className="font-bold text-white truncate">{trx.category || 'عام'}</p>
                      <p className="text-[10px] text-[#6b7280] font-mono">
                        {new Date(trx.timestamp).toLocaleDateString()} · {getDepartmentName(trx.departmentId)}
                        {salaryPayment ? ' · صرف راتب وليس خصماً' : ''}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 sm:gap-4 shrink-0">
                    <span className={`font-mono font-bold text-sm sm:text-base ${trx.type === 'income' || salaryPayment ? 'text-green-500' : (deductionPayment ? 'text-red-500' : 'text-orange-500')}`}>
                      {salaryPayment ? 'صرف ' : trx.type === 'income' ? '+' : '-'}{trx.amount.toLocaleString()} 
                    </span>
                    {(user.role === 'ADMIN' || user.role === 'MANAGER') && (
                      <button 
                        onClick={() => handleDeleteTrx(trx.id)}
                        className="opacity-100 sm:opacity-0 group-hover:opacity-100 p-2 text-red-500/50 hover:text-red-500 transition-all"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>
                );
              })}
            </div>
          )}
        </div>
        
        <div className="space-y-6">
          <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-8 glow-orange">
            <h3 className="text-xs font-bold text-[#6b7280] uppercase tracking-widest font-mono mb-6">Realtime_Summary</h3>
            <div className="space-y-4">
              <div className="flex justify-between border-b border-[#1f2127] pb-3">
                <span className="text-[#6b7280] text-sm">إجمالي الدخل</span>
                <span className="text-green-500 font-mono font-black">{totalIncome.toLocaleString()} LYD</span>
              </div>
              <div className="flex justify-between border-b border-[#1f2127] pb-3">
                <span className="text-[#6b7280] text-sm">إجمالي المصروف</span>
                <span className="text-orange-600 font-mono font-black">{totalExpense.toLocaleString()} LYD</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-white font-bold text-sm">صافي الصندوق</span>
                <span className="text-orange-500 font-mono font-black">{(totalIncome - totalExpense).toLocaleString()} LYD</span>
              </div>
            </div>
            <button 
              onClick={handleExportPDF}
              className="w-full mt-8 flex items-center justify-center gap-2 py-4 bg-orange-600/10 border border-orange-500/20 text-orange-500 rounded-2xl font-bold hover:bg-orange-600 hover:text-white transition-all"
            >
              <Printer size={18} />
              تصدير كشف PDF
            </button>
          </div>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalType === 'income' ? 'تسجيل إيراد جديد' : 'تسجيل مصروف جديد'}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">الفئة</label>
            <input
              type="text"
              required
              value={formData.category}
              onChange={(e) => {
                const nextCategory = e.target.value;
                setFormData({
                  ...formData,
                  category: nextCategory,
                  employeeId: isEmployeeFinanceCategory(nextCategory) ? formData.employeeId : ''
                });
              }}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
              placeholder="مثال: رواتب، مبيعات، إيجار..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">المبلغ (LYD)</label>
            <input
              type="number"
              required
              value={formData.amount}
              onChange={(e) => setFormData({...formData, amount: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-[#6b7280]">ملاحظات إضافية</label>
            <input
              type="text"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
            />
          </div>

          {isAdmin && isEmployeeFinanceCategory(formData.category) && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">الموظف المرتبط</label>
              <select
                value={formData.employeeId}
                onChange={(e) => setFormData({...formData, employeeId: e.target.value})}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all"
                required
              >
                <option value="">اختار الموظف</option>
                {users.filter((u: any) => u.role === 'EMPLOYEE' || u.role === 'FREELANCER').map(u => (
                  <option key={u.id} value={u.id}>{u.username} ({u.role})</option>
                ))}
              </select>
            </div>
          )}

          {isAdmin && !isEmployeeFinanceCategory(formData.category) && (
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 text-xs text-[#8b929f]">
              هذه حركة إدارية عامة ولن تُربط بأي موظف حتى لو كنت فاتح كشف موظف.
            </div>
          )}

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-500/20"
            >
              تسجيل العملية
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-6 py-3 bg-[#1f2127] text-white font-bold rounded-xl hover:bg-[#2a2d35] transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
