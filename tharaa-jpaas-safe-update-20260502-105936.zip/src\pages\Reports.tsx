import React, { useState, useEffect } from 'react';
import { BarChart3, Download, FileText, PieChart as PieChartIcon } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { saveArabicReportPdf } from '../lib/pdfArabic';

export default function Reports() {
  const [summary, setSummary] = useState<any>(null);

  useEffect(() => {
    fetch('/api/reports/summary', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(r => r.json())
    .then(data => setSummary(data));
  }, []);

  const handleExportPDF = async (type: string) => {
    let url = '/api/finance';
    let title = 'تقرير النظام';

    if (type === 'users') { url = '/api/users'; title = 'تقرير الموظفين'; }
    if (type === 'tasks') { url = '/api/tasks'; title = 'تقرير المهام'; }
    if (type === 'finance') { url = '/api/finance?includeEmployee=1'; title = 'تقرير المالية'; }
    if (type === 'attendance') { url = '/api/attendance'; title = 'تقرير الحضور'; }
    if (type === 'weekly') { url = '/api/reports/summary'; title = 'التقرير الأسبوعي'; }
    if (type === 'monthly') { url = '/api/reports/summary'; title = 'التقرير الشهري'; }
    if (type === 'annual') { url = '/api/reports/summary'; title = 'التقرير السنوي'; }
    if (type === 'all') { url = '/api/reports/summary'; title = 'الملخص العام'; }

    try {
      const resp = await fetch(url, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      
      if (!resp.ok) {
        throw new Error(`API Error: ${resp.status}`);
      }
      const data = await resp.json();

      if (type === 'all' || type === 'weekly' || type === 'monthly' || type === 'annual') {
        await saveArabicReportPdf({
          filename: `${type}_report_${Date.now()}.pdf`,
          title,
          meta: [{ label: 'تاريخ التصدير', value: new Date().toLocaleString('ar-LY') }],
          summary: [
            { label: 'إجمالي الموظفين', value: data.totalUsers || 0, tone: 'dark' },
            { label: 'الأقسام النشطة', value: data.totalDepartments || 0, tone: 'dark' },
            { label: 'إجمالي الإيرادات', value: `${(data.totalRevenue || 0).toLocaleString()} LYD`, tone: 'green' },
            { label: 'إجمالي المصروفات', value: `${(data.totalExpenses || 0).toLocaleString()} LYD`, tone: 'orange' },
            { label: 'الصافي', value: `${(data.netProfit || 0).toLocaleString()} LYD`, tone: 'dark' }
          ],
          footer: ['الملخص التشغيلي']
        });
      } else if (Array.isArray(data)) {
        const departmentsResp = await fetch('/api/departments', {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        const departments = departmentsResp.ok ? await departmentsResp.json() : [];
        const departmentNameById = (Array.isArray(departments) ? departments : []).reduce<Record<string, string>>((acc, dept: any) => {
          acc[dept.id] = dept.name;
          return acc;
        }, {});
        const normalizedData = data.map((item: any) => ({
          ...item,
          departmentName: item.departmentName || (item.departmentId ? departmentNameById[item.departmentId] || item.departmentId : item.departmentName)
        }));
        const headersMap: any = {
          'username': 'المستخدم',
          'role': 'الصلاحية',
          'departmentName': 'القسم',
          'amount': 'المبلغ',
          'category': 'الفئة',
          'type': 'النوع',
          'timestamp': 'التاريخ',
          'createdAt': 'تاريخ الإنشاء',
          'status': 'الحالة',
          'title': 'المهمة',
          'description': 'الوصف'
        };

        const firstItem = normalizedData[0] || {};
        const excludedHeaders = ['id', 'password', 'employeeId', 'departmentId'];
        const preferredHeaders = ['username', 'departmentName', 'role', 'amount', 'category', 'type', 'timestamp', 'createdAt', 'status', 'title', 'description'];
        const headers = [
          ...preferredHeaders.filter(k => Object.prototype.hasOwnProperty.call(firstItem, k)),
          ...Object.keys(firstItem).filter(k => !preferredHeaders.includes(k) && !excludedHeaders.includes(k))
        ]
          .filter(k => !excludedHeaders.includes(k))
          .slice(0, 6);

        const rows = normalizedData.map((item: any) => headers.map(h => {
          let val = item[h];
          if (h === 'timestamp' || h === 'createdAt') return new Date(val).toLocaleDateString();
          if (h === 'type') return val === 'income' ? 'إيراد' : val === 'expense' ? 'مصروف' : String(val || '-');
          if (typeof val === 'number') return val.toLocaleString();
          return String(val || '-');
        }));
        
        await saveArabicReportPdf({
          filename: `${type}_report_${Date.now()}.pdf`,
          title,
          meta: [{ label: 'تاريخ التصدير', value: new Date().toLocaleString('ar-LY') }],
          table: {
            title: 'البيانات',
            head: headers.map(h => headersMap[h] || h.toUpperCase()),
            rows,
            rowsPerPage: headers.length > 5 ? 18 : 23
          },
          footer: [title]
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const chartData = summary ? [
    { name: 'الإيرادات', value: summary.totalRevenue },
    { name: 'المصروفات', value: summary.totalExpenses },
  ] : [];

  const COLORS = ['#22c55e', '#f97316'];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black text-white">التقارير التحليلية</h1>
          <p className="text-[#6b7280]">بيانات دقيقة لدعم اتخاذ القرار</p>
        </div>
        <button 
          onClick={() => handleExportPDF('all')}
          className="flex items-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-2xl transition-all shadow-lg active:scale-95"
        >
          <Download size={18} />
          <span>تصدير الملخص الـ PDF</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#111318] border border-[#1f2127] p-8 rounded-[2rem] min-h-[400px]">
           <h3 className="text-xs font-black text-[#6b7280] uppercase tracking-widest font-mono mb-8 flex items-center gap-2">
             <BarChart3 size={14} className="text-orange-500" />
             Financial_Performance_Map
           </h3>
           <div className="h-[300px] w-full">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={chartData}>
                 <CartesianGrid strokeDasharray="3 3" stroke="#1f2127" />
                 <XAxis dataKey="name" stroke="#6b7280" fontSize={12} />
                 <YAxis stroke="#6b7280" fontSize={12} />
                 <Tooltip 
                   contentStyle={{ backgroundColor: '#111318', border: '1px solid #1f2127', borderRadius: '12px' }}
                   itemStyle={{ color: '#fff' }}
                 />
                 <Bar dataKey="value" fill="#f97316" radius={[4, 4, 0, 0]} />
               </BarChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-[#111318] border border-[#1f2127] p-8 rounded-[2rem] flex flex-col items-center">
           <h3 className="text-xs font-black text-[#6b7280] uppercase tracking-widest font-mono mb-8 w-full flex items-center gap-2">
             <PieChartIcon size={14} className="text-orange-500" />
             Distribution_Ratio
           </h3>
           <div className="h-[300px] w-full">
             <ResponsiveContainer width="100%" height="100%">
               <PieChart>
                 <Pie
                   data={chartData}
                   cx="50%"
                   cy="50%"
                   innerRadius={60}
                   outerRadius={80}
                   paddingAngle={5}
                   dataKey="value"
                 >
                   {chartData.map((entry, index) => (
                     <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                   ))}
                 </Pie>
                 <Tooltip />
               </PieChart>
             </ResponsiveContainer>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { id: 'all', title: 'الملخص العام (Tharaa Summary)', desc: 'تحليل شامل لجميع بيانات النظام' },
          { id: 'weekly', title: 'التقرير الأسبوعي', desc: 'مراجعة الأداء خلال الـ 7 أيام الماضية' },
          { id: 'monthly', title: 'التقرير الشهري', desc: 'كشف مالي وإداري للشهر الحالي' },
          { id: 'annual', title: 'التقرير السنوي', desc: 'ملخص استراتيجي للسنة المالية' },
          { id: 'finance', title: 'سجل المعاملات المالية', desc: 'تصدير كافة الصادرات والواردات النقدية' },
          { id: 'attendance', title: 'سجل الحضور الذكي', desc: 'مراجعة بروتوكولات تسجيل الدخول والخروج' },
          { id: 'users', title: 'دليل الكادر البشري', desc: 'قائمة كاملة ببيانات الموظفين والأدوار' },
          { id: 'tasks', title: 'أرشيف المهام والعمليات', desc: 'سجل كامل بكافة المهام المنجزة والمعلقة' }
        ].map((report, i) => (
          <div 
            key={i} 
            onClick={() => handleExportPDF(report.id)}
            className="bg-[#111318] border border-[#1f2127] p-6 rounded-2xl hover:border-orange-500/30 transition-all cursor-pointer group flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="p-3 bg-[#0a0b0d] border border-[#1f2127] rounded-xl text-orange-500 group-hover:bg-orange-600 group-hover:text-white transition-all">
                <FileText size={18} />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white mb-0.5">{report.title}</h3>
                <p className="text-[10px] text-[#6b7280]">{report.desc}</p>
              </div>
            </div>
            <Download size={14} className="text-[#1f2127] group-hover:text-orange-500 transition-colors" />
          </div>
        ))}
      </div>
    </div>
  );
}
