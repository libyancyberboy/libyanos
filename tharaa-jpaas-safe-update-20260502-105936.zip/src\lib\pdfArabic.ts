import { jsPDF } from 'jspdf';

type PdfCell = string | number | null | undefined;
type Rgb = [number, number, number];

interface ArabicReportTable {
  title?: string;
  head: string[];
  rows: PdfCell[][];
  rowsPerPage?: number;
}

interface PdfTextStyle {
  fontSize?: number;
  bold?: boolean;
  italic?: boolean;
  color?: string;
}

interface ArabicReportLetter {
  recipient: string;
  reference?: string;
  date?: string;
  subject?: string;
  body: string;
  greeting?: string;
  styles?: {
    recipient?: PdfTextStyle;
    greeting?: PdfTextStyle;
    body?: PdfTextStyle;
    signer?: PdfTextStyle;
  };
}

interface ArabicReportOptions {
  filename: string;
  title: string;
  subtitle?: string;
  hideBrand?: boolean;
  topOffset?: number;
  invoiceHeader?: {
    titleAr?: string;
    titleEn?: string;
  };
  meta?: Array<string | { label: string; value: PdfCell }>;
  summary?: Array<{ label: string; value: PdfCell; tone?: 'green' | 'orange' | 'dark' }>;
  image?: {
    dataUrl: string;
    caption?: string;
  };
  contentHtml?: string;
  sections?: Array<{
    title?: string;
    body: PdfCell;
  }>;
  letter?: ArabicReportLetter;
  table?: ArabicReportTable;
  tables?: ArabicReportTable[];
  footer?: string[];
  stamp?: {
    name: string;
    title: string;
  };
}

const PAGE_WIDTH = 794;
const PAGE_HEIGHT = 1123;
const PAGE_MARGIN = 52;
const CONTENT_WIDTH = PAGE_WIDTH - PAGE_MARGIN * 2;
const FOOTER_LINE_Y = 1064;
const FOOTER_TEXT_Y = 1086;
const PAGE_BOTTOM_LIMIT = 1034;
const LETTERHEAD_BOTTOM_LIMIT = 928;
const CANVAS_SCALE = 2;
const FONT_FAMILY = '"ThmanyahSans", "Tahoma", "Arial", sans-serif';
const COMPANY_NAME = 'THARA PRODUCTION';
const LETTERHEAD_SRC = '/icons/letterhead-template.png';
const OFFICIAL_LETTER_SRC = '/icons/official-letter-template.png';

const COLOR = {
  ink: [17, 19, 24] as Rgb,
  muted: [95, 102, 115] as Rgb,
  line: [217, 221, 229] as Rgb,
  soft: [247, 248, 250] as Rgb,
  orange: [249, 115, 22] as Rgb,
  green: [21, 128, 61] as Rgb,
  white: [255, 255, 255] as Rgb,
};

interface CanvasPage {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  y: number;
  bottomLimit: number;
  hasLetterhead: boolean;
  isOfficialLetter: boolean;
}

const textValue = (value: PdfCell) => String(value ?? '-').replace(/\s+/g, ' ').trim() || '-';

const normalizeDigits = (value: string) =>
  value
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)));

const parseManualDate = (value: string) => {
  const parts = normalizeDigits(value).trim().split(/[^\d]+/).filter(Boolean);
  if (parts.length < 3) return null;

  const [first, second, third] = parts;
  const isYearFirst = first?.length === 4;
  const year = isYearFirst ? first : (third?.length === 4 ? third : parts.find((part) => part.length === 4) || third);
  const month = second?.padStart(2, '0').slice(-2);
  const day = (isYearFirst ? third : first)?.padStart(2, '0').slice(-2);

  if (!year || !month || !day) return null;
  return {
    year: year.length === 2 ? `20${year}` : year,
    yearSuffix: year.slice(-2),
    month,
    day,
  };
};

const formatLetterDate = (value: string) => {
  const parsed = parseManualDate(value);
  return parsed ? `${parsed.day} / ${parsed.month} / ${parsed.year}` : normalizeDigits(value);
};

const cssColor = (color: Rgb) => `rgb(${color[0]}, ${color[1]}, ${color[2]})`;

const setFont = (ctx: CanvasRenderingContext2D, size: number, weight = 400, italic = false) => {
  ctx.font = `${italic ? 'italic ' : ''}${weight} ${size}px ${FONT_FAMILY}`;
};

const hexToRgb = (value?: string, fallback: Rgb = COLOR.ink): Rgb => {
  if (!value) return fallback;
  const clean = value.trim().replace('#', '');
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) return fallback;
  return [
    parseInt(clean.slice(0, 2), 16),
    parseInt(clean.slice(2, 4), 16),
    parseInt(clean.slice(4, 6), 16),
  ];
};

const styleSize = (style: PdfTextStyle | undefined, fallback: number) => {
  const value = Number(style?.fontSize);
  if (!Number.isFinite(value)) return fallback;
  return Math.min(34, Math.max(10, value));
};

const styleWeight = (style: PdfTextStyle | undefined, fallback = 400) => (
  style?.bold ? 800 : fallback
);

const loadImage = (src: string) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    const timer = window.setTimeout(() => reject(new Error(`Image timeout: ${src}`)), 7000);
    image.onload = () => {
      window.clearTimeout(timer);
      resolve(image);
    };
    image.onerror = () => {
      window.clearTimeout(timer);
      reject(new Error(`Image load failed: ${src}`));
    };
    image.src = src;
  });

const prepareFonts = async () => {
  try {
    if (!document.fonts) return;
    await Promise.all([
      document.fonts.load(`400 24px ${FONT_FAMILY}`),
      document.fonts.load(`800 32px ${FONT_FAMILY}`),
    ]);
    await document.fonts.ready;
  } catch (error) {
    console.warn('PDF font readiness check failed, using browser fallback fonts.', error);
  }
};

const wrapTextByWidth = (
  ctx: CanvasRenderingContext2D,
  value: PdfCell,
  maxWidth: number,
  maxLines = 4
) => {
  const text = textValue(value);
  const words = text.split(' ');
  const lines: string[] = [];
  let current = '';

  words.forEach(word => {
    const trial = current ? `${current} ${word}` : word;
    if (ctx.measureText(trial).width <= maxWidth) {
      current = trial;
      return;
    }

    if (current) {
      lines.push(current);
      current = '';
    }

    if (ctx.measureText(word).width <= maxWidth) {
      current = word;
      return;
    }

    let chunk = '';
    Array.from(word).forEach(char => {
      const next = `${chunk}${char}`;
      if (ctx.measureText(next).width > maxWidth && chunk) {
        lines.push(chunk);
        chunk = char;
      } else {
        chunk = next;
      }
    });
    if (chunk) current = chunk;
  });

  if (current) lines.push(current);
  return lines.slice(0, maxLines);
};

const wrapBalancedTextByWidth = (
  ctx: CanvasRenderingContext2D,
  value: PdfCell,
  maxWidth: number,
  maxLines = 999
) => {
  let lines = wrapTextByWidth(ctx, value, maxWidth, maxLines);

  const widthOf = (text: string) => ctx.measureText(text).width;
  const rebalancePair = (firstLine: string, secondLine: string) => {
    const words = `${firstLine} ${secondLine}`.split(/\s+/).filter(Boolean);
    if (words.length < 4) return [firstLine, secondLine];

    let best = [firstLine, secondLine];
    let bestScore = Number.POSITIVE_INFINITY;

    for (let split = 2; split <= words.length - 2; split += 1) {
      const first = words.slice(0, split).join(' ');
      const second = words.slice(split).join(' ');
      const firstWidth = widthOf(first);
      const secondWidth = widthOf(second);

      if (firstWidth > maxWidth || secondWidth > maxWidth) continue;

      const shortPenalty = Math.max(0, maxWidth * 0.66 - firstWidth) + Math.max(0, maxWidth * 0.66 - secondWidth);
      const score = Math.abs(firstWidth - secondWidth) + shortPenalty * 1.6;

      if (score < bestScore) {
        bestScore = score;
        best = [first, second];
      }
    }

    return best;
  };

  for (let pass = 0; pass < 3; pass += 1) {
    for (let index = lines.length - 1; index > 0; index -= 1) {
      const [first, second] = rebalancePair(lines[index - 1], lines[index]);
      lines[index - 1] = first;
      lines[index] = second;
    }
  }

  return lines.slice(0, maxLines);
};

const drawText = (
  page: CanvasPage,
  value: PdfCell,
  x: number,
  y: number,
  options: {
    size?: number;
    weight?: number;
    color?: Rgb;
    align?: CanvasTextAlign;
    direction?: 'rtl' | 'ltr';
    maxWidth?: number;
    maxLines?: number;
    lineHeight?: number;
    italic?: boolean;
  } = {}
) => {
  const { ctx } = page;
  const size = options.size || 16;
  const lineHeight = options.lineHeight || Math.round(size * 1.35);
  setFont(ctx, size, options.weight || 400, options.italic);
  ctx.fillStyle = cssColor(options.color || COLOR.ink);
  ctx.textAlign = options.align || (options.direction === 'ltr' ? 'left' : 'right');
  ctx.textBaseline = 'alphabetic';
  (ctx as any).direction = options.direction || 'rtl';

  const lines = options.maxWidth
    ? wrapTextByWidth(ctx, value, options.maxWidth, options.maxLines)
    : [textValue(value)];

  lines.forEach((line, index) => {
    ctx.fillText(line, x, y + index * lineHeight);
  });

  return lines.length * lineHeight;
};

const drawBalancedLine = (
  page: CanvasPage,
  value: PdfCell,
  centerX: number,
  y: number,
  maxWidth: number,
  options: {
    size?: number;
    weight?: number;
    color?: Rgb;
    italic?: boolean;
    justify?: boolean;
  } = {}
) => {
  const { ctx } = page;
  const text = textValue(value);
  const size = options.size || 19;
  const weight = options.weight || 400;
  const words = text.split(/\s+/).filter(Boolean);

  setFont(ctx, size, weight, options.italic);
  ctx.fillStyle = cssColor(options.color || COLOR.ink);
  ctx.textBaseline = 'alphabetic';
  (ctx as any).direction = 'rtl';

  const naturalWidth = ctx.measureText(text).width;
  if ((!options.justify && (words.length < 3 || naturalWidth < maxWidth * 0.45)) || words.length < 2) {
    ctx.textAlign = 'center';
    ctx.fillText(text, centerX, y);
    return;
  }

  const wordsWidth = words.reduce((sum, word) => sum + ctx.measureText(word).width, 0);
  const gap = Math.max(7, (maxWidth - wordsWidth) / (words.length - 1));
  let x = centerX + maxWidth / 2;
  ctx.textAlign = 'right';

  words.forEach((word) => {
    ctx.fillText(word, x, y);
    x -= ctx.measureText(word).width + gap;
  });
};

const drawFittedText = (
  page: CanvasPage,
  value: PdfCell,
  x: number,
  y: number,
  options: {
    size: number;
    minSize?: number;
    weight?: number;
    color?: Rgb;
    align?: CanvasTextAlign;
    direction?: 'rtl' | 'ltr';
    maxWidth: number;
    italic?: boolean;
  }
) => {
  const { ctx } = page;
  const text = textValue(value);
  let size = options.size;
  const minSize = options.minSize || 9;
  const weight = options.weight || 400;

  setFont(ctx, size, weight, options.italic);
  while (size > minSize && ctx.measureText(text).width > options.maxWidth) {
    size -= 1;
    setFont(ctx, size, weight, options.italic);
  }

  ctx.fillStyle = cssColor(options.color || COLOR.ink);
  ctx.textAlign = options.align || 'center';
  ctx.textBaseline = 'alphabetic';
  (ctx as any).direction = options.direction || 'rtl';
  ctx.fillText(text, x, y);
};

const roundedRect = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
  fill: Rgb,
  stroke?: Rgb,
  lineWidth = 1
) => {
  const safeRadius = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + safeRadius, y);
  ctx.lineTo(x + width - safeRadius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + safeRadius);
  ctx.lineTo(x + width, y + height - safeRadius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - safeRadius, y + height);
  ctx.lineTo(x + safeRadius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - safeRadius);
  ctx.lineTo(x, y + safeRadius);
  ctx.quadraticCurveTo(x, y, x + safeRadius, y);
  ctx.closePath();
  ctx.fillStyle = cssColor(fill);
  ctx.fill();

  if (stroke) {
    ctx.strokeStyle = cssColor(stroke);
    ctx.lineWidth = lineWidth;
    ctx.stroke();
  }
};

const drawImageContain = (
  ctx: CanvasRenderingContext2D,
  image: HTMLImageElement,
  x: number,
  y: number,
  width: number,
  height: number,
  align: 'left' | 'center' | 'right' = 'center'
) => {
  const imageWidth = image.naturalWidth || image.width || width;
  const imageHeight = image.naturalHeight || image.height || height;
  const scale = Math.min(width / imageWidth, height / imageHeight);
  const drawWidth = imageWidth * scale;
  const drawHeight = imageHeight * scale;
  const drawX = align === 'right'
    ? x + width - drawWidth
    : align === 'left'
      ? x
      : x + (width - drawWidth) / 2;
  const drawY = y + (height - drawHeight) / 2;

  ctx.drawImage(image, drawX, drawY, drawWidth, drawHeight);
};

const extractImageFromContent = (contentHtml?: string) => {
  if (!contentHtml) return null;
  const imageMatch = contentHtml.match(/src="([^"]+)"/);
  const captionMatch = contentHtml.match(/<p>(.*?)<\/p>/);
  return imageMatch ? {
    dataUrl: imageMatch[1],
    caption: captionMatch?.[1]?.replace(/<[^>]+>/g, '')
  } : null;
};

const createPage = (
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null
) => {
  const canvas = document.createElement('canvas');
  canvas.width = PAGE_WIDTH * CANVAS_SCALE;
  canvas.height = PAGE_HEIGHT * CANVAS_SCALE;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas is not available.');

  ctx.scale(CANVAS_SCALE, CANVAS_SCALE);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, PAGE_WIDTH, PAGE_HEIGHT);

  const page: CanvasPage = {
    canvas,
    ctx,
    y: options.hideBrand
      ? (options.invoiceHeader ? 154 + (options.topOffset || 0) : 74 + (options.topOffset || 0))
      : (letterhead ? (options.letter ? 184 : 206) : 122),
    bottomLimit: letterhead ? LETTERHEAD_BOTTOM_LIMIT : PAGE_BOTTOM_LIMIT,
    hasLetterhead: Boolean(letterhead),
    isOfficialLetter: Boolean(options.letter),
  };
  if (letterhead) {
    ctx.drawImage(letterhead, 0, 0, PAGE_WIDTH, PAGE_HEIGHT);
  }
  drawPageHeader(page, options, logo);
  return page;
};

const drawPageHeader = (
  page: CanvasPage,
  options: ArabicReportOptions,
  logo: HTMLImageElement | null
) => {
  const { ctx } = page;

  if (options.hideBrand) {
    if (options.invoiceHeader) {
      if (logo) {
        drawImageContain(ctx, logo, PAGE_WIDTH - PAGE_MARGIN - 230, 26, 230, 82, 'right');
      } else {
        drawText(page, COMPANY_NAME, PAGE_WIDTH - PAGE_MARGIN, 66, {
          size: 22,
          weight: 800,
          color: COLOR.orange,
          maxWidth: 230,
        });
      }

      drawText(page, options.invoiceHeader.titleAr || 'فاتورة', PAGE_MARGIN, 58, {
        size: 36,
        weight: 800,
        align: 'left',
        maxWidth: 240,
      });
      drawText(page, options.invoiceHeader.titleEn || 'INVOICE', PAGE_MARGIN, 88, {
        size: 16,
        weight: 800,
        color: COLOR.muted,
        align: 'left',
        direction: 'ltr',
        maxWidth: 240,
      });

      ctx.strokeStyle = cssColor(COLOR.orange);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(PAGE_MARGIN, 124);
      ctx.lineTo(PAGE_WIDTH - PAGE_MARGIN, 124);
      ctx.stroke();
      return;
    }

    const offset = options.topOffset || 0;
    drawText(page, options.title, PAGE_WIDTH / 2, 46 + offset, {
      size: 31,
      weight: 800,
      align: 'center',
      maxWidth: CONTENT_WIDTH,
      maxLines: 2,
      lineHeight: 36,
    });
    ctx.strokeStyle = cssColor(COLOR.orange);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(PAGE_MARGIN, 68 + offset);
    ctx.lineTo(PAGE_WIDTH - PAGE_MARGIN, 68 + offset);
    ctx.stroke();
    return;
  }

  if (page.hasLetterhead) {
    if (!options.letter) {
      drawText(page, options.title, PAGE_WIDTH / 2, 158, {
        size: 29,
        weight: 800,
        align: 'center',
        maxWidth: 500,
        maxLines: 2,
        lineHeight: 34,
      });

      if (options.subtitle) {
        drawText(page, options.subtitle, PAGE_WIDTH / 2, 188, {
          size: 15,
          color: COLOR.muted,
          align: 'center',
          maxWidth: 480,
          maxLines: 1,
        });
      }
    }
    return;
  }

  if (logo) {
    ctx.drawImage(logo, PAGE_MARGIN - 8, 18, 160, 82);
  } else {
    drawText(page, COMPANY_NAME, PAGE_MARGIN, 55, {
      size: 22,
      weight: 800,
      color: COLOR.orange,
      align: 'left',
      direction: 'ltr',
    });
  }

  drawText(page, options.title, PAGE_WIDTH - PAGE_MARGIN, 54, {
    size: 31,
    weight: 800,
    maxWidth: 360,
    maxLines: 2,
    lineHeight: 37,
  });

  if (options.subtitle) {
    drawText(page, options.subtitle, PAGE_WIDTH - PAGE_MARGIN, 86, {
      size: 17,
      color: COLOR.muted,
      maxWidth: 420,
    });
  }

  ctx.strokeStyle = cssColor(COLOR.orange);
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(PAGE_MARGIN, 104);
  ctx.lineTo(PAGE_WIDTH - PAGE_MARGIN, 104);
  ctx.stroke();
};

const ensureSpace = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null,
  neededHeight: number
) => {
  let page = pages[pages.length - 1];
  if (page.y + neededHeight <= page.bottomLimit) return page;

  page = createPage(options, logo, letterhead);
  pages.push(page);
  return page;
};

const drawMeta = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null
) => {
  if (!options.meta?.length) return;

  let page = pages[pages.length - 1];
  const gap = 10;
  const width = (CONTENT_WIDTH - gap) / 2;
  const height = 48;
  const rows = Math.ceil(options.meta.length / 2);
  page = ensureSpace(pages, options, logo, letterhead, rows * (height + gap) + 10);

  options.meta.forEach((item, index) => {
    const col = index % 2;
    const row = Math.floor(index / 2);
    const x = col === 0 ? PAGE_WIDTH - PAGE_MARGIN - width : PAGE_MARGIN;
    const y = page.y + row * (height + gap);
    roundedRect(page.ctx, x, y, width, height, 12, COLOR.white, COLOR.line);

    if (typeof item === 'string') {
      drawText(page, item, x + width - 14, y + 30, { size: 15, maxWidth: width - 28 });
    } else {
      drawText(page, item.label, x + width - 14, y + 20, { size: 12, color: COLOR.muted, maxWidth: width - 28 });
      drawText(page, item.value, x + width - 14, y + 38, { size: 15, weight: 800, maxWidth: width - 28 });
    }
  });

  page.y += rows * (height + gap) + 8;
};

const drawSummary = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null
) => {
  if (!options.summary?.length) return;

  let page = pages[pages.length - 1];
  const gap = 10;
  const columns = options.summary.length <= 2 ? options.summary.length : 3;
  const width = (CONTENT_WIDTH - gap * (columns - 1)) / columns;
  const height = 76;
  const rows = Math.ceil(options.summary.length / columns);
  page = ensureSpace(pages, options, logo, letterhead, rows * (height + gap) + 12);

  options.summary.forEach((item, index) => {
    const col = index % columns;
    const row = Math.floor(index / columns);
    const x = PAGE_WIDTH - PAGE_MARGIN - width - col * (width + gap);
    const y = page.y + row * (height + gap);
    const fill = item.tone === 'green' ? COLOR.green : item.tone === 'orange' ? COLOR.orange : COLOR.ink;
    roundedRect(page.ctx, x, y, width, height, 14, fill);
    drawText(page, item.label, x + width - 14, y + 25, { size: 13, color: COLOR.white, maxWidth: width - 28 });
    drawText(page, item.value, x + width - 14, y + 56, { size: 22, weight: 800, color: COLOR.white, maxWidth: width - 28 });
  });

  page.y += rows * (height + gap) + 12;
};

const drawImageBlock = async (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null
) => {
  const image = options.image || extractImageFromContent(options.contentHtml);
  if (!image?.dataUrl) return;

  let page = ensureSpace(pages, options, logo, letterhead, 448);
  const cardWidth = 430;
  const cardHeight = 430;
  const x = PAGE_MARGIN + (CONTENT_WIDTH - cardWidth) / 2;
  const y = page.y;

  roundedRect(page.ctx, x, y, cardWidth, cardHeight, 24, COLOR.soft, COLOR.line);

  try {
    const loadedImage = await loadImage(image.dataUrl);
    page.ctx.drawImage(loadedImage, x + 65, y + 32, 300, 300);
  } catch (error) {
    console.warn('PDF image insertion failed:', error);
    drawText(page, 'تعذر إدراج الصورة', x + cardWidth / 2, y + 205, {
      size: 18,
      weight: 800,
      color: COLOR.muted,
      align: 'center',
    });
  }

  if (image.caption) {
    drawText(page, image.caption, PAGE_WIDTH / 2, y + 376, {
      size: 19,
      weight: 800,
      align: 'center',
      maxWidth: cardWidth - 40,
    });
  }

  page.y += cardHeight + 18;
};

const drawSections = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null
) => {
  if (!options.sections?.length) return;

  options.sections.forEach((section) => {
    let page = ensureSpace(pages, options, logo, letterhead, 80);

    if (section.title) {
      drawText(page, section.title, PAGE_WIDTH - PAGE_MARGIN, page.y + 4, {
        size: 20,
        weight: 800,
        maxWidth: CONTENT_WIDTH,
      });
      page.y += 36;
    }

    setFont(page.ctx, 18, 400);
    const rawBody = String(section.body ?? '-').replace(/\r/g, '').trim() || '-';
    const paragraphs = rawBody.split(/\n+/).map(item => item.trim()).filter(Boolean);

    paragraphs.forEach((paragraph) => {
      const lines = wrapTextByWidth(page.ctx, paragraph, CONTENT_WIDTH, 999);
      lines.forEach((line) => {
        if (page.y + 30 > page.bottomLimit) {
          page = createPage(options, logo, letterhead);
          pages.push(page);
        }

        drawText(page, line, PAGE_WIDTH - PAGE_MARGIN, page.y, {
          size: 18,
          color: COLOR.ink,
          maxWidth: CONTENT_WIDTH,
          maxLines: 1,
          lineHeight: 28,
        });
        page.y += 29;
      });

      page.y += 12;
    });

    page.y += 10;
  });
};

const drawOfficialLetter = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null
) => {
  if (!options.letter) return;

  const letter = options.letter;
  let page = pages[pages.length - 1];
  const { ctx } = page;
  const recipientStyle = letter.styles?.recipient;
  const greetingStyle = letter.styles?.greeting;
  const bodyStyle = letter.styles?.body;
  const recipientSize = styleSize(recipientStyle, 20);
  const greetingSize = styleSize(greetingStyle, 19);
  const bodySize = styleSize(bodyStyle, 19);
  const bodyLineHeight = Math.round(bodySize * 1.75);
  const bodyWeight = styleWeight(bodyStyle, 400);
  const bodyColor = hexToRgb(bodyStyle?.color, COLOR.ink);

  if (page.hasLetterhead) {
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.96)';
    ctx.fillRect(28, 36, 254, 84);
    ctx.restore();

    drawText(page, 'التاريخ', 252, 64, {
      size: 15,
      weight: 800,
      maxWidth: 72,
    });
    drawFittedText(page, formatLetterDate(letter.date || ''), 136, 64, {
      size: 13,
      weight: 800,
      align: 'center',
      direction: 'ltr',
      maxWidth: 150,
    });
    drawText(page, 'الإشاري', 252, 96, {
      size: 15,
      weight: 800,
      maxWidth: 72,
    });
    drawFittedText(page, normalizeDigits(letter.reference || '-'), 136, 96, {
      size: 13,
      weight: 800,
      align: 'center',
      direction: 'ltr',
      maxWidth: 150,
    });

    page.y = 216;
    drawText(page, `السادة / ${letter.recipient}`, PAGE_WIDTH - PAGE_MARGIN, page.y, {
      size: recipientSize,
      weight: styleWeight(recipientStyle, 800),
      italic: recipientStyle?.italic,
      color: hexToRgb(recipientStyle?.color, COLOR.ink),
      maxWidth: CONTENT_WIDTH,
      maxLines: 2,
      lineHeight: Math.round(recipientSize * 1.4),
    });
    page.y += 68;
    drawText(page, letter.greeting || 'بعد التحية،', PAGE_WIDTH - PAGE_MARGIN, page.y, {
      size: greetingSize,
      weight: styleWeight(greetingStyle, 800),
      italic: greetingStyle?.italic,
      color: hexToRgb(greetingStyle?.color, COLOR.ink),
      align: 'right',
      maxWidth: CONTENT_WIDTH,
    });
    page.y += Math.round(greetingSize * 2.2);

    setFont(ctx, bodySize, bodyWeight, bodyStyle?.italic);
    const rawBody = String(letter.body ?? '-').replace(/\r/g, '').trim() || '-';
    const paragraphs = rawBody.split(/\n+/).map(item => item.trim()).filter(Boolean);
    const bodyWidth = CONTENT_WIDTH - 118;

    paragraphs.forEach((paragraph) => {
      const lines = wrapBalancedTextByWidth(ctx, paragraph, bodyWidth, 999);

      lines.forEach((line) => {
        if (page.y + bodyLineHeight + 4 > page.bottomLimit - 114) {
          page = createPage(options, logo, letterhead);
          pages.push(page);
          page.y = 194;
        }

        drawBalancedLine(page, line, PAGE_WIDTH / 2, page.y, bodyWidth, {
          size: bodySize,
          weight: bodyWeight,
          italic: bodyStyle?.italic,
          color: bodyColor,
          justify: true,
        });
        page.y += bodyLineHeight;
      });

      page.y += 14;
    });

    page.y += 8;
    return;
  }

  roundedRect(ctx, PAGE_MARGIN, page.y, CONTENT_WIDTH, 92, 18, COLOR.soft, COLOR.line);
  ctx.fillStyle = cssColor(COLOR.orange);
  ctx.fillRect(PAGE_WIDTH - PAGE_MARGIN - 6, page.y + 18, 6, 56);

  drawText(page, 'إلى', PAGE_WIDTH - PAGE_MARGIN - 24, page.y + 31, {
    size: 13,
    weight: 800,
    color: COLOR.muted,
    maxWidth: 380,
  });
  drawText(page, letter.recipient, PAGE_WIDTH - PAGE_MARGIN - 24, page.y + 61, {
    size: recipientSize,
    weight: styleWeight(recipientStyle, 800),
    italic: recipientStyle?.italic,
    color: hexToRgb(recipientStyle?.color, COLOR.ink),
    maxWidth: 390,
    maxLines: 2,
    lineHeight: Math.round(recipientSize * 1.35),
  });

  const infoX = PAGE_MARGIN + 22;
  drawText(page, `التاريخ: ${letter.date || '-'}`, infoX, page.y + 36, {
    size: 15,
    weight: 800,
    color: COLOR.ink,
    align: 'left',
    maxWidth: 250,
  });
  drawText(page, `رقم الإشارة: ${letter.reference || '-'}`, infoX, page.y + 66, {
    size: 15,
    color: COLOR.muted,
    align: 'left',
    maxWidth: 250,
  });

  page.y += 116;

  const subjectBoxHeight = 88;
  roundedRect(ctx, PAGE_MARGIN + 42, page.y, CONTENT_WIDTH - 84, subjectBoxHeight, 18, COLOR.white, COLOR.line);
  ctx.strokeStyle = cssColor(COLOR.orange);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(PAGE_MARGIN + 88, page.y + subjectBoxHeight - 14);
  ctx.lineTo(PAGE_WIDTH - PAGE_MARGIN - 88, page.y + subjectBoxHeight - 14);
  ctx.stroke();

  drawText(page, 'الموضوع', PAGE_WIDTH / 2, page.y + 26, {
    size: 13,
    weight: 800,
    color: COLOR.orange,
    align: 'center',
    maxWidth: CONTENT_WIDTH - 140,
  });
  drawText(page, letter.subject, PAGE_WIDTH / 2, page.y + 58, {
    size: 22,
    weight: 800,
    align: 'center',
    maxWidth: CONTENT_WIDTH - 150,
    maxLines: 2,
    lineHeight: 27,
  });

  page.y += subjectBoxHeight + 42;

  drawText(page, letter.greeting || 'بعد التحية،', PAGE_WIDTH - PAGE_MARGIN, page.y, {
    size: greetingSize,
    weight: styleWeight(greetingStyle, 800),
    italic: greetingStyle?.italic,
    color: hexToRgb(greetingStyle?.color, COLOR.ink),
    align: 'right',
    maxWidth: CONTENT_WIDTH,
  });
  page.y += Math.round(greetingSize * 2.2);

  setFont(ctx, bodySize, bodyWeight, bodyStyle?.italic);
  const rawBody = String(letter.body ?? '-').replace(/\r/g, '').trim() || '-';
  const paragraphs = rawBody.split(/\n+/).map(item => item.trim()).filter(Boolean);
  const bodyWidth = CONTENT_WIDTH - 118;

  paragraphs.forEach((paragraph) => {
    const lines = wrapBalancedTextByWidth(ctx, paragraph, bodyWidth, 999);

    lines.forEach((line) => {
      if (page.y + bodyLineHeight + 4 > PAGE_BOTTOM_LIMIT - 128) {
        page = createPage(options, logo, letterhead);
        pages.push(page);
        page.y += 10;
      }

      drawBalancedLine(page, line, PAGE_WIDTH / 2, page.y, bodyWidth, {
        size: bodySize,
        weight: bodyWeight,
        italic: bodyStyle?.italic,
        color: bodyColor,
        justify: true,
      });
      page.y += bodyLineHeight;
    });

    page.y += 14;
  });

  page.y += 8;
};

const getColumnWidths = (columnCount: number) => {
  if (columnCount <= 4) return Array(columnCount).fill(CONTENT_WIDTH / columnCount);
  if (columnCount === 5) return [130, 135, 125, 140, 160];
  if (columnCount === 6) return [112, 112, 112, 112, 112, 130];
  if (columnCount === 7) return [95, 105, 95, 95, 95, 95, 110];
  if (columnCount === 8) return [84, 90, 84, 84, 84, 84, 84, 96];
  if (columnCount === 9) return [70, 70, 76, 76, 66, 70, 70, 70, 122];
  return Array(columnCount).fill(CONTENT_WIDTH / columnCount);
};

const getTableFontSize = (columnCount: number) => (
  columnCount > 8 ? 11 : columnCount > 7 ? 12 : columnCount > 5 ? 13 : 15
);

const measureTableRow = (
  page: CanvasPage,
  cells: PdfCell[],
  columnWidths: number[],
  isHead = false
) => {
  const fontSize = getTableFontSize(columnWidths.length);
  setFont(page.ctx, fontSize, isHead ? 800 : 400);
  const cellLines = cells.map((cell, index) => wrapTextByWidth(
    page.ctx,
    cell,
    (columnWidths[index] || columnWidths[columnWidths.length - 1]) - 16,
    columnWidths.length > 7 ? 2 : 4
  ));
  const lineCount = Math.max(...cellLines.map(lines => lines.length), 1);
  const rowHeight = Math.max(columnWidths.length > 7 ? 34 : 40, 18 + lineCount * Math.round(fontSize * 1.25));

  return { fontSize, cellLines, rowHeight };
};

const drawTableRow = (
  page: CanvasPage,
  cells: PdfCell[],
  columnWidths: number[],
  isHead = false,
  rowIndex = 0
) => {
  const { ctx } = page;
  const { fontSize, cellLines, rowHeight } = measureTableRow(page, cells, columnWidths, isHead);
  let x = PAGE_WIDTH - PAGE_MARGIN;

  cells.forEach((cell, index) => {
    const width = columnWidths[index] || columnWidths[columnWidths.length - 1];
    x -= width;

    ctx.fillStyle = cssColor(isHead ? COLOR.orange : rowIndex % 2 === 0 ? COLOR.white : COLOR.soft);
    ctx.strokeStyle = cssColor(isHead ? COLOR.orange : COLOR.line);
    ctx.lineWidth = 1;
    ctx.fillRect(x, page.y, width, rowHeight);
    ctx.strokeRect(x, page.y, width, rowHeight);

    const lines = cellLines[index] || [textValue(cell)];
    lines.forEach((line, lineIndex) => {
      drawText(page, line, x + width - 8, page.y + 23 + lineIndex * Math.round(fontSize * 1.25), {
        size: fontSize,
        weight: isHead ? 800 : 400,
        color: isHead ? COLOR.white : COLOR.ink,
        maxWidth: width - 16,
      });
    });
  });

  page.y += rowHeight;
};

const drawTable = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null,
  table: ArabicReportTable
) => {
  let page = pages[pages.length - 1];
  const columnWidths = getColumnWidths(table.head.length);

  page = ensureSpace(pages, options, logo, letterhead, 84);
  if (table.title) {
    drawText(page, table.title, PAGE_WIDTH - PAGE_MARGIN, page.y + 4, {
      size: 20,
      weight: 800,
      maxWidth: CONTENT_WIDTH,
    });
    page.y += 26;
  }

  const drawHeader = () => drawTableRow(page, table.head, columnWidths, true);
  drawHeader();

  const rows = table.rows.length ? table.rows : [['لا توجد بيانات', ...Array(table.head.length - 1).fill('')]];
  rows.forEach((row, index) => {
    const fullRow = table.head.map((_, cellIndex) => row[cellIndex] ?? '-');
    const { rowHeight } = measureTableRow(page, fullRow, columnWidths);
    if (page.y + rowHeight > page.bottomLimit) {
      page = createPage(options, logo, letterhead);
      pages.push(page);
      drawHeader();
    }
    drawTableRow(page, fullRow, columnWidths, false, index);
  });

  page.y += 14;
};

const drawStamp = (
  pages: CanvasPage[],
  options: ArabicReportOptions,
  logo: HTMLImageElement | null,
  letterhead: HTMLImageElement | null
) => {
  if (!options.stamp) return;

  let page = ensureSpace(pages, options, logo, letterhead, 126);
  const stampBaseY = page.hasLetterhead ? 798 : 878;
  page.y = Math.max(page.y, stampBaseY);

  if (page.y + 118 > page.bottomLimit) {
    page = createPage(options, logo, letterhead);
    pages.push(page);
    page.y = page.hasLetterhead ? 798 : 878;
  }

  const y = page.y;
  const signerStyle = options.letter?.styles?.signer;
  const signerSize = styleSize(signerStyle, 21);
  const signerColor = hexToRgb(signerStyle?.color, COLOR.ink);
  const signerWeight = styleWeight(signerStyle, 800);
  const signerTitleSize = Math.max(10, signerSize - 5);

  if (page.isOfficialLetter) {
    const leftBlockX = PAGE_MARGIN + 260;
    drawText(page, options.stamp.title, leftBlockX, y + 42, {
      size: signerTitleSize,
      color: signerStyle ? signerColor : COLOR.muted,
      weight: signerStyle?.bold ? 800 : 400,
      italic: signerStyle?.italic,
      maxWidth: 290,
    });
    drawText(page, options.stamp.name, leftBlockX, y + 70, {
      size: signerSize,
      weight: signerWeight,
      color: signerColor,
      italic: signerStyle?.italic,
      maxWidth: 290,
    });

    page.y += 110;
    return;
  }

  const leftBlockX = PAGE_MARGIN + 260;
  drawText(page, options.stamp.title, leftBlockX, y + 42, {
    size: 16,
    color: COLOR.muted,
    maxWidth: 290,
  });
  drawText(page, options.stamp.name, leftBlockX, y + 70, {
    size: 21,
    weight: 800,
    maxWidth: 290,
  });

  page.y += 110;
};

const drawFooter = (page: CanvasPage, pageNumber: number, totalPages: number, footer: string[]) => {
  const { ctx } = page;
  if (page.isOfficialLetter) return;

  if (page.hasLetterhead) {
    drawText(page, `صفحة ${pageNumber} من ${totalPages}`, PAGE_MARGIN, 958, {
      size: 11,
      color: COLOR.muted,
      align: 'left',
      direction: 'rtl',
    });
    return;
  }

  ctx.strokeStyle = 'rgb(229, 231, 235)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(PAGE_MARGIN, FOOTER_LINE_Y);
  ctx.lineTo(PAGE_WIDTH - PAGE_MARGIN, FOOTER_LINE_Y);
  ctx.stroke();

  if (footer.length) {
    drawText(page, footer.join(' | '), PAGE_WIDTH - PAGE_MARGIN, FOOTER_TEXT_Y, {
      size: 12,
      color: COLOR.muted,
      maxWidth: 480,
      maxLines: 1,
    });
  }

  drawText(page, `صفحة ${pageNumber} من ${totalPages}`, PAGE_MARGIN, FOOTER_TEXT_Y, {
    size: 12,
    color: COLOR.muted,
    align: 'left',
    direction: 'rtl',
  });
};

export const setupArabicPdf = async (doc: jsPDF) => {
  doc.setLanguage('ar');
  doc.setR2L(true);
  return 'canvas-arabic';
};

export const arabicText = (doc: jsPDF, text: string, x: number, y: number, options: Record<string, any> = {}) => {
  doc.setR2L(true);
  doc.text(String(text || ''), x, y, { align: 'right', ...options });
};

export const arabicTableStyles = (fontName: string) => ({
  styles: { font: fontName, fontSize: 8, halign: 'right' as const, cellPadding: 2.5 },
  headStyles: { font: fontName, fillColor: COLOR.orange, halign: 'right' as const, textColor: COLOR.white },
  bodyStyles: { font: fontName, halign: 'right' as const },
});

export const saveArabicReportPdf = async (options: ArabicReportOptions) => {
  try {
    await prepareFonts();
    const reportOptions = options.letter ? options : { ...options, hideBrand: true };
    const letterhead = reportOptions.letter ? await loadImage(OFFICIAL_LETTER_SRC)
      .catch(() => loadImage(LETTERHEAD_SRC))
      .catch(() => null) : null;
    const logo = (reportOptions.letter || reportOptions.invoiceHeader)
      ? await loadImage('/icons/letterhead-logo.png')
        .catch(() => loadImage('/icons/logo.svg'))
        .catch(() => loadImage('/icons/icon.svg'))
        .catch(() => null)
      : null;
    const pages = [createPage(reportOptions, logo, letterhead)];

    if (reportOptions.letter) {
      drawOfficialLetter(pages, reportOptions, logo, letterhead);
    } else {
      drawMeta(pages, reportOptions, logo, letterhead);
      drawSummary(pages, reportOptions, logo, letterhead);
      await drawImageBlock(pages, reportOptions, logo, letterhead);
      drawSections(pages, reportOptions, logo, letterhead);
    }

    const tables = reportOptions.tables || (reportOptions.table ? [reportOptions.table] : []);
    tables.forEach(table => drawTable(pages, reportOptions, logo, letterhead, table));
    drawStamp(pages, reportOptions, logo, letterhead);

    const doc = new jsPDF('p', 'mm', 'a4');
    pages.forEach((page, index) => {
      drawFooter(page, index + 1, pages.length, reportOptions.footer || []);
      if (index > 0) doc.addPage();
      doc.addImage(page.canvas.toDataURL('image/jpeg', 0.96), 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
    });

    doc.save(reportOptions.filename);
  } catch (error) {
    console.error('PDF export failed:', error);
    alert('تعذر تصدير PDF. راجع البيانات وحاول مرة ثانية.');
  }
};
