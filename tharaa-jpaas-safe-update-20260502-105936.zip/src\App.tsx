import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Login from './pages/Login';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Departments from './pages/Departments';
import Users from './pages/Users';
import Finance from './pages/Finance';
import Tasks from './pages/Tasks';
import Attendance from './pages/Attendance';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Freelance from './pages/Freelance';
import Invoices from './pages/Invoices';
import Suppliers from './pages/Suppliers';
import Notifications from './pages/Notifications';
import OfficialLetters from './pages/OfficialLetters';
import Profile from './pages/Profile';
import InstallAppPrompt from './components/InstallAppPrompt';
import { playNotificationSound, showDeviceNotification } from './lib/deviceNotifications';

const pathToTab: Record<string, string> = {
  '/': 'dashboard',
  '/dashboard': 'dashboard',
  '/attendance': 'attendance',
  '/tasks': 'tasks',
  '/finance': 'finance',
  '/freelance': 'freelance',
  '/invoices': 'invoices',
  '/suppliers': 'suppliers',
  '/notifications': 'notifications',
  '/profile': 'profile',
  '/letters': 'letters',
  '/users': 'users',
  '/departments': 'departments',
  '/reports': 'reports',
  '/settings': 'settings',
};

const tabToPath: Record<string, string> = {
  dashboard: '/',
  attendance: '/attendance',
  tasks: '/tasks',
  finance: '/finance',
  freelance: '/freelance',
  invoices: '/invoices',
  suppliers: '/suppliers',
  notifications: '/notifications',
  profile: '/profile',
  letters: '/letters',
  users: '/users',
  departments: '/departments',
  reports: '/reports',
  settings: '/settings',
};

const getTabFromLocation = () => pathToTab[window.location.pathname] || 'dashboard';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('token') !== null);
  const [user, setUser] = useState<any>(JSON.parse(localStorage.getItem('user') || 'null'));
  const [activeTab, setActiveTabState] = useState(getTabFromLocation);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const unreadNotificationsRef = useRef<number | null>(null);

  useEffect(() => {
    const handleRouteChange = () => setActiveTabState(getTabFromLocation());
    window.addEventListener('popstate', handleRouteChange);
    return () => window.removeEventListener('popstate', handleRouteChange);
  }, []);

  useEffect(() => {
    if (!isLoggedIn || !user) {
      unreadNotificationsRef.current = null;
      setUnreadNotifications(0);
      return;
    }

    let stopped = false;
    const checkNotifications = async () => {
      try {
        const resp = await fetch('/api/notifications', {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        if (!resp.ok) return;
        const data = await resp.json();
        const notifications = Array.isArray(data) ? data : data.notifications;
        const unread = Number.isFinite(Number(data?.unreadCount))
          ? Number(data.unreadCount)
          : (Array.isArray(notifications) ? notifications.filter((item: any) => !item.isRead).length : 0);

        if (!stopped && unreadNotificationsRef.current !== null && unread > unreadNotificationsRef.current) {
          const latestUnread = Array.isArray(notifications) ? notifications.find((item: any) => !item.isRead) : null;
          playNotificationSound();
          if (latestUnread && latestUnread.id !== localStorage.getItem('tharaa.lastDeviceNotificationId')) {
            localStorage.setItem('tharaa.lastDeviceNotificationId', latestUnread.id);
            showDeviceNotification(latestUnread).catch(() => undefined);
          }
        }
        unreadNotificationsRef.current = unread;
        if (!stopped) setUnreadNotifications(unread);
      } catch {
        // Silent polling; the notifications page still shows the list.
      }
    };

    checkNotifications();
    const intervalId = window.setInterval(checkNotifications, 25000);
    return () => {
      stopped = true;
      window.clearInterval(intervalId);
    };
  }, [isLoggedIn, user?.id]);

  useEffect(() => {
    if (!isLoggedIn || !user || activeTab !== 'notifications') return;

    unreadNotificationsRef.current = 0;
    setUnreadNotifications(0);
    fetch('/api/notifications/read-all', {
      method: 'PATCH',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    }).catch(() => undefined);
  }, [activeTab, isLoggedIn, user?.id]);

  const setActiveTab = (tab: string) => {
    setActiveTabState(tab);
    const nextPath = tabToPath[tab] || '/';
    if (window.location.pathname !== nextPath || window.location.search) {
      window.history.pushState({}, '', nextPath);
    }
  };

  const onLogin = (token: string, userData: any) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    setIsLoggedIn(true);
  };

  const onUserUpdate = (userData: any) => {
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
  };

  const onNotificationsReadAll = () => {
    unreadNotificationsRef.current = 0;
    setUnreadNotifications(0);
  };

  const onLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setIsLoggedIn(false);
    setActiveTabState('dashboard');
    window.history.replaceState({}, '', '/');
  };

  if (!isLoggedIn || !user) {
    return <Login onLogin={onLogin} />;
  }

  const canOpenTab = (tab: string) => {
    if (tab === 'freelance') return user.role === 'ADMIN';
    if (tab === 'settings') return user.role === 'ADMIN';
    if (['users', 'departments', 'reports', 'invoices', 'letters'].includes(tab)) return user.role === 'ADMIN' || user.role === 'MANAGER';
    if (tab === 'suppliers') return user.role === 'ADMIN' || user.role === 'MANAGER' || Boolean(user.isSupplier);
    return true;
  };

  const renderContent = () => {
    if (!canOpenTab(activeTab)) {
      return <Dashboard user={user} />;
    }

    const pages: any = {
      dashboard: <Dashboard user={user} />,
      departments: <Departments user={user} />,
      users: <Users />,
      finance: <Finance user={user} />,
      freelance: <Freelance />,
      invoices: <Invoices />,
      suppliers: <Suppliers user={user} />,
      notifications: <Notifications user={user} onReadAll={onNotificationsReadAll} />,
      profile: <Profile user={user} onUserUpdate={onUserUpdate} />,
      letters: <OfficialLetters />,
      tasks: <Tasks user={user} />,
      attendance: <Attendance user={user} />,
      reports: <Reports />,
      settings: <Settings />,
    };
    return pages[activeTab] || <Dashboard user={user} />;
  };

  return (
    <div className="flex h-screen bg-[#0a0b0d] text-[#e1e1e1] font-sans" dir="rtl">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={onLogout} user={user} unreadNotifications={unreadNotifications} />
      <main className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
        <InstallAppPrompt />
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.18 }}
            className="max-w-7xl mx-auto"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
