import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, Clock, Database, KeyRound, MapPin, RotateCcw, Save, Settings as SettingsIcon, ShieldCheck } from 'lucide-react';

interface SettingsForm {
  app: {
    name: string;
    port: number;
  };
  attendance: {
    companyLat: number;
    companyLng: number;
    maxDistanceMeters: number;
    minIntervalSeconds: number;
    timeZone: string;
    graceMinutes: number;
  };
  database: {
    mode: string;
    connected?: boolean;
    provider?: string;
    jsonDataDir: string;
  };
}

const defaultSettings: SettingsForm = {
  app: {
    name: 'THARA PRODUCTION',
    port: 3000,
  },
  attendance: {
    companyLat: 32.8872,
    companyLng: 13.1913,
    maxDistanceMeters: 150,
    minIntervalSeconds: 120,
    timeZone: 'Africa/Tripoli',
    graceMinutes: 10,
  },
  database: {
    mode: 'json',
    connected: true,
    provider: 'JSON',
    jsonDataDir: './data',
  },
};

export default function Settings() {
  const [settings, setSettings] = useState<SettingsForm>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [currentResetCode, setCurrentResetCode] = useState('');
  const [newResetCode, setNewResetCode] = useState('');
  const [resetBusy, setResetBusy] = useState('');

  useEffect(() => {
    fetch('/api/settings', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
      .then((response) => response.json())
      .then((data) => setSettings({
        ...defaultSettings,
        ...data,
        app: { ...defaultSettings.app, ...(data.app || {}) },
        attendance: { ...defaultSettings.attendance, ...(data.attendance || {}) },
        database: { ...defaultSettings.database, ...(data.database || {}) },
      }))
      .finally(() => setLoading(false));
  }, []);

  const updateApp = (key: keyof SettingsForm['app'], value: string | number) => {
    setSettings((prev) => ({ ...prev, app: { ...prev.app, [key]: value } }));
  };

  const updateAttendance = (key: keyof SettingsForm['attendance'], value: string | number) => {
    setSettings((prev) => ({ ...prev, attendance: { ...prev.attendance, [key]: value } }));
  };

  const saveSettings = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setMessage('');

    const payload = {
      app: {
        name: settings.app.name,
      },
      attendance: {
        companyLat: Number(settings.attendance.companyLat),
        companyLng: Number(settings.attendance.companyLng),
        maxDistanceMeters: Number(settings.attendance.maxDistanceMeters),
        minIntervalSeconds: Number(settings.attendance.minIntervalSeconds),
        timeZone: settings.attendance.timeZone || 'Africa/Tripoli',
        graceMinutes: Number(settings.attendance.graceMinutes),
      }
    };

    const response = await fetch('/api/settings', {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      const data = await response.json();
      setMessage(data.message || 'تم حفظ الإعدادات');
    } else {
      const error = await response.json();
      setMessage(error.message || 'تعذر حفظ الإعدادات');
    }

    setSaving(false);
  };

  const resetSystem = async () => {
    if (!resetCode.trim()) return setMessage('اكتب رمز التصفير أولاً');
    if (!confirm('تصفير كامل: يمسح الموظفين، الأقسام، المالية، الحضور، المهام، الإشعارات، والفواتير. سيبقى حساب الأدمن فقط. هل أنت متأكد؟')) return;

    setResetBusy('reset');
    setMessage('');
    const response = await fetch('/api/system/reset', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ code: resetCode })
    });
    const data = await response.json().catch(() => ({}));
    setResetBusy('');
    setMessage(data.message || (response.ok ? 'تم التصفير' : 'تعذر التصفير'));
    if (response.ok) setResetCode('');
  };

  const changeResetCode = async () => {
    if (!currentResetCode.trim() || !newResetCode.trim()) return setMessage('اكتب الرمز الحالي والجديد');

    setResetBusy('code');
    setMessage('');
    const response = await fetch('/api/system/reset-code', {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ currentCode: currentResetCode, newCode: newResetCode })
    });
    const data = await response.json().catch(() => ({}));
    setResetBusy('');
    setMessage(data.message || (response.ok ? 'تم تغيير الرمز' : 'تعذر تغيير الرمز'));
    if (response.ok) {
      setCurrentResetCode('');
      setNewResetCode('');
    }
  };

  const storageLabel = settings.database.provider || (
    settings.database.mode === 'postgres' || settings.database.mode === 'supabase'
      ? 'PostgreSQL / Supabase'
      : 'JSON محلي'
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-black text-white">الإعدادات</h1>
        <p className="text-[#6b7280]">تعديل إعدادات الشركة والحضور والموقع الجغرافي</p>
      </div>

      <form onSubmit={saveSettings} className="space-y-6">
        <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6 md:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <SettingsIcon size={22} className="text-orange-500" />
            <h2 className="text-xl font-black text-white">إعدادات النظام</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">اسم الشركة</label>
              <input
                disabled={loading}
                value={settings.app.name}
                onChange={(event) => updateApp('name', event.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              />
            </div>
          </div>
        </div>

        <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6 md:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <MapPin size={22} className="text-orange-500" />
            <h2 className="text-xl font-black text-white">إعدادات الحضور</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">خط العرض Latitude</label>
              <input
                disabled={loading}
                type="number"
                step="0.000001"
                value={settings.attendance.companyLat}
                onChange={(event) => updateAttendance('companyLat', event.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">خط الطول Longitude</label>
              <input
                disabled={loading}
                type="number"
                step="0.000001"
                value={settings.attendance.companyLng}
                onChange={(event) => updateAttendance('companyLng', event.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">نطاق الحضور بالمتر</label>
              <input
                disabled={loading}
                type="number"
                min="10"
                value={settings.attendance.maxDistanceMeters}
                onChange={(event) => updateAttendance('maxDistanceMeters', event.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#6b7280]">الفاصل بين التسجيلات بالثواني</label>
              <input
                disabled={loading}
                type="number"
                min="10"
                value={settings.attendance.minIntervalSeconds}
                onChange={(event) => updateAttendance('minIntervalSeconds', event.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold text-[#6b7280]">توقيت حساب التأخير</label>
              <div className="relative">
                <Clock size={17} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#4b5563]" />
                <input
                  disabled={loading}
                  value={settings.attendance.timeZone}
                  onChange={(event) => updateAttendance('timeZone', event.target.value)}
                  className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 pr-11 pl-4 focus:border-orange-500 outline-none"
                  placeholder="Africa/Tripoli"
                />
              </div>
              <p className="text-[10px] text-[#6b7280]">خليه Africa/Tripoli باش التأخير يتحسب بتوقيت ليبيا بدقة.</p>
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold text-[#6b7280]">مهلة الدخول بالدقائق</label>
              <input
                disabled={loading}
                type="number"
                min="0"
                value={settings.attendance.graceMinutes}
                onChange={(event) => updateAttendance('graceMinutes', event.target.value)}
                className="w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
              />
              <p className="text-[10px] text-[#6b7280]">القيمة الحالية 10 دقائق: لو وقت الدخول 09:00، التأخير يبدأ بعد 09:10.</p>
            </div>
          </div>
        </div>

        <div className="bg-[#111318] border border-[#1f2127] rounded-[2rem] p-6 md:p-8 space-y-5">
          <div className="flex items-center gap-3">
            <Database size={22} className="text-orange-500" />
            <h2 className="text-xl font-black text-white">قاعدة البيانات</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
              <p className="text-[10px] text-[#6b7280] mb-1">نوع التخزين الحالي</p>
              <p className="text-white font-bold">{storageLabel}</p>
            </div>
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
              <p className="text-[10px] text-[#6b7280] mb-1">الحالة</p>
              <div className="flex items-center gap-2 text-green-500 font-bold">
                <CheckCircle2 size={16} />
                <span>{settings.database.connected === false ? 'غير متصل' : 'متصل'}</span>
              </div>
            </div>
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4">
              <p className="text-[10px] text-[#6b7280] mb-1">مصدر الربط</p>
              <p className="text-white text-sm">ملف إعدادات السيرفر</p>
            </div>
            <div className="md:col-span-3 bg-orange-500/10 border border-orange-500/20 rounded-2xl p-4">
              <p className="text-sm text-orange-100 leading-7">
                بيانات قاعدة البيانات مخفية من هنا لحماية الربط والبيانات. تعديل اسم الشركة والحضور لا يغير رابط التخزين ولا يمس العمليات الموجودة.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#111318] border border-red-500/30 rounded-[2rem] p-6 md:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <AlertTriangle size={22} className="text-red-500" />
            <div>
              <h2 className="text-xl font-black text-white">تصفير المنظومة</h2>
              <p className="text-xs text-[#6b7280] mt-1">تصفير كامل يمسح كل البيانات بما فيها الموظفين والأقسام، ويترك حساب الأدمن فقط.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-5 space-y-3">
              <label className="text-xs font-bold text-[#6b7280]">رمز التصفير</label>
              <input
                type="password"
                value={resetCode}
                onChange={(event) => setResetCode(event.target.value)}
                className="w-full bg-[#111318] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-red-500 outline-none"
                placeholder="tharaproduction"
              />
              <button
                type="button"
                onClick={resetSystem}
                disabled={resetBusy === 'reset'}
                className="w-full flex items-center justify-center gap-2 py-3 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all"
              >
                <RotateCcw size={17} />
                {resetBusy === 'reset' ? 'جاري التصفير...' : 'تصفير كامل للمنظومة'}
              </button>
            </div>

            <div className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-5 space-y-3">
              <label className="text-xs font-bold text-[#6b7280]">تغيير رمز التصفير</label>
              <input
                type="password"
                value={currentResetCode}
                onChange={(event) => setCurrentResetCode(event.target.value)}
                className="w-full bg-[#111318] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
                placeholder="الرمز الحالي"
              />
              <input
                type="password"
                value={newResetCode}
                onChange={(event) => setNewResetCode(event.target.value)}
                className="w-full bg-[#111318] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none"
                placeholder="الرمز الجديد"
              />
              <button
                type="button"
                onClick={changeResetCode}
                disabled={resetBusy === 'code'}
                className="w-full flex items-center justify-center gap-2 py-3 bg-[#1f2127] hover:bg-[#2a2d35] disabled:opacity-50 text-white font-bold rounded-xl transition-all"
              >
                <KeyRound size={17} />
                {resetBusy === 'code' ? 'جاري التغيير...' : 'تغيير الرمز'}
              </button>
            </div>
          </div>
        </div>

        {message && (
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4 text-green-500 text-sm font-bold flex items-center gap-2">
            <ShieldCheck size={18} />
            {message}
          </div>
        )}

        <button
          type="submit"
          disabled={saving || loading}
          className="w-full md:w-auto flex items-center justify-center gap-2 px-8 py-4 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20"
        >
          <Save size={18} />
          {saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
        </button>
      </form>
    </div>
  );
}
