import React, { useMemo, useState } from 'react';
import { AlignRight, Bold, Building2, CalendarDays, FileDown, FileText, Hash, Italic, Palette, Type } from 'lucide-react';
import { saveArabicReportPdf } from '../lib/pdfArabic';

const DEFAULT_GREETING = 'تحية طيبة وبعد،';
const SIGNERS = [
  { name: 'عبد الغني بن سعد', title: 'المدير العام' },
  { name: 'محمود قنونو', title: 'المدير التنفيذي' },
];

type StyleKey = 'recipient' | 'greeting' | 'body' | 'signer';

interface TextStyle {
  fontSize: number;
  bold: boolean;
  italic: boolean;
  color: string;
}

const DEFAULT_TEXT_STYLES: Record<StyleKey, TextStyle> = {
  recipient: { fontSize: 20, bold: true, italic: false, color: '#111318' },
    greeting: { fontSize: 19, bold: true, italic: false, color: '#111318' },
  body: { fontSize: 19, bold: false, italic: false, color: '#111318' },
  signer: { fontSize: 21, bold: true, italic: false, color: '#111318' },
};

const normalizeDigits = (value: string) =>
  value
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)));

const parseManualDate = (value: string) => {
  const parts = normalizeDigits(value).trim().split(/[^\d]+/).filter(Boolean);
  if (parts.length < 3) return null;

  const [first, second, third] = parts;
  const isYearFirst = first?.length === 4;
  const year = isYearFirst ? first : (third?.length === 4 ? third : parts.find((part) => part.length === 4) || third);
  const month = second?.padStart(2, '0').slice(-2);
  const day = (isYearFirst ? third : first)?.padStart(2, '0').slice(-2);

  if (!year || !month || !day) return null;
  return {
    year: year.length === 2 ? `20${year}` : year,
    yearSuffix: year.slice(-2),
    month,
    day,
  };
};

const formatLetterDate = (value: string) => {
  const parsed = parseManualDate(value);
  return parsed ? `${parsed.day} / ${parsed.month} / ${parsed.year}` : normalizeDigits(value);
};

const getTodayDateString = () => {
  const today = new Date();
  const day = String(today.getDate()).padStart(2, '0');
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const year = today.getFullYear();
  return `${day} / ${month} / ${year}`;
};

const balancePreviewText = (value: string, maxChars = 48) => {
  const paragraphs = (value.trim() || 'نص الرسالة')
    .replace(/\r/g, '')
    .split(/\n+/)
    .map((paragraph) => paragraph.trim())
    .filter(Boolean);

  const wrapParagraph = (paragraph: string) => {
    const words = paragraph.split(/\s+/).filter(Boolean);
    const lines: string[] = [];
    let current = '';

    words.forEach((word) => {
      const trial = current ? `${current} ${word}` : word;
      if (trial.length <= maxChars) {
        current = trial;
        return;
      }
      if (current) lines.push(current);
      current = word;
    });
    if (current) lines.push(current);

    const rebalancePair = (firstLine: string, secondLine: string) => {
      const combined = `${firstLine} ${secondLine}`.split(/\s+/).filter(Boolean);
      if (combined.length < 4) return [firstLine, secondLine];

      let best = [firstLine, secondLine];
      let bestScore = Number.POSITIVE_INFINITY;

      for (let split = 2; split <= combined.length - 2; split += 1) {
        const first = combined.slice(0, split).join(' ');
        const second = combined.slice(split).join(' ');
        if (first.length > maxChars || second.length > maxChars) continue;

        const shortPenalty = Math.max(0, maxChars * 0.68 - first.length) + Math.max(0, maxChars * 0.68 - second.length);
        const score = Math.abs(first.length - second.length) + shortPenalty * 1.5;
        if (score < bestScore) {
          bestScore = score;
          best = [first, second];
        }
      }

      return best;
    };

    for (let pass = 0; pass < 3; pass += 1) {
      for (let index = lines.length - 1; index > 0; index -= 1) {
        const [first, second] = rebalancePair(lines[index - 1], lines[index]);
        lines[index - 1] = first;
        lines[index] = second;
      }
    }

    return lines;
  };

  return paragraphs.flatMap(wrapParagraph);
};

export default function OfficialLetters() {
  const [formData, setFormData] = useState({
    recipient: '',
    date: getTodayDateString(),
    reference: '',
    greeting: DEFAULT_GREETING,
    body: '',
    signerName: SIGNERS[0].name,
    styles: DEFAULT_TEXT_STYLES,
  });

  const selectedSigner = SIGNERS.find((signer) => signer.name === formData.signerName) || SIGNERS[0];
  const letterDate = formatLetterDate(formData.date || getTodayDateString());
  const previewBodyLines = useMemo(() => balancePreviewText(formData.body, 48).slice(0, 12), [formData.body]);
  const currentGreeting = formData.greeting.trim() || DEFAULT_GREETING;

  const handleExport = async () => {
    if (!formData.recipient.trim()) return alert('اكتب الجهة المرسل إليها');
    if (!formData.body.trim()) return alert('اكتب نص الرسالة الرسمية');

    await saveArabicReportPdf({
      filename: `official-letter-${Date.now()}.pdf`,
      title: 'رسالة رسمية',
      subtitle: 'THARA PRODUCTION',
      letter: {
        recipient: formData.recipient.trim(),
        date: formData.date.trim() || getTodayDateString(),
        reference: formData.reference.trim() || '-',
        body: formData.body.trim(),
        greeting: currentGreeting,
        styles: formData.styles,
      },
      stamp: {
        name: selectedSigner.name,
        title: selectedSigner.title,
      },
      footer: ['THARA PRODUCTION', 'رسالة رسمية']
    });
  };

  const inputClass = 'w-full bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-3 px-4 focus:border-orange-500 outline-none transition-all';
  const labelClass = 'flex items-center gap-2 text-xs font-bold text-[#8b929f]';

  const updateTextStyle = (key: StyleKey, patch: Partial<TextStyle>) => {
    setFormData((current) => ({
      ...current,
      styles: {
        ...current.styles,
        [key]: {
          ...current.styles[key],
          ...patch,
        },
      },
    }));
  };

  const previewTextStyle = (key: StyleKey): React.CSSProperties => {
    const style = formData.styles[key];
    return {
      fontSize: `${Math.max(8, Math.round(style.fontSize * 0.58))}px`,
      fontWeight: style.bold ? 900 : 400,
      fontStyle: style.italic ? 'italic' : 'normal',
      color: style.color,
    };
  };

  const styleControlLabels: Record<StyleKey, string> = {
    recipient: 'الجهة',
    greeting: 'التحية',
    body: 'نص الرسالة',
    signer: 'التوقيع',
  };

  const renderTextStyleControls = (key: StyleKey) => {
    const style = formData.styles[key];

    return (
      <div key={key} className="bg-[#0a0b0d] border border-[#1f2127] rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm font-black text-white">{styleControlLabels[key]}</p>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => updateTextStyle(key, { bold: !style.bold })}
              className={`w-9 h-9 flex items-center justify-center rounded-xl border transition-all ${style.bold ? 'bg-orange-600 border-orange-500 text-white' : 'border-[#1f2127] text-[#8b929f] hover:text-white'}`}
              title="غامق"
            >
              <Bold size={16} />
            </button>
            <button
              type="button"
              onClick={() => updateTextStyle(key, { italic: !style.italic })}
              className={`w-9 h-9 flex items-center justify-center rounded-xl border transition-all ${style.italic ? 'bg-orange-600 border-orange-500 text-white' : 'border-[#1f2127] text-[#8b929f] hover:text-white'}`}
              title="مائل"
            >
              <Italic size={16} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-[1fr_58px] gap-3">
          <label className="space-y-2">
            <span className="flex items-center gap-1 text-[10px] font-bold text-[#6b7280]">
              <Type size={12} />
              حجم الخط
            </span>
            <input
              type="number"
              min="10"
              max="34"
              value={style.fontSize}
              onChange={(event) => updateTextStyle(key, { fontSize: Number(event.target.value) || style.fontSize })}
              className="w-full bg-[#111318] border border-[#1f2127] text-white rounded-xl py-2 px-3 focus:border-orange-500 outline-none"
            />
          </label>
          <label className="space-y-2">
            <span className="flex items-center gap-1 text-[10px] font-bold text-[#6b7280]">
              <Palette size={12} />
              اللون
            </span>
            <input
              type="color"
              value={style.color}
              onChange={(event) => updateTextStyle(key, { color: event.target.value })}
              className="w-full h-10 bg-[#111318] border border-[#1f2127] rounded-xl p-1"
            />
          </label>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-10" dir="rtl">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-orange-600/10 border border-orange-500/20 text-orange-500 flex items-center justify-center">
            <FileText size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-white">رسالة رسمية</h1>
            <p className="text-[#8b929f] text-sm">مراسلات THARA PRODUCTION</p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleExport}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-orange-500/20 active:scale-95"
        >
          <FileDown size={18} />
          تصدير PDF
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_390px] gap-6 items-start">
        <div className="bg-[#111318] border border-[#1f2127] rounded-2xl p-5 sm:p-7 space-y-6">
          <div className="flex items-center justify-between gap-3 border-b border-[#1f2127] pb-5">
            <div>
              <h2 className="text-xl font-black text-white">بيانات الخطاب</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className={labelClass}>
                <Building2 size={15} />
                الجهة المرسل إليها
              </label>
              <input
                value={formData.recipient}
                onChange={(event) => setFormData({ ...formData, recipient: event.target.value })}
                className={inputClass}
                placeholder="مثال: السادة / شركة ..."
              />
            </div>
            <div className="space-y-2">
              <label className={labelClass}>
                <Hash size={15} />
                رقم الإشارة
              </label>
              <input
                value={formData.reference}
                onChange={(event) => setFormData({ ...formData, reference: event.target.value })}
                className={inputClass}
                placeholder="اختياري"
              />
            </div>
            <div className="space-y-2">
              <label className={labelClass}>
                <CalendarDays size={15} />
                التاريخ
              </label>
              <input
                value={formData.date}
                onChange={(event) => setFormData({ ...formData, date: event.target.value })}
                className={inputClass}
                placeholder="مثال: 29 / 04 / 2026"
                dir="auto"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className={labelClass}>
              <AlignRight size={15} />
              التحية
            </label>
            <input
              value={formData.greeting}
              onChange={(event) => setFormData({ ...formData, greeting: event.target.value })}
              className={inputClass}
              placeholder={DEFAULT_GREETING}
            />
          </div>

          <div className="space-y-2">
            <label className={labelClass}>
              <AlignRight size={15} />
              نص الرسالة
            </label>
            <textarea
              value={formData.body}
              onChange={(event) => setFormData({ ...formData, body: event.target.value })}
              className="w-full min-h-[420px] bg-[#0a0b0d] border border-[#1f2127] text-white rounded-xl py-5 px-5 focus:border-orange-500 outline-none transition-all resize-y leading-8 text-[15px] sm:text-base text-right"
              placeholder="اكتب نص الرسالة الرسمية هنا..."
              dir="rtl"
              wrap="soft"
            />
          </div>

          <div className="space-y-3">
            <label className={labelClass}>
              <Type size={15} />
              تنسيق نصوص الورقة
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(['recipient', 'greeting', 'body', 'signer'] as StyleKey[]).map(renderTextStyleControls)}
            </div>
          </div>

          <div className="space-y-2">
            <label className={labelClass}>اختيار التوقيع</label>
            <select
              value={formData.signerName}
              onChange={(event) => setFormData({ ...formData, signerName: event.target.value })}
              className={inputClass}
            >
              {SIGNERS.map((signer) => (
                <option key={signer.name} value={signer.name}>{signer.name}</option>
              ))}
            </select>
          </div>
        </div>

        <aside className="h-fit">
          <div
            className="relative aspect-[794/1123] w-full overflow-hidden rounded-2xl bg-white bg-cover bg-center shadow-xl shadow-black/25 border border-[#e5e7eb]"
            style={{ backgroundImage: "url('/icons/official-letter-template.png')" }}
          >
            <div className="absolute left-[3.7%] top-[3.6%] h-[7.5%] w-[31%] bg-white/95" />
            <div className="absolute left-[5%] top-[4.8%] w-[27.5%] grid grid-cols-[1fr_54px] items-center gap-2 text-[8px] font-black text-[#111318]">
              <span className="overflow-hidden whitespace-nowrap text-center" dir="ltr">{letterDate}</span>
              <span className="text-right">التاريخ</span>
            </div>
            <div className="absolute left-[5%] top-[7.5%] w-[27.5%] grid grid-cols-[1fr_54px] items-center gap-2 text-[8px] font-black text-[#111318]">
              <span className="overflow-hidden whitespace-nowrap text-center" dir="ltr">{normalizeDigits(formData.reference) || '-'}</span>
              <span className="text-right">الإشاري</span>
            </div>
            <div className="absolute right-[7%] top-[18.5%] left-[7%] text-right font-black leading-6 text-[#111318]" style={previewTextStyle('recipient')}>
              السادة / {formData.recipient || 'الجهة المرسل إليها'}
            </div>
            <div className="absolute right-[7%] left-[7%] top-[27%] text-[#111318]">
              <p className="text-right" style={previewTextStyle('greeting')}>{currentGreeting}</p>
              <div className="mt-2 leading-6 overflow-hidden" style={previewTextStyle('body')}>
                {previewBodyLines.map((line, index) => {
                  const shouldJustify = line.split(/\s+/).filter(Boolean).length > 2;
                  return (
                    <span
                      key={`${line}-${index}`}
                      className="block whitespace-nowrap"
                      style={{
                        textAlign: shouldJustify ? 'justify' : 'center',
                        textAlignLast: shouldJustify ? 'justify' : 'center',
                      }}
                    >
                      {line}
                    </span>
                  );
                })}
              </div>
            </div>
            <div className="absolute left-[7%] bottom-[16.5%] text-left" style={previewTextStyle('signer')}>
              <p className="opacity-70">{selectedSigner.title}</p>
              <p>{selectedSigner.name}</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
